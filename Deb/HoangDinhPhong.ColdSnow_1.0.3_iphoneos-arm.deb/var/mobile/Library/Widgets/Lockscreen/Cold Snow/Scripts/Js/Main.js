var iPhoneType = "auto";
if (iPhoneType == "auto") {
if (screen.height == 667) { iPhoneType = "iPh678"; }
else if (screen.height == 736) { iPhoneType = "iPh678Plus"; }
else if (screen.height == 812) { iPhoneType = "iPhX"; }
else if (screen.height == 896) { iPhoneType = "iPhMax"; }
else if (screen.height == 844) { iPhoneType = "iPh12Pro"; }
else { iPhoneType = "iPh12Max"; }
}

window.addEventListener("load", function() { 
switch(iPhoneType) {

case "iPh678":
document.body.style.width='375px';
document.body.style.height='667px';
$("#AmLich").css({ "top":"94%" });
$("#Title").css({ "top":"88.5%" });
$("#BatCont").css({ "top":"63.7%" });
$("#Clock").css({ "top":"61%" });
$("#AmLich").css({ "letter-spacing":"5.5px" });
break;

case "iPh678Plus":
document.body.style.width='414px';
document.body.style.height='736px';
$("#BatCont").css({ "top":"64.15%" });
$("#Clock").css({ "top":"61.7%" });
break;

case "iPhX":
document.body.style.width='375px';
document.body.style.height='812px';
$("#AmLich").css({ "letter-spacing":"5.5px" });
break;

case "iPhMax":
document.body.style.width='414px';
document.body.style.height='896px';
break;

case "iPh12Pro":
document.body.style.width='390px';
document.body.style.height='844px';
$("#AmLich").css({ "letter-spacing":"6px" });
break;

case "iPh12Max":
document.body.style.width='428px';
document.body.style.height='926px';
$("#AmLich").css({ "letter-spacing":"7px" });
break;
}}, false);