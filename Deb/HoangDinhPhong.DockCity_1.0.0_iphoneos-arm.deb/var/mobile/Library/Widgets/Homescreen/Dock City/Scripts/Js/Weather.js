function mainUpdate(type) {
if (type === "battery") { updateBattery(); }
if (type === "weather") { checkWeather(); }
}

function checkWeather() {
document.getElementById('WeIcon').src = 'Scripts/Weather/' + weather.conditionCode + '.png';
document.getElementById("City").innerHTML = weather.city;
document.getElementById("Temp").innerHTML = weather.temperature + '°';
  //document.getElementById("High").innerHTML = '⇡' + ' ' + weather.high + '°';
  //document.getElementById("Low").innerHTML = '⇣' + ' ' + weather.low + '°';
  //document.getElementById("FeelsLike").innerHTML = weather.feelsLike + '°';
  //document.getElementById("WindSpeed").innerHTML = windspeedtext + ' ' + weather.windSpeed + ' km/h';
  //document.getElementById("Humidity").innerHTML = humiditytext + ' ' + weather.humidity + '%';
  //document.getElementById("Rain").innerHTML = raintext + ' ' + weather.hourlyForecasts[0].percentPrecipitation + '%';

  //document.getElementById("Day1").innerHTML = sday[weather.dayForecasts[1].dayOfWeek - 1];
  //document.getElementById("Day2").innerHTML = sday[weather.dayForecasts[2].dayOfWeek - 1];
  //document.getElementById("Day3").innerHTML = sday[weather.dayForecasts[3].dayOfWeek - 1];

  //document.getElementById("Day1Icon").src = "Scripts/Weather/" + config.IconSet2 + "/" + weather.dayForecasts[1].icon + ".png";
  //document.getElementById("Day2Icon").src = "Scripts/Weather/" + config.IconSet2 + "/" + weather.dayForecasts[2].icon + ".png";
  //document.getElementById("Day3Icon").src = "Scripts/Weather/" + config.IconSet2 + "/" + weather.dayForecasts[3].icon + ".png";

  //document.getElementById("Day1HiLo").innerHTML = weather.dayForecasts[1].high + "°" + "|" + weather.dayForecasts[1].low + "°";
  //document.getElementById("Day2HiLo").innerHTML = weather.dayForecasts[2].high + "°" + "|" + weather.dayForecasts[2].low + "°";
  //document.getElementById("Day3HiLo").innerHTML = weather.dayForecasts[3].high + "°" + "|" + weather.dayForecasts[3].low + "°";

  //document.getElementById("City").innerHTML = weather.city;
  //document.getElementById("Condition").innerHTML = condition[weather.conditionCode];
  //document.getElementById('LastUpdate').innerHTML = lastupdatetext + ' ' + weather.updateTimeString.substring(8, 13);
}