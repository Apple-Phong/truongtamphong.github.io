// Color
document.documentElement.style.setProperty('--allCl', config.allCl);

// Blur
document.documentElement.style.setProperty('--appBlur', config.appBlur + 'px');

//Border
document.documentElement.style.setProperty('--br', config.br + 'px');

// On off
if(!config.app){
document.getElementById('Application').style.display = 'none';
}

if(!config.stt3){
document.getElementById('Star').style.display = 'none';
document.getElementById('Stt3').style.display = 'none';
document.getElementById('Stt3LineTopL').style.display = 'none';
document.getElementById('Stt3LineTopR').style.display = 'none';
document.getElementById('Stt3LineBotL').style.display = 'none';
document.getElementById('Stt3LineBotR').style.display = 'none';
document.getElementById('Stt3LineCenter1').style.display = 'none';
document.getElementById('Stt3LineCenter2').style.display = 'none';
}
// Other
