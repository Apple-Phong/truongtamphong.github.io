var iPhoneType = "auto";
if (iPhoneType == "auto") {
   if (screen.height == 812) {
      iPhoneType = "iPhX";
   } else if (screen.height == 896) {
      iPhoneType = "iPhMax";
   } else if (screen.height == 844) {
      iPhoneType = "iPh12Pro";
   } else {
      iPhoneType = "iPh12Max";
   }
}

window.addEventListener("load", function () {
   switch (iPhoneType) {

      case "iPhX":
         document.body.style.width = '375px';
         document.body.style.height = '812px';
         $("#AlYear").css({
            "font-size": "13px"
         });
         $("#BatRing").css({
            "height":"29px", "width": "29px"
         });
         $("#WeIcon").css({
            "top":"6%"
         });
         $("#PlayPause").css({
            "top": "51%", "left":"48.5%"
         });
         $(".Scrobble-times").css({
            "padding-top": "13px"
         });
         break;

      case "iPhMax":
         document.body.style.width = '414px';
         document.body.style.height = '896px';
         break;

      case "iPh12Pro":
         document.body.style.width = '390px';
         document.body.style.height = '844px';
         $("#WeIcon").css({
            "top":"6%"
         });
         $("#BatRing").css({
            "height":"30.5px", "width": "30.5px"
         });
         $("#PlayPause").css({
            "top": "51%", "left":"49%"
         });
         break;

      case "iPh12Max":
         document.body.style.width = '428px';
         document.body.style.height = '926px';
         $("#BatRing").css({
            "height":"33.5px", "width": "33.5px"
         });
         $(".Scrobble-times").css({
            "padding-top": "20px"
         });
         break;
   }
}, false);