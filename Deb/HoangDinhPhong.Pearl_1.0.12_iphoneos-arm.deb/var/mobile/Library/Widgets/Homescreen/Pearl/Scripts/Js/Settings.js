document.getElementById('YourName').innerHTML = config.name;
document.getElementById('Email').innerHTML = config.email;
document.documentElement.style.setProperty('--avSize', config.avSize +'px');
document.documentElement.style.setProperty('--filter', config.filter +'%');
document.documentElement.style.setProperty('--bll', config.bll);
document.documentElement.style.setProperty('--blr', config.blr);
document.documentElement.style.setProperty('--effCl', config.effCl);
document.documentElement.style.setProperty('--dateCl', config.dateCl);
if(!config.app) {
document.getElementById('AppCont').style.display = 'none'; }