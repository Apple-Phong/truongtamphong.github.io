if (window.config.language == 'Vietnamese') {
var pertext = "Pin";
var yeartext = "";
var freeRAMtxt = "RAM trống:";
var titletext = "✯ Âm Nhạc ✯ ࿐♪ ♫ ༄";
var gan = new Array ("Giáp", "Ất", "Bính", "Đinh", "Mậu", "Kỷ", "Canh", "Tân", "Nhâm", "Quý");
var zhi = new Array ("Tí", "Sửu", "Dần", "Mão", "Thìn", "Tị", "Ngọ", "Mùi", "Thân", "Dậu", "Tuất", "Hợi");
var sunday = ['CN'];
var sday = ['T2', 'T3', 'T4', 'T5', 'T6', 'T7'];
var months = ["Tháng 01", "Tháng 02", "Tháng 03", "Tháng 04", "Tháng 05", "Tháng 06", "Tháng 07", "Tháng 08", "Tháng 09", "Tháng 10", "Tháng 11", "Tháng 12"];
}

if (window.config.language == 'English') {
var pertext = "Battery";
var freeRAMtxt = "Free RAM:";
var titletext = "✫ Media Player ✫ ࿐♪♫༄";
var yeartext = "Year";
var gan = new Array ("", "", "", "", "", "", "", "", "", "");
var zhi = new Array (" Rat", " Ox", " Tiger", " Cat", " Dragon", " Snake", " Horse", " Goat", " Monkey", " Rooster", " Dog", " Pig");
var sunday = ['Su'];
var sday = ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
}