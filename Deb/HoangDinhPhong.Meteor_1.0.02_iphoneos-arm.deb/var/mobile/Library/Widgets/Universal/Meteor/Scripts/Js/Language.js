if (window.config.language == "Vietnamese") {
var wetext = "Thời tiết hiện tại";
var temptext = "và nhiệt độ khoảng";
var altext = "Âm lịch";
var monthtext = "tháng";
var yeartext = "";
var gan = new Array ("giáp", "ất", "bính", "đinh", "mậu", "kỷ", "canh", "tân", "nhâm", "quý");
var zhi = new Array ("tí", "sửu", "dần", "mão", "thìn", "tị", "ngọ", "mùi", "thân", "dậu", "tuất", "hợi");
var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
var months = ["Tháng 1", "Tháng 2", "Tháng 3", "Tháng 4", "Tháng 5", "Tháng 6", "Tháng 7", "Tháng 8", "Tháng 9", "Tháng 10", "Tháng 11", "Tháng 12"];
var condition = ["lốc xoáy", "bão nhiệt đới", "có bão", "giông bão lớn", "giông bão", "mưa và tuyết hỗn hợp", "mưa có tuyết", "tuyết và mưa hỗn hợp", "mưa phùn lạnh giá", "mưa phùn", "mưa đóng băng", "mưa rào", "mưa", "tuyết rơi", "mưa tuyết", "tuyết thổi mạnh", "tuyết rơi", "mưa đá", "mưa đá", "gió bụi", "sương mù", "sương mù nhẹ", "sương mù", "gió dữ dội", "có gió", "trời lạnh", "có mây", "trời nhiều mây", "trời nhiều mây", "có mây vài nơi", "có mây vài nơi", "quang mây", "có nắng", "trời quang mây", "trời nắng", "mưa đá", "trời nóng", "có sấm sét", "giông bão rải rác", "có sấm sét", "mưa lớn", "có tuyết", "tuyết rơi nhẹ", "tuyết rơi nhiều", "ít mây", "có giông", "có tuyết", "có giông", "không có sẵn"];
}

if (window.config.language == "English") {
var wetext = "Current";
var temptext = "and the temp is around";
var altext = "Lunar";
var monthtext = "month";
var yeartext = "year";
var gan = new Array ("", "", "", "", "", "", "", "", "", "");
var zhi = new Array ("rat", "ox", "tiger", "cat", "dragon", "snake", "horse", "goat", "monkey", "rooster", "dog", "pig");
var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
var condition = ["tornado", "tropical storm", "hurricane", "thunderstorm", "thunderstorm", "snow", "sleet", "sleet", "freezing drizzle", "drizzle", "freezing rain", "raining", "raining", "flurries", "snow", "snow", "snow", "hail", "sleet", "dust", "fog", "haze", "smoky", "blustery", "windy", "cold", "cloudy", "cloudy", "cloudy", "cloudy", "cloudy", "clear", "sunny", "fair", "fair", "sleet", "hot", "thunderstorms", "thunderstorms", "thunderstorms", "raining", "heavy snow", "light snow", "heavy snow", "partly cloudy", "thunderstorm", "snow", "thunderstorm", "blank"]
}