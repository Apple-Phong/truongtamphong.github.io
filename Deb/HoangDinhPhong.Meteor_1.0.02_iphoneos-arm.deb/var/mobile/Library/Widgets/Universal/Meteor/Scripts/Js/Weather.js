function mainUpdate(type) {
if (type === "weather"){ checkWeather(); }
}

function checkWeather() {
document.getElementById("WeInfo").innerHTML = wetext + ' ' + condition[weather.conditionCode] + ' ' + temptext + ' ' + weather.temperature + '&deg;' + '.';
}