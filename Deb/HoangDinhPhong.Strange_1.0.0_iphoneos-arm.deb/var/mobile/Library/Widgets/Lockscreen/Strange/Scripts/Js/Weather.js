function mainUpdate(type) {
if (type === "battery") { updateBattery(); }
if (type === "weather") { checkWeather(); }
}

function checkWeather() {
document.getElementById("Temp").innerHTML = weather.temperature + '°';
  //document.getElementById('WeatherIcon').src = 'Scripts/Weather/' + config.IconSet + '/' + weather.conditionCode + '.png';
  document.getElementById("City").innerHTML = weather.city;
   //document.getElementById("HiLo").innerHTML = hilotext + ' ' + weather.high + '°' + '/' + weather.low + '°';
  //document.getElementById("FeelsLike").innerHTML = feelstext + ' ' + weather.feelsLike + '°C';

  document.getElementById("Condition").innerHTML = condition[weather.conditionCode];
  //document.getElementById("Sunrise").innerHTML = sunrisetext + ' ' + weather.sunriseTime.substring(1, 0) + ':' + weather.sunriseTime.substring(3, 1);
  //document.getElementById("Sunset").innerHTML = sunsettext + ' ' + weather.sunsetTime.substring(2, 0) + ':' + weather.sunsetTime.substring(2, 4);
}

//function updateBattery(){
   //document.getElementById('FreeRAMtxt').innerHTML = freeRAMtxt;
   //document.getElementById("FreeRAM").innerHTML = ramFree + ' ' + 'MB';
//}