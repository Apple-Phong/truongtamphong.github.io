/* Offset */
document.documentElement.style.setProperty('--contY', config.contY + '%');
document.documentElement.style.setProperty('--contX', config.contX + '%');

/* Other */
document.documentElement.style.setProperty('--bl', config.bl + 'px');
document.documentElement.style.setProperty('--sc', config.sc);