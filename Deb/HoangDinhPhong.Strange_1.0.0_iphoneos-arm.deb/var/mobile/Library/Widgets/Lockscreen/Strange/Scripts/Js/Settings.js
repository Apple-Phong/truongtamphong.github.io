/* Offset */
document.documentElement.style.setProperty('--contY', config.contY + '%');
document.documentElement.style.setProperty('--contX', config.contX + '%');

/* On off */
if(!config.mu){
document.getElementById('MuCont').style.display = 'none';
}

/* Other */
document.documentElement.style.setProperty('--bl', config.bl + 'px');
document.documentElement.style.setProperty('--sc', config.sc);