function checkMusic(newData) {

if (isplaying === 1) {
document.getElementById('Play').classList.remove("BtnPlay");
document.getElementById('Play').classList.add("BtnPause");
} else {
document.getElementById('Play').classList.remove("BtnPause");
document.getElementById('Play').classList.add("BtnPlay");
}
}

function checkOverflow(el) {
var curOverflow = el.style.overflow;
if ( !curOverflow || curOverflow === "visible" ) {
el.style.overflow = "none"; 
}

var isOverflowing = el.clientWidth < el.scrollWidth;
el.style.overflow = curOverflow;
return isOverflowing; 
}

function XenApi() {
api.media.observeData(function (newData) {
appPlaying = newData.nowPlayingApplication.identifier;
checkMusic(newData); });
}

function HDP() {
XenApi();
}

function Play() {
window.location = 'xeninfo:playpause';
document.getElementById('Play').style.opacity = 0.2;
setTimeout(function () {
document.getElementById('Play').style.opacity = 1;
}, 200);
}

window.addEventListener("load", HDP, false);