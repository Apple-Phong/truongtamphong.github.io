function mainUpdate(type) {
if (type === "weather") { checkWeather() }
}

function checkWeather() {
document.getElementById("WeInfo").innerHTML = weathertext + ' ' + weather.city + ' ' + condition[weather.conditionCode] + ' ' + weather.temperature + '°' + '<br>' + humitext + ' ' + weather.humidity + '%.' + ' ' + windtext + ' ' + weather.windSpeed + ' km/h' + '<br>' + raintext + ' ' + weather.hourlyForecasts[0].percentPrecipitation + '%';
}