function checkWeather() {
document.getElementById("City").innerHTML = weather.city;
document.getElementById("Condition").innerHTML = condition[weather.conditionCode];
document.getElementById("Temp").innerHTML = weather.temperature;
document.getElementById("WeInfo").innerHTML = feelstext + ' ' + weather.feelsLike + '°' + '<br>' + hilotext + ' ' + weather.high + '°' + '/' + weather.low + '°' + '<br>' + raintext + ' ' + weather.hourlyForecasts[0].percentPrecipitation + '%';
document.getElementById("Wind").innerHTML = windtext + ' ' + weather.windSpeed + ' km/h';
document.getElementById("Humi").innerHTML = humitext + ' ' + weather.humidity + '%';
document.getElementById('Deg').innerHTML = '°C';
}