function updateBattery(){
document.getElementById("Bl2").style.width = batteryPercent + "%";
}