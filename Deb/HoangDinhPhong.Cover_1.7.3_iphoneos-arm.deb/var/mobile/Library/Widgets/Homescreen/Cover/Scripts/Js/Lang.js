if (window.config.language == "Vietnamese") {
var days = ["Chủ Nhật", "Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy"];
var months = ["tháng 1", "tháng 2", "tháng 3", "tháng 4", "tháng 5", "tháng 6", "tháng 7", "tháng 8", "tháng 9", "tháng 10", "tháng 11", "tháng 12"];
var monthtext = ["tháng"];
var yeartext = [""];
var humtext = ["✫ Độ ẩm"];
var windtext = ["✫ Gió"];
var raintext = ["Mưa"];
var hitext = ["Cao"];
var lotext = ["Thấp"];
var Gan = new Array ("giáp", "ất", "bính", "đinh", "mậu", "kỷ", "canh", "tân", "nhâm", "quý");
var Zhi = new Array (" tí", " sửu", " dần", " mão", " thìn", " tị", " ngọ", " mùi", " thân", " dậu", " tuất", " hợi");
var subtitletext = "♫ Music ♫";
var artisttext = "Không có nghệ sĩ";
var condition = ["Lốc xoáy", "Bão nhiệt đới", "Có bão", "Giông bão lớn", "Giông bão", "Mưa và tuyết hỗn hợp", "Mưa có tuyết", "Tuyết và mưa hỗn hợp", "Mưa phùn lạnh giá", "Mưa phùn", "Mưa đóng băng", "Mưa rào", "Mưa", "Tuyết rơi", "Mưa tuyết nhẹ", "Tuyết thổi", "Tuyết rơi", "Mưa đá", "Mưa đá", "Gió bụi", "Có sương mù", "Sương mù nhẹ", "Sương mù", "Gió dữ dội", "Có gió", "Trời lạnh", "Có mây", "Trời nhiều mây", "Trời nhiều mây", "Có mây vài nơi", "Có mây vài nơi", "Quang mây", "Có nắng", "Trời quang mây", "Trời nắng", "Mưa đá", "Trời nóng", "Có sấm sét", "Giông bão rải rác", "Có sấm sét", "Mưa lớn", "Có tuyết", "Tuyết rơi nhẹ", "Tuyết rơi nhiều", "Ít mây", "Có dông", "Có tuyết", "Có dông", "Không có sẵn"];
}

if (window.config.language == "English") {
var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
var months = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];
var monthtext = ["month"];
var yeartext = ["year"];
var humtext = ["✫ Humidity"];
var windtext = ["✫ Wind"];
var raintext = ["Precip"];
var hitext = ["Hi"];
var lotext = ["Lo"];
var Gan = new Array ("", "", "", "", "", "", "", "", "", "");
var Zhi = new Array (" rat", " ox", " tiger", " cat", " dragon", " snake", " horse", " goat", " monkey", " rooster", " dog", " pig");
var subtitletext = "♫ Music ♫";
var artisttext = "No Artist";
var condition = ["Tornado", "Tropical storm", "Hurricane", "Severe thunder", "Thunder", "Rain and snow", "Rain and sleet", "Snow and sleet", "Freezing drizzle", "drizzle", "Freezing rain", "Showers", "Showers", "Snow flurries", "Light snow showers", "Blowing snow", "Snow", "Hail", "Sleet", "Dust", "Foggy", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy ", "Mostly cloudy", "Mostly cloudy", "Partly cloudy", "Partly cloudy", "Clear", "Sunny", "Fair", "Fair", "Mixed rain and hail", "Hot", "Isolated thunder", "Scattered thunder", "Scattered thunder", "Scattered showers", "Heavy snow", "Scattered sleet", "Heavy snow", "Partly cloudy", "Thunder", "Snow showers", "Isolated thunder", "Not available"];
}