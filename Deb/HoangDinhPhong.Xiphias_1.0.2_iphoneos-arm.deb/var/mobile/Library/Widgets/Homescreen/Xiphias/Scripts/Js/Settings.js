// Color
document.documentElement.style.setProperty('--textCl', config.textCl);
document.documentElement.style.setProperty('--secCl', config.secCl);
document.documentElement.style.setProperty('--weekdayCl', config.weekdayCl);
document.documentElement.style.setProperty('--batInCl', config.batInCl);
document.documentElement.style.setProperty('--batOutCl', config.batOutCl);
document.documentElement.style.setProperty('--windIconCl', config.windIconCl);
document.documentElement.style.setProperty('--humiIconCl', config.humiIconCl);
document.documentElement.style.setProperty('--rainIconCl', config.rainIconCl);
document.documentElement.style.setProperty('--hiCl', config.hiCl);
document.documentElement.style.setProperty('--loCl', config.loCl);
document.documentElement.style.setProperty('--ramIconCl', config.ramIconCl);
document.documentElement.style.setProperty('--titleCl', config.titleCl);

// On off
if (!config.batTime) {
document.getElementById('AnalogCont').style.display = 'none';
document.getElementById('CalendarCont').style.display = 'none';
document.getElementById('BatCont').style.display = 'none';
document.getElementById('WeatherCont').style.top = '2.5%';
document.getElementById('Application').style.top = '15.5%';
document.getElementById('Application').style.height = '47.1%';
}

if (!config.ramSearch) {
document.getElementById('RamCont').style.display = 'none';
document.getElementById('SearchCont').style.display = 'none';
document.getElementById('Application').style.height = '38.8%';
}

// Other
document.getElementById("In").placeholder = config.ph;