function updateBattery(){
document.getElementById("Percentage").innerHTML = batteryPercent + '%';
document.getElementById("Charging").innerHTML = (batteryCharging) ? charging : notcharging;
}