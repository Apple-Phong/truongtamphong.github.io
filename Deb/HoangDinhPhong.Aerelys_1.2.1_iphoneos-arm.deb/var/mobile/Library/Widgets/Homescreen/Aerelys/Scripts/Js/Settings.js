// Other
document.getElementById("In").placeholder = config.ph;
document.documentElement.style.setProperty('--bl', window.config.bl + 'px');
document.documentElement.style.setProperty('--wallT', window.config.wallT + '%');

// Color
document.documentElement.style.setProperty('--textCl', window.config.textCl);
document.documentElement.style.setProperty('--sepCl', config.sepCl);
document.documentElement.style.setProperty('--playCl', config.playCl);
document.documentElement.style.setProperty('--chanCl', config.chanCl);

// On Off
if (!config.wall) {
document.getElementById('ChangeWall').style.display = 'none';
document.getElementById('Wallpaper').style.display = 'none';
document.getElementById('WallBlur').style.display = 'none';
document.getElementById('WallOverlay').style.display = 'none';
document.getElementById('Control').style.left = '51%';
document.getElementById('Control').style.width = '70%';
}