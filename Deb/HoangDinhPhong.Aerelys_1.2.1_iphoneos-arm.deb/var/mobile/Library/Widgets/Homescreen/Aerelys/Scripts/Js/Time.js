function calendar(options) {
var getTimes = function () {
var d = new Date(),
funcs = {

day: function () {
return d.getDay();
},

date: function () {
return d.getDate();
},

month: function () {
return d.getMonth();
},

year: function () {
return d.getFullYear();
}
};

options.success(funcs);
setTimeout(function () {
getTimes();
}, options.refresh);
};
getTimes();
}

calendar({
twentyfour: config.Time24,
padzero: true,
refresh: 5000,
success:

function(calendar) {
document.getElementById("Year").innerHTML = calendar.year() + '|';
document.getElementById('Weekday').innerHTML = sday[calendar.day()];
document.getElementById('Date').innerHTML = calendar.date(); 
document.getElementById('Month').innerHTML = months[calendar.month()];
}
});