if (window.config.language == "Vietnamese") {
var titletext = "✯ Âm Nhạc ✯ ࿐♪ ♫ ༄";
var artisttext = "Không có nghệ sĩ";
var hitext = "C";
var lotext = "T";
var yeartext = "";
var gan = new Array ("Giáp", "Ất", "Bính", "Đinh", "Mậu", "Kỷ", "Canh", "Tân", "Nhâm", "Quý");
var zhi = new Array ("Tí", "Sửu", "Dần", "Mão", "Thìn", "Tị", "Ngọ", "Mùi", "Thân", "Dậu", "Tuất", "Hợi");
var sday = ["CN", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7"];
var months = ["Tháng 1", "Tháng 2", "Tháng 3", "Tháng 4", "Tháng 5", "Tháng 6", "Tháng 7", "Tháng 8", "Tháng 9", "Tháng 10", "Tháng 11", "Tháng 12"];
var condition = ["Lốc xoáy", "Bão nhiệt đới", "Có bão", "Giông bão lớn", "Giông bão", "Mưa và tuyết hỗn hợp", "Mưa có tuyết", "Tuyết và mưa hỗn hợp", "Mưa phùn lạnh giá", "Mưa phùn", "Mưa đóng băng", "Mưa rào", "Mưa", "Tuyết rơi", "Mưa tuyết", "Tuyết thổi mạnh", "Tuyết rơi", "Mưa đá", "Mưa đá", "Gió bụi", "Sương mù", "Sương mù nhẹ", "Sương mù", "Gió dữ dội", "Có gió", "Trời lạnh", "Có mây", "Trời nhiều mây", "Trời nhiều mây", "Có mây vài nơi", "Có mây vài nơi", "Quang mây", "Có nắng", "Trời quang mây", "Trời nắng", "Mưa đá", "Trời nóng", "Có sấm sét", "Giông bão rải rác", "Có sấm sét", "Mưa lớn", "Có tuyết", "Tuyết rơi nhẹ", "Tuyết rơi nhiều", "Ít mây", "Có giông", "Có tuyết", "Có giông", "Không có sẵn"];
}

if (window.config.language == "English") {
var titletext = "✫ Media Player ✫ ࿐♪♫༄";
var artisttext = "No Artist";
var hitext = "H";
var lotext = "L";
var yeartext = "Year";
var gan = new Array ("", "", "", "", "", "", "", "", "", "");
var zhi = new Array (" Rat", " Ox", " Tiger", " Cat", " Dragon", " Snake", " Horse", " Goat", " Monkey", " Rooster", " Dog", " Pig");
var sday = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
var condition = ["Tornado", "Tropical Storm", "Hurricane", "Thunderstorm", "Thunderstorm", "Snow", "Sleet", "Sleet", "Freezing Drizzle", "Drizzle", "Freezing Rain", "Showers", "Showers", "Flurries", "Snow", "Snow", "Snow", "Hail", "Sleet", "Dust", "Fog", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Clear", "Sunny", "Fair", "Fair", "Sleet", "Hot", "Thunderstorms", "Thunderstorms", "Thunderstorms", "Showers", "Heavy Snow", "Light Snow", "Heavy Snow", "Partly Cloudy", "Thunderstorm", "Snow", "Thunderstorm", "blank"];
}