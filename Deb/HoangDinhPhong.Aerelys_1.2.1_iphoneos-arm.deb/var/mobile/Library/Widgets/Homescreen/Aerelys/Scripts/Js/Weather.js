function mainUpdate(type) {
if (type === "weather") { checkWeather(); }
if (type === "battery") { updateBattery(); }
}

function checkWeather() {
document.getElementById("Day1").src = "Scripts/Weather/Stardock/" + weather.dayForecasts[1].icon + ".png";
document.getElementById("Day2").src = "Scripts/Weather/Stardock/" + weather.dayForecasts[2].icon + ".png";
document.getElementById("Day3").src = "Scripts/Weather/Stardock/" + weather.dayForecasts[3].icon + ".png";
document.getElementById("Day4").src = "Scripts/Weather/Stardock/" + weather.dayForecasts[4].icon + ".png";

document.getElementById('WeatherIcon').src = 'Scripts/Weather/' + weather.conditionCode + '.png';
document.getElementById('Condition').innerHTML = condition[weather.conditionCode];
document.getElementById('Tempe').innerHTML = weather.temperature;
document.getElementById('High').innerHTML = hitext + ' ' + weather.high + '&deg';
document.getElementById('Low').innerHTML = lotext + ' ' + weather.low + '&deg';
}