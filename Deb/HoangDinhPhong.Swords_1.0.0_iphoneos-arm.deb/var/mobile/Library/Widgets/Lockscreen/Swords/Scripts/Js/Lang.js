if (window.config.language == "Vietnamese") {
var charging = "⚡️";
var notcharging = "";
var windspeedtext = "Tốc độ gió";
var humiditytext = "Độ ẩm";
var sunsettext = "Lặn";
var sunrisetext = "Mọc";
var yeartext = "";
var gan = new Array ("Giáp", "Ất", "Bính", "Đinh", "Mậu", "Kỷ", "Canh", "Tân", "Nhâm", "Quý");
var zhi = new Array ("Tí", "Sửu", "Dần", "Mão", "Thìn", "Tị", "Ngọ", "Mùi", "Thân", "Dậu", "Tuất", "Hợi");
var ssday = ["CN", "T2", "T3", "T4", "T5", "T6", "T7"];
var ssmonth = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"];
var condition = ["Lốc xoáy", "Bão nhiệt đới", "Có bão", "Giông bão lớn", "Giông bão", "Mưa và tuyết hỗn hợp", "Mưa có tuyết", "Tuyết và mưa hỗn hợp", "Mưa phùn lạnh giá", "Mưa phùn", "Mưa đóng băng", "Mưa rào", "Mưa", "Tuyết rơi", "Mưa tuyết nhẹ", "Tuyết thổi", "Tuyết rơi", "Mưa đá", "Mưa đá", "Gió bụi", "Sương mù", "Sương mù nhẹ", "Sương mù", "Gió dữ dội", "Có gió", "Trời lạnh", "Có mây", "Trời nhiều mây", "Trời nhiều mây", "Có mây vài nơi", "Có mây vài nơi", "Quang mây", "Có nắng", "Trời quang mây", "Trời nắng", "Mưa đá", "Trời nóng", "Có sấm sét", "Giông bão rải rác", "Có sấm sét", "Mưa lớn", "Có tuyết", "Tuyết rơi nhẹ", "Tuyết rơi nhiều", "Ít mây", "Có giông", "Có tuyết", "Có giông", "Không có sẵn"];
}

if (window.config.language == "English") {
var charging = "⚡️";
var notcharging = "";
var windspeedtext = "Wind speed";
var humiditytext = "Humidity";
var sunsettext = "Dive";
var sunrisetext = "Grow";
var yeartext = "Year";
var gan = new Array ("", "", "", "", "", "", "", "", "", "");
var zhi = new Array ("Rat", "Ox", "Tiger", "Cat", "Dragon", "Snake", "Horse", "Goat", "Monkey", "Rooster", "Dog", "Pig");
var ssday = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];
var ssmonth = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"];
var condition = ["Tornado", "Tropical storm", "Hurricane", "Severe thunderstorms", "Thunderstorms", "Mixed rain and snow", "Mixed rain and sleet", "Mixed snow and sleet", "Freezing drizzle", "drizzle", "Freezing rain", "Showers", "Showers", "Snow flurries", "Light snow showers", "Blowing snow", "Snow", "Hail", "Sleet", "Dust", "Foggy", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy ", "Mostly cloudy", "Mostly cloudy", "Partly cloudy", "Partly cloudy", "Clear", "Sunny", "Fair", "Fair", "Mixed rain and hail", "Hot", "Isolated thunderstorms", "Scattered thunderstorms", "Scattered thunderstorms", "Scattered showers", "Heavy snow", "Scattered snow showers", "Heavy snow", "Partly cloudy", "Thundershowers", "Snow showers", "Isolated thundershowers", "Not available"];
}