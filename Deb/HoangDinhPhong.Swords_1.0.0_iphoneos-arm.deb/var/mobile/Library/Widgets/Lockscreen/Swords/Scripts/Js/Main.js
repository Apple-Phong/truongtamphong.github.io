var iPhoneType = "auto";
if (iPhoneType == "auto") {
if (screen.height == 812) { iPhoneType = "iPhX"; }
else if (screen.height == 896) { iPhoneType = "iPhMax"; }
else if (screen.height == 844) { iPhoneType = "iPh12Pro"; }
else { iPhoneType = "iPh12Max"; }
}

window.addEventListener("load", function() { 
switch(iPhoneType) {

case "iPhX":
document.body.style.width='375px';
document.body.style.height='812px';
$("#WeekdayCont").css({ "width":"23px", "height":"23px" });
$("#Weekday").css({ "font-size":"8px" });
$("#DateMonth").css({ "font-size":"24px" });
$("#Percentage").css({ "right":"12%" });
$("#AlCont").css({ "height":"12.5%" });
$("#AlDate").css({ "font-size":"28px" });
$("#AlMonth").css({ "top":"2%", "font-size":"10px" });
$("#AlYear").css({ "bottom":"-2%", "font-size":"10px" });
$("#WeInfo").css({ "font-size":"10px" });
$("#AlbumCont").css({ "width":"115px", "height":"115px" });
break;

case "iPhMax":
document.body.style.width='414px';
document.body.style.height='896px';
break;

case "iPh12Pro":
document.body.style.width='390px';
document.body.style.height='844px';
$("#Percentage").css({ "right":"12%" });
$("#AlMonth").css({ "top":"-3%" });
$("#AlYear").css({ "bottom":"-4%" });
$("#AlbumCont").css({ "width":"120px", "height":"120px" });
break;

case "iPh12Max":
document.body.style.width='428px';
document.body.style.height='926px';
$("#Percentage").css({ "right":"11%" });
$("#AlMonth").css({ "top":"2%" });
break;
}}, false);