var savedElements = {
"placedElements": {
"BatteryCircle": {
"circle-width": "40px"
},

"Percent": {
"position": "absolute",
"top": "35px",
"left": "-6px",
"font-size": "0px",
"color": "white",
"width": "0px",
"text-align": "center" }
  }
}

/*---------- Elements ----------*/

systemElements = {
'Percent' : ['battery'],
'BatteryCircle' : ['batterycircle'],
};

systemMethods = {
battery: function(){
return injectedSystem.battery;
},

batterycircle: function (){
try{
if(circleProgress){
if(circleProgress.value != injectedSystem.battery){
circleProgress.value = injectedSystem.battery;
    }
  }
} catch(err){}
return "";
  },
};

/*---------- Main Loop ----------*/

function setElementInfo(div, value) {
var innerHTML = div.innerHTML.replace('°', '°'),
innerTEXT = div.innerText.replace('°', '°'),
knockoutEl = null;

if (innerHTML === value || innerTEXT === value) {
return;
} else {
if (String(value).indexOf(';') > -1) {
div.innerHTML = value;
} else {
div.innerText = value;
    }
  }
};

function getSystemInfo(key) {
var value = "";
if (systemElements[key]) {
systemElements[key].forEach(function (info) {
if (systemMethods[info]) {
value += systemMethods[info]();
} else {
value += info;
    }
 });
}
return value;
}

function refreshAllInfo() {
Object.keys(action.savedElements.placedElements).forEach(function (key) {
if (systemElements[key]) {
div = document.getElementById(key);
prefix = div.getAttribute('data-prefix') || '';
suffix = div.getAttribute('data-suffix') || '';
}

if (systemElements[key]) {
if (key.substring(0, 3) != 'box' && key.substring(0, 2) != 'ft') {
value = prefix + getSystemInfo(key) + suffix;
setElementInfo(div, value);
      }
    }
 });
}

var Looper = {
loopit: function (obj) {
var loopSetTimeOutValue = 0;
this[obj.name] = setTimeout(function () {
obj.success();
  }, loopSetTimeOutValue);
},
create: function (obj) {
this.loopit(obj);
  }
};

function startLoop() {
Looper.create({
refreshTime: 1000,
success: function () {
refreshAllInfo();
    }
});
}

/*---------- Main ----------*/

injectedSystem = {}
var action = {};

function setSpecificStylesAfterCreation(div, id) {
switch (id) {
case 'BatteryCircle':
div.className = 'progressBattery';
div.title = 'progressBattery';
circleProgress = new CircleProgress('.progressBattery');
circleProgress.max = 100;
circleProgress.value = 0;
circleProgress.textFormat = 'none';
break;
  }
}

var excludeFromClearingPointerEvents = ['BatteryCircle'];

action.remakeDIV = function (id) {
div = document.createElement('div');
div.id = id;
document.getElementById('BatteryCircle').appendChild(div);
setSpecificStylesAfterCreation(div, id);
return div;
};

function addStyleString(str, id) {
var doc = document;
node = doc.createElement('style');
node.innerHTML = str;
doc.body.appendChild(node);
}

action.loadStyles = function (key, value, createdDiv) {
Object.keys(value).forEach(function (skey) {
styleVal = value[skey];

if (skey === 'circle-width') {
addStyleString('.circle-progress-' + createdDiv.title + '{width:' + styleVal + ';height:' + styleVal + ';}', 'circlewidth' + createdDiv.title);
} else {
try {
createdDiv.style[skey] = styleVal;
} catch (err) {}
    }
 });
};

action.replaceElements = function () {
var elementStyles, createdDiv, placedElements = action.savedElements.placedElements;
if (!placedElements) {
return;
}

Object.keys(placedElements).forEach(function (elementName) {
if (placedElements[elementName].type == 'widget') {
} else {
createdDiv = action.remakeDIV(elementName);
if (!createdDiv) {
return;
}

elementStyles = placedElements[elementName];
action.loadStyles(elementName, elementStyles, createdDiv); }
});

setTimeout(function () {
startLoop();
}, 1000);
};

function isExportedInfo() {
if (typeof savedElements !== 'undefined') {
return savedElements;
} else {
return false;
  }
}

function setStoredElementsToLocalSavedElements() {
if (isExportedInfo()) {
action.savedElements = savedElements;
}
return action.savedElements;
}

action.loadFromStorage = function () {
var elements = setStoredElementsToLocalSavedElements();
if (elements) {
action.replaceElements();
  }
};

function loadInfo() {
action.loadFromStorage();
}

window.onload = function () {
loadInfo();
};