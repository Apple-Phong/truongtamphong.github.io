document.getElementById('BgInput').addEventListener('change', function (e) {
   var tw = e.target.files,
      rd = new FileReader();
   rd.onload = (function () {
      return function (e) {
         localStorage.aerelys = e.target.result;
         document.getElementById('Wallpaper').style.backgroundImage = 'url("' + localStorage.aerelys + '")';
         tw = null;
         rd = null;
      };
   }(tw[0]));
   rd.readAsDataURL(tw[0]);
});
if (localStorage.aerelys && localStorage.aerelys != "null") {
   document.getElementById('Wallpaper').style.backgroundImage = 'url("' + localStorage.aerelys + '")';
}