/* Scale, radius & blur */
document.body.style.webkitTransform = 'scale(' + config.Scale + ')';

/* Color */
document.documentElement.style.setProperty('--weekCl', config.weekCl);
document.documentElement.style.setProperty('--clockCl', config.clockCl);
document.documentElement.style.setProperty('--dateCl', config.dateCl);
document.documentElement.style.setProperty('--yearCl', config.yearCl);
document.documentElement.style.setProperty('--textCl', config.textCl);

/* On off */
if (!config.Clock) {
document.getElementById('Clock').style.display = 'none';
}

if (!config.Year) {
document.getElementById('Year').style.display = 'none';
}