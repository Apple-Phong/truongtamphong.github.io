function DP() { checkSettings(); }
function checkSettings() {
document.documentElement.style.setProperty('--dateCl', config.dateCl);
}