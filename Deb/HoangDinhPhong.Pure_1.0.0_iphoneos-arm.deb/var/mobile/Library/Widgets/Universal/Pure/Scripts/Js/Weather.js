function mainUpdate(type) {
if (type === "weather") { checkWeather(); }
}

function checkWeather() {
document.getElementById('WeatherIcon').src = 'Scripts/Weather/' + weather.conditionCode + '.png';
document.getElementById("WeInfo").innerHTML = condition[weather.conditionCode] + ' ' + weather.temperature + '°';
}