function checkWeather() {
document.getElementById("Temp").innerHTML = weather.temperature + '°';
}