function openLunar() {
if (
document.getElementById("Calendar").classList.contains('closed')) {
document.getElementById("Calendar").classList.add('open');
document.getElementById("Calendar").classList.remove('closed');
document.getElementById("Amlich").classList.add('open');
document.getElementById("Amlich").classList.remove('closed');
return;
} else {
document.getElementById("Calendar").classList.add('closed');
document.getElementById("Calendar").classList.remove('open');
document.getElementById("Amlich").classList.add('closed');
document.getElementById("Amlich").classList.remove('open');
  }
}