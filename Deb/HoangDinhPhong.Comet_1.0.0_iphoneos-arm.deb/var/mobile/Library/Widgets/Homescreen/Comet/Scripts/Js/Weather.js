function mainUpdate(type) {
if (type === "weather") { checkWeather(); } 
if (type === "battery") { updateBattery(); }

function checkWeather() {
document.getElementById('WeInfo').innerHTML = nowtext + ' ' + condition[weather.conditionCode] + '. ' + temptext + ' ' + weather.conditionCode + '&deg;' + '. ' + humtext + ' ' + weather.humidity + '%' + ', ' + windtext + ' ' + weather.windSpeed + ' km/h' + ', ' + citytext + ' ' + weather.city;
document.getElementById('WeatherIcon').src = 'Scripts/Weather/' + weather.conditionCode + '.png';
  }
}