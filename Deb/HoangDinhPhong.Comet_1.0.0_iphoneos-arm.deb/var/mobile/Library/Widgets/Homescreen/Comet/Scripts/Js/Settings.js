document.documentElement.style.setProperty('--nameCl', config.nameCl);
document.documentElement.style.setProperty('--weCalCl', config.weCalCl);
document.documentElement.style.setProperty('--timeBatCl', config.timeBatCl);

document.documentElement.style.setProperty('--timeBatBg', config.timeBatBg);
document.documentElement.style.setProperty('--timeBatLeftCl', config.timeBatLeftCl);
document.documentElement.style.setProperty('--timeBatRightCl', config.timeBatRightCl);

document.getElementById('Wallpaper').src = 'Scripts/Wallpaper/' + config.Wall + '.png';
document.getElementById('YourName').innerHTML = config.YourName;

if(!config.Dock){
document.getElementById('Dock').style.display = 'none';
}