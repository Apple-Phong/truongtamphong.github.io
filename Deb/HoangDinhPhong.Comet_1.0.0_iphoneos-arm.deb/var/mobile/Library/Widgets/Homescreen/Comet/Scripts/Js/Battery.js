function updateBattery() {
document.getElementById("Percent").innerHTML = batteryPercent + ' ' + pertext;
document.getElementById("Bl").style.width = batteryPercent + "%";
document.getElementById("Charging").innerHTML = (batteryCharging) ? charging : notcharging;
}