function mainUpdate(type) {
if (type === "battery") { updateBattery(); }
if (type === "weather") { checkWeather(); }
}

function checkWeather() {
document.getElementById("WeInfo").innerHTML = 
humitext + ' ' + weather.humidity + '%. ' + windtext + ' ' + weather.windSpeed + ' km/h.' + '<br>' + raintext + ' ' + weather.hourlyForecasts[0].percentPrecipitation + '%';
document.getElementById("Temp").innerHTML = weather.temperature + '°C';
document.getElementById("Condition").innerHTML = condition[weather.conditionCode];

document.getElementById("Day1").innerHTML = sday[weather.dayForecasts[1].dayOfWeek - 1];
document.getElementById("Day2").innerHTML = sday[weather.dayForecasts[2].dayOfWeek - 1];
document.getElementById("Day3").innerHTML = sday[weather.dayForecasts[3].dayOfWeek - 1];
document.getElementById("Day4").innerHTML = sday[weather.dayForecasts[4].dayOfWeek - 1];
document.getElementById("Day5").innerHTML = sday[weather.dayForecasts[5].dayOfWeek - 1];

document.getElementById("Day1Icon").src = "Scripts/Weather/" + weather.dayForecasts[1].icon + ".svg";
document.getElementById("Day2Icon").src = "Scripts/Weather/" + weather.dayForecasts[2].icon + ".svg";
document.getElementById("Day3Icon").src = "Scripts/Weather/" + weather.dayForecasts[3].icon + ".svg";
document.getElementById("Day4Icon").src = "Scripts/Weather/" + weather.dayForecasts[4].icon + ".svg";
document.getElementById("Day5Icon").src = "Scripts/Weather/" + weather.dayForecasts[5].icon + ".svg";

document.getElementById("Day1Hi").innerHTML = weather.dayForecasts[1].high;
document.getElementById("Day1Lo").innerHTML = weather.dayForecasts[1].low;
document.getElementById("Day2Hi").innerHTML = weather.dayForecasts[2].high;
document.getElementById("Day2Lo").innerHTML = weather.dayForecasts[2].low;
document.getElementById("Day3Hi").innerHTML = weather.dayForecasts[3].high;
document.getElementById("Day3Lo").innerHTML = weather.dayForecasts[3].low;
document.getElementById("Day4Hi").innerHTML = weather.dayForecasts[4].high;
document.getElementById("Day4Lo").innerHTML = weather.dayForecasts[4].low;
document.getElementById("Day5Hi").innerHTML = weather.dayForecasts[5].high;
document.getElementById("Day5Lo").innerHTML = weather.dayForecasts[5].low;
}