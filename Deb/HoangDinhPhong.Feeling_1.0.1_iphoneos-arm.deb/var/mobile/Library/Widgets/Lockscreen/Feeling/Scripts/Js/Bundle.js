var savedElements = {

"Settings": {
"OpenSettings": {
"BundleID": "com.apple.Preferences" }
},

"Messenger": {
"OpenMessenger": {
"BundleID": "com.facebook.Messenger" }
},

"Facebook": {
"OpenFacebook": {
"BundleID": "com.facebook.Facebook" }
},

"Note": {
"OpenNote": {
"BundleID": "com.apple.mobilenotes" }
},

"YouTube": {
"OpenYouTube": {
"BundleID": "com.google.ios.youtube" }
  }
}