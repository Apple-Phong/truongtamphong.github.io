function mainUpdate(type) {
if (type === "battery") { updateBattery(); }
if (type === "weather") { checkWeather(); }
}

function checkWeather() {
document.getElementById('WeatherIcon').src = 'Scripts/Weather/' + weather.conditionCode + '.png';
document.getElementById("Temp").innerHTML = weather.temperature + '°' + 'C';
document.getElementById("HumiWind").innerHTML = humiditytext + ' ' + weather.humidity + '% - ' + windspeedtext + ' ' + weather.windSpeed + ' km/h';
document.getElementById("Day1Hi").innerHTML = weather.dayForecasts[1].high + "°" + "C";
document.getElementById("Day2Hi").innerHTML = weather.dayForecasts[2].high + "°" + "C";
document.getElementById("Day3Hi").innerHTML = weather.dayForecasts[3].high + "°" + "C";
document.getElementById("Day4Hi").innerHTML = weather.dayForecasts[4].high + "°" + "C";
document.getElementById("Condition").innerHTML = condition[weather.conditionCode];
}