let FontFamily = new FontFace("FontSelect", `url(${'/Fonts/' + config.fontSelect + '.ttf'}) format("truetype")`);

FontFamily.load().then(function (loadedFont) {
document.fonts.add(loadedFont); })