function updateBattery() {
document.getElementById("Bl2").style.width = batteryPercent + "%";

if (batteryPercent > 90 && batteryPercent <= 100) {
document.documentElement.style.setProperty('--batC', '#00FF00');
$("#Bl2").css({ "background": "linear-gradient(to left,#00FF00, #70FF13,#9EFF00,#D3FF13,#FFF604,#FFCB03,#FFA204,#FF6B08,#FF490E,#FF0000)" });
}

if (batteryPercent > 80 && batteryPercent <= 90) {
document.documentElement.style.setProperty('--batC', '#70FF13');
$("#Bl2").css({ "background": "linear-gradient(to left,#70FF13,#9EFF00,#D3FF13,#FFF604,#FFCB03,#FFA204,#FF6B08,#FF490E,#FF0000)" });
}

if (batteryPercent > 70 && batteryPercent <= 80) {
document.documentElement.style.setProperty('--batC', '#9EFF00');
$("#Bl2").css({ "background": "linear-gradient(to left,#9EFF00,#D3FF13,#FFF604,#FFCB03,#FFA204,#FF6B08,#FF490E,#FF0000)" });
}

if (batteryPercent > 60 && batteryPercent <= 70) {
document.documentElement.style.setProperty('--batC', '#D3FF13');
$("#Bl2").css({ "background": "linear-gradient(to left,#D3FF13,#FFF604,#FFCB03,#FFA204,#FF6B08,#FF490E,#FF0000)" });
}

if (batteryPercent > 50 && batteryPercent <= 60) {
document.documentElement.style.setProperty('--batC', '#FFF604');
$("#Bl2").css({ "background": "linear-gradient(to left,#FFF604,#FFCB03,#FFA204,#FF6B08,#FF490E,#FF0000)" });
}

if (batteryPercent > 40 && batteryPercent <= 50) {
document.documentElement.style.setProperty('--batC', '#FFCB03');
$("#Bl2").css({ "background": "linear-gradient(to left,#FFCB03,#FFA204,#FF6B08,#FF490E,#FF0000)"
});
}

if (batteryPercent > 30 && batteryPercent <= 40) {
document.documentElement.style.setProperty('--batC', '#FFA204');
$("#Bl2").css({ "background": "linear-gradient(to left,#FFA204,#FF6B08,#FF490E,#FF0000)" });
}

if (batteryPercent > 20 && batteryPercent <= 30) {
document.documentElement.style.setProperty('--batC', '#FF6B08');
$("#Bl2").css({ "background": "linear-gradient(to left,#FF6B08,#FF490E,#FF0000)" });
}

if (batteryPercent >= 10 && batteryPercent <= 20) {
document.documentElement.style.setProperty('--batC', '#FF490E');
$("#Bl2").css({ "background": "linear-gradient(to left,#FF490E,#FF0000)" });
}

if (batteryPercent >= 0 && batteryPercent <= 10) {
document.documentElement.style.setProperty('--batC', '#FF0000');
$("#Bl2").css({ "background": "#FF0000" });
}

ram = ramusedtext + ' ' + ramUsed + 'MB, ' + ramfreetext + ' ' + ramFree + 'MB';

var activate = true;
if (batteryCharging === 1) {
if (activate) {
activate = true;
document.getElementById("Dot1R").style.opacity = 0.1;
document.getElementById("Dot3").style.opacity = 0.1;
setTimeout(function () {
document.getElementById("Dot1R").style.opacity = 1;
document.getElementById("Dot3").style.opacity = 1;
activate = true;
}, 100); }
}
}