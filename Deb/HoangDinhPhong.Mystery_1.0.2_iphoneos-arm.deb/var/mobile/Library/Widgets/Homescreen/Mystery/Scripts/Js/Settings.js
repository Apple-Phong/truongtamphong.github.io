/* Color */
document.documentElement.style.setProperty('--consoleCl', config.consoleCl);
document.documentElement.style.setProperty('--textCl', config.textCl);
document.documentElement.style.setProperty('--slideCl', config.slideCl);
document.documentElement.style.setProperty('--nameCl', config.nameCl);
document.documentElement.style.setProperty('--lightCl', config.lightCl);
document.documentElement.style.setProperty('--deviceCl', config.deviceCl);
document.documentElement.style.setProperty('--iosCl', config.iosCl);
document.documentElement.style.setProperty('--calCl', config.calCl);
document.documentElement.style.setProperty('--alCl', config.alCl);

document.documentElement.style.setProperty('--dotOneCl', config.dotOneCl);
document.documentElement.style.setProperty('--dotTwoCl', config.dotTwoCl);
document.documentElement.style.setProperty('--dotThreeCl', config.dotThreeCl);

/* Border & Blur */
document.documentElement.style.setProperty('--br', config.br + 'px');
document.documentElement.style.setProperty('--bl', config.bl + 'px');

/* Name */
document.getElementById('YourName').innerHTML = config.YourName;

/* On off */
if (!config.conName) {
document.getElementById('Console').style.display = 'none';
document.getElementById('YourName').style.display = 'block';
}

if (!config.deviceCal) {
document.getElementById('DeviceCont').style.display = 'none';
document.getElementById('Calendar').style.display = 'block';
document.getElementById('AmLich').style.display = 'block';
}

/* Src */
document.getElementById('ChainTopLeft').src = 'Scripts/Images/' + config.Chain + '.png';
document.getElementById('ChainTopRight').src = 'Scripts/Images/' + config.Chain + '.png';
document.getElementById('ChainCenLeft').src = 'Scripts/Images/' + config.Chain + '.png';
document.getElementById('ChainCenRight').src = 'Scripts/Images/' + config.Chain + '.png';
document.getElementById('ChainBotLeft').src = 'Scripts/Images/' + config.Chain + '.png';
document.getElementById('ChainBotRight').src = 'Scripts/Images/' + config.Chain + '.png';

document.documentElement.style.setProperty('--bri', config.bri + '%');