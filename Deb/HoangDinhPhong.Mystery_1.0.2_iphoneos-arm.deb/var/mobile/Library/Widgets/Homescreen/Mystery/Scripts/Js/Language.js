if (window.config.language == "Vietnamese") {
var altext = 'Âm lịch:';
var intext = 'Tại';
var windtext = 'tốc độ gió';
var raintext = 'khả năng mưa/h';
var humitext = 'độ ẩm';
var hilotext = 'nhiệt độ cao & thấp nhất là';
var ramusedtext = 'RAM sử dụng:';
var ramfreetext = 'RAM còn trống:';
var titletext = '✯ Âm Nhạc ✯ ࿐♪ ♫ ༄';
var arttext = 'Chưa phát';
var days = ["Chủ Nhật", "Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy"];
var shortdays = ["CN", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7"];
var shortmonths = ["Tháng 1 ", "Tháng 2", "Tháng 3", "Tháng 4", "Tháng 5", "Tháng 6", "Tháng 7", "Tháng 8", "Tháng 9", "Tháng 10", "Tháng 11", "Tháng 12"];
var condition = ["Có lốc xoáy", "Bão nhiệt đới", "Có giông bão", "Giông bão lớn", "Giông bão", "Mưa và tuyết", "Mưa có tuyết", "Tuyết và mưa", "Mưa phùn lạnh", "Mưa phùn", "Mưa đóng băng", "Mưa rào", "Có mưa", "Tuyết rơi", "Mưa tuyết", "Tuyết thổi mạnh", "Tuyết rơi", "Mưa đá", "Mưa đá", "Gió bụi", "Sương mù", "Sương mù nhẹ", "Sương mù", "Gió dữ dội", "Có gió", "Trời lạnh", "Có mây", "Trời nhiều mây", "Trời nhiều mây", "Có mây vài nơi", "Có mây vài nơi", "Quang mây", "Có nắng", "Trời quang mây", "Trời nắng", "Mưa đá", "Trời nóng", "Có sấm sét", "Có giông bão", "Có sấm sét", "Mưa lớn", "Có tuyết", "Tuyết rơi nhẹ", "Tuyết rơi nhiều", "Ít mây", "Có giông", "Có tuyết", "Có giông", "Không có sẵn"];
}

if (window.config.language == "English") {
var altext = 'Lunar';
var intext = 'In';
var windtext = 'wind speed';
var humitext = 'humidity';
var raintext = 'chance of rain/h';
var hilotext = 'The highest & lowest temperature is';
var ramusedtext = 'RAM used:';
var ramfreetext = 'Free RAM:';
var titletext = '✯ Music ✯ ࿐♪ ♫ ༄';
var arttext = 'No Media Player';
var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
var shortdays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
var shortmonths = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
var condition = ["Tornado", "Tropical storm", "Hurricane", "Thunderstorms", "Thunderstorms", "Mixed rain", "Mixed rain", "Mixed snow", "Freezing drizzle", "Drizzle", "Freezing rain", "Showers", "Showers", "Snow flurries", "Light snow", "Blowing snow", "Snow", "Hail", "Sleet", "Dust", "Foggy", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy ", "Mostly cloudy", "Mostly cloudy", "Partly cloudy", "Partly cloudy", "Clear", "Sunny", "Fair", "Fair", "Mixed rain", "Hot", "Thunderstorms", "Thunderstorms", "Thunderstorms", "Scattered showers", "Heavy snow", "Snow showers", "Heavy snow", "Partly cloudy", "Thundershowers", "Snow showers", "Thundershowers", "Not available"];
}