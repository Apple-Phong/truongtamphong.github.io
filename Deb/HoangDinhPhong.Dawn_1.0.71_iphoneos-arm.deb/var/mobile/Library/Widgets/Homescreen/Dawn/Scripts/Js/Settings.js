/*Color*/
document.documentElement.style.setProperty('--bgCl', config.bgCl);
document.documentElement.style.setProperty('--leftCl', config.leftCl);
document.documentElement.style.setProperty('--rightCl', config.rightCl);
document.documentElement.style.setProperty('--appBgCl', config.appBgCl);
document.documentElement.style.setProperty('--muBgCl', config.muBgCl);
document.documentElement.style.setProperty('--batBgCl', config.batBgCl);
document.documentElement.style.setProperty('--clockCl', config.clockCl);
document.documentElement.style.setProperty('--calCl', config.calCl);
document.documentElement.style.setProperty('--cityCl', config.cityCl);
document.documentElement.style.setProperty('--prevNextCl', config.prevNextCl);
document.documentElement.style.setProperty('--playCl', config.playCl);
document.documentElement.style.setProperty('--infoCl', config.infoCl);
document.documentElement.style.setProperty('--muTimeCl', config.muTimeCl);
document.documentElement.style.setProperty('--slideCl', config.slideCl);
document.documentElement.style.setProperty('--cenCl', config.cenCl);
document.documentElement.style.setProperty('--cenBoCl', config.cenBoCl);
document.documentElement.style.setProperty('--titleCl', config.titleCl);
document.documentElement.style.setProperty('--perCl', config.perCl);
document.documentElement.style.setProperty('--dockCl', config.dockCl);

/*On off*/
if(!config.Av){
document.getElementById('AvaCont').style.display = 'none';
}

if(!config.Glasses){
document.getElementById('AvaGlasses').style.display = 'none';
}

if(!config.WallGlasses){
document.getElementById('WallGlasses').style.display = 'none';
}

if(!config.Cal){
document.getElementById('AmLich').style.display = 'block';
document.getElementById('Calendar').style.display = 'none';
}

if(!config.App){
document.getElementById('AppsCont').style.display = 'none';
}

if(!config.Ctrl){
document.getElementById('CtrlCont').style.display = 'none';
}

if(!config.Tit){
document.getElementById('Title').style.display = 'none';
}

if(!config.Bat){
document.getElementById('Battery').style.display = 'none';
}

if(!config.Per){
document.getElementById('Percentage').style.display = 'none';
}

if(!config.Do){
document.getElementById('Dock').style.display = 'none';
}

/*Shadow*/
if (window.config.sh == "ou"){
document.getElementById('AvaCont').classList.remove('Shadow-wide');
document.getElementById('AvaCont').classList.add('Shadow-narrow');

document.getElementById('WallCont').classList.remove('Shadow-wide');
document.getElementById('WallCont').classList.add('Shadow-narrow');

document.getElementById('AppsCont').classList.remove('Shadow-wide');
document.getElementById('AppsCont').classList.add('Shadow-narrow');

document.getElementById('CtrlCont').classList.remove('Shadow-wide');
document.getElementById('CtrlCont').classList.add('Shadow-narrow');
}