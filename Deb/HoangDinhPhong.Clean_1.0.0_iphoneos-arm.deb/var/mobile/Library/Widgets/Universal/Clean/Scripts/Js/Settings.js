// Color
document.documentElement.style.setProperty('--textCl', config.textCl);
document.documentElement.style.setProperty('--yearCl', config.yearCl);

// On off
if (!config.title) {
document.getElementById('Title').style.display = 'none';
}