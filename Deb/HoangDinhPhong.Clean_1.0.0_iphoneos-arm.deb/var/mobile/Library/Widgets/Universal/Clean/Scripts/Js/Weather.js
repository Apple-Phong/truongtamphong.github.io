function checkWeather() {
document.getElementById("WeInfo").innerHTML = weather.city + ' | ' + weather.temperature + '°';
}