var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

function clock(options) {
var getTimes = function () {
var d = new Date(),
funcs = {

day: function () {
return d.getDay();
},

datepadded: function () {
return (d.getDate() < 10) ? "0" + d.getDate() : d.getDate();
},

month: function () {
return d.getMonth();
},

year: function () {
return d.getFullYear();
}
};

options.success(funcs);
setTimeout(function () {
getTimes();
}, options.refresh);
};
getTimes();
}

clock({
refresh: 5000,
success:

function (clock) {
document.getElementById('Weekday').innerHTML = days[clock.day()];
document.getElementById('Date').innerHTML = clock.datepadded();
document.getElementById('Month').innerHTML = months[clock.month()];
document.getElementById('Year').innerHTML = clock.year();
}
});