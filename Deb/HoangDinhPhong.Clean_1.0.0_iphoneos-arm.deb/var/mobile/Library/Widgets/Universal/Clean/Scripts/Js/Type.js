var iPhoneType = "auto";
if (iPhoneType == "auto") {
if (screen.height == 780) { iPhoneType = "iPhMini" }
else if (screen.height == 812) { iPhoneType = "iPhX11P" }
else if (screen.height == 896) { iPhoneType = "iPh11M" }
else if (screen.height == 844) { iPhoneType = "iPh12P" }
else if (screen.height == 926) { iPhoneType = "iPh12M" }
}

window.addEventListener("load", function () {
switch (iPhoneType) {

case "iPhMini":
document.body.style.width = '360px';
document.body.style.height = '780px';
$("#Date").css({ "font-size":"72px" });
$("#Percentage").css({ "top":"17.5%" });
break;

case "iPhX11P":
document.body.style.width = '375px';
document.body.style.height = '812px';
$("#Date").css({ "font-size":"74px" });
$("#Percentage").css({ "top":"17.6%" });
break;

case "iPh11M":
document.body.style.width = '414px';
document.body.style.height = '896px';
break;

case "iPh12P":
document.body.style.width = '390px';
document.body.style.height = '844px';
break;

case "iPh12M":
document.body.style.width = '428px';
document.body.style.height = '926px';
$("#Date").css({ "font-size":"84px" });
break;
}
}, false);