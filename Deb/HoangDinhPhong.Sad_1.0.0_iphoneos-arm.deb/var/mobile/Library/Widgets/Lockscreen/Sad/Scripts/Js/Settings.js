document.documentElement.style.setProperty('--textCl', config.textCl);
document.documentElement.style.setProperty('--hourAltCl', config.hourAltCl);