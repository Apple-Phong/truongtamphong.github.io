var iPhoneType = "auto";
if (iPhoneType == "auto") {
if (screen.height == 667) { iPhoneType = "iPh678"; }
else if (screen.height == 736) { iPhoneType = "iPh678Plus"; }
else if (screen.height == 780) { iPhoneType = "iPhMini"; }
else if (screen.height == 812) { iPhoneType = "iPhX"; }
else if (screen.height == 896) { iPhoneType = "iPhMax"; }
else if (screen.height == 844) { iPhoneType = "iPh12Pro"; }
else if (screen.height == 926) { iPhoneType = "iPh12Max"; }
}

window.addEventListener("load", function() { 
switch(iPhoneType) {

case "iPh678":
document.body.style.width='375px';
document.body.style.height='667px';
$("#DaMo").css({ "font-size":"46px" });
$("#WeatherIcon").css({ "top":"15.3%" });
break;

case "iPh678Plus":
document.body.style.width='414px';
document.body.style.height='736px';
$("#DaMo").css({ "font-size":"49px" });
$("#WeatherIcon").css({ "top":"15.3%" });
break;

case "iPhMini":
document.body.style.width = '360px';
document.body.style.height = '780px';
break;

case "iPhX":
document.body.style.width='375px';
document.body.style.height='812px';
$("#DaMo").css({ "font-size":"54px" });
break;

case "iPhMax":
document.body.style.width='414px';
document.body.style.height='896px';
break;

case "iPh12Pro":
document.body.style.width='390px';
document.body.style.height='844px';
$("#DaMo").css({ "font-size":"58px" });
break;

case "iPh12Max":
document.body.style.width='428px';
document.body.style.height='926px';
break;
}}, false);