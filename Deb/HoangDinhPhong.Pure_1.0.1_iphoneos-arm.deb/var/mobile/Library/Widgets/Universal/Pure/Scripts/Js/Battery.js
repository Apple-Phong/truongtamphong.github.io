function updateBattery() {
document.getElementById("Battery").style.width = batteryPercent + "%";
document.getElementById("Percentage").innerHTML = batteryPercent + "%";
}