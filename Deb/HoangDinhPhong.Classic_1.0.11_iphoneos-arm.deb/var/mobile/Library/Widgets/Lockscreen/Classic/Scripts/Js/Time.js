function clock(options) {
var getTimes = function () {
var d = new Date(),
funcs = {

hour: function () {
var hour = (options.twentyfour === true) ? d.getHours() : (d.getHours() + 11) % 12 + 1;
hour = (options.padzero === true) ? (hour < 10 ? "0" + hour : "" + hour) : hour;
return hour;
},

rawminute: function () {
return d.getMinutes();
},

minuteonetext: function () {
if (minuteone[this.rawminute()] !== undefined) {
return minuteone[this.rawminute()];
}
return "";
},

minutetwotext: function () {
if (minutetwo[this.rawminute()] !== undefined) {
return minutetwo[this.rawminute()];
}
return "";
},

day: function () {
return d.getDay();
},

datepadded: function () {
return (d.getDate() < 10) ? "0" + d.getDate() : d.getDate();
},

month: function () {
return d.getMonth();
},

year: function () {
return d.getFullYear();
}
};

options.success(funcs);
setTimeout(function () {
getTimes();
}, options.refresh);
};
getTimes();
}

clock({
twentyfour: config.Time24,
padzero: true,
refresh: 5000,
success:

function (clock) {
document.getElementById("Hour").innerHTML = clock.hour();
document.getElementById("Minute").innerHTML = clock.minuteonetext() + ' ' + clock.minutetwotext();
document.getElementById('Date').innerHTML = clock.datepadded();
document.getElementById('Weekday').innerHTML = days[clock.day()];
document.getElementById('MonthYear').innerHTML = months[clock.month()] + ' ' + clock.year();
}
});