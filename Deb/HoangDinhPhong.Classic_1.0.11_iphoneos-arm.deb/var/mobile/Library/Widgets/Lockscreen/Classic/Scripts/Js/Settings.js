if (!config.media) {
document.getElementById('Prev').style.display = 'none';
document.getElementById('PlayCont').style.display = 'none';
document.getElementById('Next').style.display = 'none';
document.getElementById('LineL').style.display = 'none';
document.getElementById('LineC').style.display = 'none';
document.getElementById('LineR').style.display = 'none';
document.getElementById('ColumnL').style.display = 'none';
document.getElementById('ColumnR').style.display = 'none';
document.getElementById('Title').style.display = 'none';
}

document.getElementById('HourText').innerHTML = hourtext;
document.getElementById('PerText').innerHTML = pertext;
document.getElementById('Deg').innerHTML = '°';