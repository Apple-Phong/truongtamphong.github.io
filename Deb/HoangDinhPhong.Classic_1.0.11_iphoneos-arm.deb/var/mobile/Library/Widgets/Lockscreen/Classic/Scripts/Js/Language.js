if (window.config.language == "Vietnamese") {
var hourtext = "Giờ";
var pertext = "Năng lượng";
var charging = "Đang sạc...";
var notcharging = "Chưa sạc";
var humitext = "Độ ẩm";
var windtext = "Tốc độ gió";
var titletext = "✯ Thế giới âm nhạc ✯";
var monthtext = "Tháng";
var yeartext = "Năm";
var gan = new Array ("Giáp", "Ất", "Bính", "Đinh", "Mậu", "Kỷ", "Canh", "Tân", "Nhâm", "Quý");
var zhi = new Array ("Tí", "Sửu", "Dần", "Mão", "Thìn", "Tị", "Ngọ", "Mùi", "Thân", "Dậu", "Tuất", "Hợi");
var days = ["Chủ Nhật", "Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy"];
var months = ["Tháng một", "Tháng hai", "Tháng ba", "Tháng tư", "Tháng năm", "Tháng sáu", "Tháng bảy", "Tháng tám", "Tháng chín", "Tháng mười", "Tháng m.một", "Tháng m.hai"];
var minuteone = ["Không không", "Không một", "Không hai", "Không ba", "Không bốn", "Không năm", "Không sáu", "Không bảy", "Không tám", "Không chín", "Mười", "Mười một", "Mười hai", "Mười ba", "Mười bốn", "Mười năm", "Mười sáu", "Mười bảy", "Mười tám", "Mười chín", "Hai mươi", "Hai mươi", "Hai mươi", "Hai mươi", "Hai mươi", "Hai mươi", "Hai mươi", "Hai mươi", "Hai mươi", "Hai mươi", "Ba mươi", "Ba mươi", "Ba mươi", "Ba mươi", "Ba mươi", "Ba mươi", "Ba mươi", "Ba mươi", "Ba mươi", "Ba mươi", "Bốn mươi", "Bốn mươi", "Bốn mươi", "Bốn mươi", "Bốn mươi", "Bốn mươi", "Bốn mươi", "Bốn mươi", "Bốn mươi", "Bốn mươi", "Năm mươi", "Năm mươi", "Năm mươi", "Năm mươi", "Năm mươi", "Năm mươi", "Năm mươi", "Năm mươi", "Năm mươi", "Năm mươi", "Năm mươi"];
var minutetwo = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "mốt", "hai", "ba", "bốn", "năm", "sáu", "bảy", "tám", "chín", "", "mốt", "hai", "ba", "bốn", "năm", "sáu", "bảy", "tám", "chín", "", "mốt", "hai", "ba", "bốn", "năm", "sáu", "bảy", "tám", "chín", "", "mốt", "hai", "ba", "bốn", "năm", "sáu", "bảy", "tám", "chín", ""];
}

if (window.config.language == "English") {
var hourtext = "Hours";
var pertext = "Battery";
var charging = "Charging...";
var notcharging = "Discharged";
var humitext = "Humidity";
var windtext = "Wind speed";
var titletext = "✯ No media player ✯";
var monthtext = "Month";
var yeartext = "Year";
var gan = new Array ("", "", "", "", "", "", "", "", "", "");
var zhi = new Array ("Rat", "Ox", "Tiger", "Cat", "Dragon", "Snake", "Horse", "Goat", "Monkey", "Rooster", "Dog", "Pig");
var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
var minuteone = ["O' Clock", "O' One", "O' Two", "O' Three", "O' Four", "O' Five", "O' Six", "O' Seven", "O' Eight", "O' Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty"];
var minutetwo = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", ""];
}