document.getElementById('BgInput').addEventListener('change', function (e) {
   var tw = e.target.files,
      rd = new FileReader();
   rd.onload = (function () {
      return function (e) {
         localStorage.dark = e.target.result;
         document.getElementById('Wallpaper').style.backgroundImage = 'url("' + localStorage.dark + '")';
         tw = null;
         rd = null;
      };
   }(tw[0]));
   rd.readAsDataURL(tw[0]);
});
if (localStorage.dark && localStorage.dark != "null") {
   document.getElementById('Wallpaper').style.backgroundImage = 'url("' + localStorage.dark + '")';
}