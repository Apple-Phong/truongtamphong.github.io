/*---------- Calendar ----------*/

function openCal() {
if (
document.getElementById("Calendar").classList.contains('closed')) {
document.getElementById("Calendar").classList.add('open');
document.getElementById("Calendar").classList.remove('closed');
return;
} else {
document.getElementById("Calendar").classList.add('closed');
document.getElementById("Calendar").classList.remove('open');
  }
}

function openCalArrow() {
if (
document.getElementById("CalArrow").classList.contains('closed')) {
document.getElementById("CalArrow").classList.add('open');
document.getElementById("CalArrow").classList.remove('closed');
return;
} else {
document.getElementById("CalArrow").classList.add('closed');
document.getElementById("CalArrow").classList.remove('open');
  }
}

/*---------- Weather ----------*/

function openWeInfo() {
if (
document.getElementById("WeInfoBox").classList.contains('closed')) {
document.getElementById("WeInfoBox").classList.add('open');
document.getElementById("WeInfoBox").classList.remove('closed');
return;
} else {
document.getElementById("WeInfoBox").classList.add('closed');
document.getElementById("WeInfoBox").classList.remove('open');
  }
}

function openWeArrow() {
if (
document.getElementById("WeArrow").classList.contains('closed')) {
document.getElementById("WeArrow").classList.add('open');
document.getElementById("WeArrow").classList.remove('closed');
return;
} else {
document.getElementById("WeArrow").classList.add('closed');
document.getElementById("WeArrow").classList.remove('open');
  }
}