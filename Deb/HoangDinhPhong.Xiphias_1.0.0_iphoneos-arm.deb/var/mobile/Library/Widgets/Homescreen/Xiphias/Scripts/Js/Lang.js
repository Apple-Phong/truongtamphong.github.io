if (window.config.language == "Vietnamese") {
var charging = "⚡️";
var notcharging = "";
var sunrisetext = "Bình minh";
var sunsettext = "Hoàng hôn";
var feelstext = "Nhiệt độ cảm nhận";
var windtext = "Tốc độ gió";
var humitext = "Độ ẩm";
var raintext = "Khả năng có mưa";
var freeramtext = "RAM trống";
var titletext = "✯ Âm Nhạc ✯ ࿐♪ ♫ ༄";
var artisttext = "Không có nghệ sĩ";
var monthtext = "Tháng";
var sday = ["CN", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7"];
var days = ["Chủ Nhật", "Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy"];
var smonth = ["Tháng 1", "Tháng 2", "Tháng 3", "Tháng 4", "Tháng 5", "Tháng 6", "Tháng 7", "Tháng 8", "Tháng 9", "Tháng 10", "Tháng 11", "Tháng 12"];
}

if (window.config.language == "English") {
var charging = "⚡️";
var notcharging = "";
var sunrisetext = "Sunrise";
var sunsettext = "Sunset";
var feelstext = "Feels Like";
var windtext = "Wind speed";
var humitext = "Humidity";
var raintext = "Chances of rain";
var freeramtext = "Free RAM";
var titletext = "✯ Music ✯ ࿐♪ ♫ ༄";
var artisttext = "No Artist";
var monthtext = "Month";
var sday = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
var smonth = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
}