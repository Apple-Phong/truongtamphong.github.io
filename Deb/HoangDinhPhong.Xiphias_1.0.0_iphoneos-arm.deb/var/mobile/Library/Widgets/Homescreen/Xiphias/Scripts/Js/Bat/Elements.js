var savedElements = {
"placedElements": {
"BatteryCircle": {
"circle-cap": "round",
"circle-stroke": "7px",
"circle-width": "100%",
"circle-stroke-value": "7px",
"inner-color": "var(--batInCl)",
"outer-color": "var(--batOutCl)",
},

"Percentage": { }
  }
}