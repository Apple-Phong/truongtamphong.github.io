function mainUpdate(type) {
if (type == "battery") { injectedSystem.battery = batteryPercent; 
document.getElementById("Charging").innerHTML = (batteryCharging) ? charging : notcharging;
document.getElementById("FreeRAM").innerHTML = freeramtext + ' ' + ramFree + ' MB'; }
if (type === "weather") { checkWeather(); }
}

function checkWeather() {
document.getElementById('WeatherIcon').src = 'Scripts/Weather/HTC/' + weather.conditionCode + '.png';
document.getElementById("Temp").innerHTML = weather.temperature + '°';
document.getElementById("High").innerHTML = weather.high + '°';
document.getElementById("Low").innerHTML = weather.low + '°';
document.getElementById("FeelsLike").innerHTML = feelstext + ' ' + weather.feelsLike + '°';
document.getElementById("Sunrise").innerHTML = sunrisetext + ' ' + weather.sunriseTime.substring(1, 0) + ':' + weather.sunriseTime.substring(3, 1);
document.getElementById("Sunset").innerHTML = sunsettext + ' ' + weather.sunsetTime.substring(2, 0) + ':' + weather.sunsetTime.substring(2, 4);
document.getElementById("Wind").innerHTML = windtext + ' ' + weather.windSpeed + ' km/h';
document.getElementById("Humi").innerHTML = humitext + ' ' + weather.humidity + '%';
document.getElementById("Rain").innerHTML = raintext + ' ' + weather.hourlyForecasts[0].percentPrecipitation + '%';

document.getElementById("Day1").innerHTML = sday[weather.dayForecasts[1].dayOfWeek - 1];
document.getElementById("Day2").innerHTML = sday[weather.dayForecasts[2].dayOfWeek - 1];
document.getElementById("Day3").innerHTML = sday[weather.dayForecasts[3].dayOfWeek - 1];
document.getElementById("Day1Icon").src = "Scripts/Weather/" + weather.dayForecasts[1].icon + ".svg";
document.getElementById("Day2Icon").src = "Scripts/Weather/" + weather.dayForecasts[2].icon + ".svg";
document.getElementById("Day3Icon").src = "Scripts/Weather/" + weather.dayForecasts[3].icon + ".svg";
document.getElementById("Day1Hi").innerHTML = weather.dayForecasts[1].high;
document.getElementById("Day1Lo").innerHTML = weather.dayForecasts[1].low;
document.getElementById("Day2Hi").innerHTML = weather.dayForecasts[2].high;
document.getElementById("Day2Lo").innerHTML = weather.dayForecasts[2].low;
document.getElementById("Day3Hi").innerHTML = weather.dayForecasts[3].high;
document.getElementById("Day3Lo").innerHTML = weather.dayForecasts[3].low;
}