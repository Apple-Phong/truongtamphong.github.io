var screenWidth;
var iPhoneType = "auto";
if (iPhoneType == "auto") {
if (screen.height == 780) {

iPhoneType = "iPhMini";
} //iPh12Mini

else if (screen.height == 812) {
iPhoneType = "iPhX11P";
} //iPhX, iPhXS, iPh11Pro

else if (screen.height == 844) {
iPhoneType = "iPh12P";
} //iPh12 & iPh12Pro

else if (screen.height == 896) {
iPhoneType = "iPh11M";
} //iPhXR, iPhXSMAX, iPh11 & iPh11ProMax

else if (screen.height == 926) {
iPhoneType = "iPh12M";
} //iPh12max

else if (screen.height == 1024) {
iPhoneType = "iPadP";
} //Original and 9.6" iPads in PortraitMode
else {
iPhoneType = "iPh12P";
  } //iPh12ProMax
}

window.addEventListener("load", function () {
switch (iPhoneType) {
case "iPhMini":
document.body.style.width = '360px';
document.body.style.height = '780px';
screenWidth = 360;
$(".TwelveSix, .NineThree").css({ "font-size":"10px"});
$("#Weekday, #AlMonth").css({ "font-size":"11px"});
$("#Date, #AlDate").css({ "font-size":"33px"});
$("#CalArrow").css({ "font-size":"11px"});
$("#Percentage, #WeArrow").css({ "font-size":"12px"});
$(".Twelve, #Wind, #WindIcon, #HumiIcon, #Humi, #Rain, #RainIcon, #FeelsLike, #FeelsLikeIcon, #Sunrise, #SinriseIcon, #Sunset, #SunsetIcon, #HiLo, #FreeRAM, #Prev, #Next, #Day1Hi, #Day2Hi, #Day3Hi, #In").css({ "font-size":"9px"});
$("#Temp").css({ "font-size":"17px"});
$("#PlayPause").css({ "font-size":"13px"});
$("#Artist").css({ "margin-top":"12px"});
$("#Title, #Day1, #Day2, #Day3").css({ "font-size":"8px"});
$("#RamIcon").css({ "font-size":"22px"});
break;

case "iPhX11P":
document.body.style.width = '375px';
document.body.style.height = '812px';
screenWidth = 375;
$(".TwelveSix, .NineThree").css({ "font-size":"10px"});
$("#Weekday, #AlMonth").css({ "font-size":"11px"});
$("#Date, #AlDate").css({ "font-size":"33px"});
$("#CalArrow").css({ "font-size":"11px"});
$("#Percentage, #WeArrow").css({ "font-size":"12px"});
$(".Twelve, #Wind, #WindIcon, #HumiIcon, #Humi, #Rain, #RainIcon, #FeelsLike, #FeelsLikeIcon, #Sunrise, #SinriseIcon, #Sunset, #SunsetIcon, #HiLo, #FreeRAM, #Prev, #Next, #Day1Hi, #Day2Hi, #Day3Hi, #In").css({ "font-size":"9px"});
$("#Temp").css({ "font-size":"17px"});
$("#PlayPause").css({ "font-size":"13px"});
$("#Artist").css({ "margin-top":"12px"});
$("#Title, #Day1, #Day2, #Day3").css({ "font-size":"8px"});
$("#RamIcon").css({ "font-size":"22px"});
break;

case "iPh12P":
document.body.style.width = '390px';
document.body.style.height = '844px';
screenWidth = 390;
$(".TwelveSix, .NineThree").css({ "font-size":"10px"});
$("#Weekday, #AlMonth").css({ "font-size":"11px"});
$("#Date, #AlDate").css({ "font-size":"33px"});
$("#CalArrow").css({ "font-size":"11px"});
$("#Percentage, #WeArrow").css({ "font-size":"12px"});
$(".Twelve, #Wind, #WindIcon, #HumiIcon, #Humi, #Rain, #RainIcon, #FeelsLike, #FeelsLikeIcon, #Sunrise, #SinriseIcon, #Sunset, #SunsetIcon, #HiLo, #FreeRAM, #Prev, #Next, #Day1Hi, #Day2Hi, #Day3Hi, #In").css({ "font-size":"9px"});
$("#Temp").css({ "font-size":"17px"});
$("#PlayPause").css({ "font-size":"13px"});
$("#Artist").css({ "margin-top":"12px"});
$("#Title, #Day1, #Day2, #Day3").css({ "font-size":"8px"});
$("#RamIcon").css({ "font-size":"22px"});
break;

case "iPh11M":
document.body.style.width = '414px';
document.body.style.height = '896px';
screenWidth = 414;
break;

case "iPh12M":
document.body.style.width = '428px';
document.body.style.height = '926px';
screenWidth = 428;
break;

case "iPadP":
document.body.style.width = '768px';
document.body.style.height = '1365px';
screenWidth = 768;
break;

case "editMode":
document.body.style.width = '500px';
document.body.style.height = '1082px';
screenWidth = 500;
break;
  }
}, false);