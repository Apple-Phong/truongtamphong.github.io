function checkMusic(newData) {
document.getElementById('YouTube').src = newData.nowPlaying.artwork.length > 0 ? newData.nowPlaying.artwork : 'Scripts/Js/Blank.js';

if (isplaying === 1) {
document.getElementById('Album').style.animation = 'fading 1s linear 1 forwards';
document.getElementById('YouTube').style.animation = 'fading 1s linear 1 forwards';
document.getElementById('Scenery').style.display = 'none';
document.getElementById('PlayPause').classList.remove("ButtonPlay");		document.getElementById('PlayPause').classList.add("ButtonPause");
} else {
document.getElementById('Album').style.animation = '';
document.getElementById('YouTube').style.animation = '';
document.getElementById('Scenery').style.display = '';
document.getElementById('PlayPause').classList.remove("ButtonPause");		document.getElementById('PlayPause').classList.add("ButtonPlay");
}

if (title === "(null)") {
document.getElementById('Title').innerHTML = titletext;
} else {
document.getElementById('Title').innerHTML = title;

if (checkOverflow(document.getElementById('Title')) === true) {
document.getElementById('Title').classList.add("Marquee");
} else {
document.getElementById('Title').classList.remove("Marquee");
}
}

if (album === "(null)") {
document.getElementById('Album').src = 'Scripts/Js/Blank.js';
} else {		
var xhr = new XMLHttpRequest();
xhr.open('HEAD', "file:///var/mobile/Documents/Artwork.jpg", false);
xhr.send();

if (xhr.status === "404") {
document.getElementById('Album').src = 'Scripts/Js/Blank.js';
} else {
document.getElementById('Album').src = "file:///var/mobile/Documents/Artwork.jpg?" + (new Date()).getTime(); }
}
}

function checkOverflow(el) {
var curOverflow = el.style.overflow;
if ( !curOverflow || curOverflow === "visible" ) {
el.style.overflow = "none"; 
}

var isOverflowing = el.clientWidth < el.scrollWidth;
el.style.overflow = curOverflow;
return isOverflowing; 
}

function XenApi() {
api.media.observeData(function (newData) {
appPlaying = newData.nowPlayingApplication.identifier;
checkMusic(newData);});
}

function HDP() {
XenApi();
}

function openApp(app) {
api.apps.launchApplication(app);
}

function playPause() {
window.location = 'xeninfo:playpause';
document.getElementById('PlayBg').style.opacity = 0.4;
document.getElementById('PlayPause').style.opacity = 0.4;
setTimeout(function () {
document.getElementById('PlayBg').style.opacity = 1;
document.getElementById('PlayPause').style.opacity = 1;
}, 200);
}
		
function next() {
window.location = 'xeninfo:nexttrack';
document.getElementById('Album').style.animation = 'fadingout 1s linear 1 forwards';
document.getElementById('YouTube').style.animation = 'fadingout 1s linear 1 forwards';
document.getElementById('NextBg').style.opacity = 0.4;
document.getElementById('Next').style.opacity = 0.4;
setTimeout(function () {
document.getElementById('NextBg').style.opacity = 1;
document.getElementById('Next').style.opacity = 1;
}, 200);
}
			
function prev() {
window.location = 'xeninfo:prevtrack';
document.getElementById('Album').style.animation = 'fadingout 1s linear 1 forwards';
document.getElementById('YouTube').style.animation = 'fadingout 1s linear 1 forwards';
document.getElementById('PrevBg').style.opacity = 0.4;
document.getElementById('Prev').style.opacity = 0.4;
setTimeout(function () {
document.getElementById('PrevBg').style.opacity = 1;
document.getElementById('Prev').style.opacity = 1;
}, 200);
}

window.addEventListener("load", HDP, false);