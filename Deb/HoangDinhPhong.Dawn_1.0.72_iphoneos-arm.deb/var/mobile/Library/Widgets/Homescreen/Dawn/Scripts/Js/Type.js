var iPhoneType = "auto";
if (iPhoneType == "auto") {
if (screen.height == 667) { iPhoneType = "iPh678"; }
else if (screen.height == 736) { iPhoneType = "iPh678Plus"; }
else if (screen.height == 780) { iPhoneType = "iPhMini"; }
else if (screen.height == 812) { iPhoneType = "iPhX"; }
else if (screen.height == 896) { iPhoneType = "iPhMax"; }
else if (screen.height == 844) { iPhoneType = "iPh12Pro"; }
else if (screen.height == 926) { iPhoneType = "iPh12Max"; }
}

window.addEventListener("load", function() { 
switch(iPhoneType) {

case "iPh678":
document.body.style.width='375px';
document.body.style.height='667px';
$("#TimeCont").css({ "top":"6.3%", "width":"59%", "height":"4.8%" });
$("#Clock").css({ "font-size":"36px" });
$("#Calendar").css({ "font-size":"12px" });
$("#City").css({ "font-size":"10px" });
$("#AvaCont").css({ "top":"2.5%", "right":"1.5%", "height":"63px", "width":"63px" });
$("#WallCont").css({ "top":"13%", "height":"23%" });
$("#WallSh").css({ "top":"13.7%", "height":"21.7%" });
$("#AppsCont").css({ "top":"38.5%", "height":"31.4%" });
$("#PrevCont, #NextCont").css({ "height":"26px", "width":"26px" });
$("#PlayCont").css({ "height":"36px", "width":"36px" });
$("#PlayPause").css({ "font-size":"17px" });
$("#Prev, #Next").css({ "font-size":"10px" });
$("#Dock").css({ "bottom":"1%" });
$("#Charging").css({ "bottom":"0%", "left":"54.5%", "font-size":"7px" });
$("#Percentage").css({ "bottom":"-0.3%", "font-size":"10px", "z-index":"1" });
$("#Playback-time::-webkit-progress-bar").css({ "height":"36px" });
break;

case "iPh678Plus":
document.body.style.width='414px';
document.body.style.height='736px';
$("#TimeCont").css({ "top":"6.3%", "height":"4.8%" });
$("#Clock").css({ "font-size":"42px" });
$("#AvaCont").css({ "top":"2.5%", "right":"1.5%", "height":"63px", "width":"63px" });
$("#WallCont").css({ "top":"13%", "height":"23%" });
$("#WallSh").css({ "top":"13.7%", "height":"21.7%" });
$("#AppsCont").css({ "top":"38.5%", "height":"31.4%" });
$("#PrevCont, #NextCont").css({ "height":"30px", "width":"30px" });
$("#PlayCont").css({ "height":"40px", "width":"40px" });
$("#PlayPause").css({ "font-size":"18px" });
$("#Prev, #Next").css({ "font-size":"11px" });
$("#Dock").css({ "bottom":"1%" });
$("#Charging").css({ "bottom":"0%", "left":"54%", "font-size":"7px" });
$("#Percentage").css({ "bottom":"-0.3%", "font-size":"10px", "z-index":"1" });
break;

case "iPhMini":
document.body.style.width = '360px';
document.body.style.height = '780px';
$("#Clock").css({ "font-size":"38px" });
$("#AvaCont").css({ "top":"5%", "right":"1.5%", "height":"63px", "width":"63px" });
$("#PrevCont, #NextCont").css({ "height":"26px", "width":"26px" });
$("#PlayCont").css({ "height":"36px", "width":"36px" });
$("#PlayPause").css({ "font-size":"17px" });
$("#Prev, #Next").css({ "font-size":"10px" });
$("#Charging").css({ "font-size":"9px" });
$("#Percentage").css({ "bottom":"0%", "font-size":"10px" });
break;

case "iPhX":
document.body.style.width='375px';
document.body.style.height='812px';
$("#Clock").css({ "font-size":"38px" });
$("#AvaCont").css({ "top":"5%", "height":"66px", "width":"66px" });
$("#PrevCont, #NextCont").css({ "height":"31px", "width":"31px" });
$("#PlayCont").css({ "height":"38px", "width":"38px" });
$("#PlayPause").css({ "font-size":"17px" });
$("#Prev, #Next").css({ "font-size":"12px" });
$("#Charging").css({ "font-size":"9px" });
$("#Percentage").css({ "bottom":"0%", "font-size":"10px" });
break;

case "iPhMax":
document.body.style.width='414px';
document.body.style.height='896px';
break;

case "iPh12Pro":
document.body.style.width='390px';
document.body.style.height='844px';
$("#Clock").css({ "font-size":"39px" });
$("#AvaCont").css({ "top":"5%", "height":"68px", "width":"68px" });
$("#PrevCont, #NextCont").css({ "height":"33px", "width":"33px" });
$("#PlayCont").css({ "height":"43px", "width":"43px" });
$("#PlayPause").css({ "font-size":"19px" });
$("#Prev, #Next").css({ "font-size":"13px" });
$("#Charging").css({ "font-size":"9px" });
$("#Percentage").css({ "bottom":"0%", "font-size":"10px" });
break;

case "iPh12Max":
document.body.style.width='428px';
document.body.style.height='926px';
break;
}
}, false);