function mainUpdate(type) {
if (type === "battery") { updateBattery(); }
if (type === "weather") { checkWeather(); } 
}

function checkWeather() {
document.getElementById("City").innerHTML = weather.city + ' | ' + weather.temperature + "&deg";
}