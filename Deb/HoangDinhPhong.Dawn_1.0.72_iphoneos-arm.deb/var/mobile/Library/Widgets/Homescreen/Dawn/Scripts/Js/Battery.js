function updateBattery() {
document.getElementById("Percentage").innerHTML = batteryPercent + '%';
document.getElementById("Bl2").style.width = batteryPercent + "%";
document.getElementById("Charging").innerHTML = (batteryCharging) ? charging : notcharging;
}