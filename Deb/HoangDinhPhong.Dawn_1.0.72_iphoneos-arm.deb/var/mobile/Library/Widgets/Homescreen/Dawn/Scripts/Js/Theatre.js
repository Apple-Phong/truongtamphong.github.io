! function (t) {
   var e, i = {},
      a = {};
   t.fn.theatre = function () {
      var e = arguments;
      return this.css({
         visibility: "visible",
         display: "block"
      }), (this.length ? this : t(document)).each(function () {
         a.initAll.apply(t(this), e)
      }), this
   }, t.fn.theatre.cssSupport = function (e, i) {
      var a, n = !1,
         s = (document.body || document.documentElement).style,
         r = e.substr(0, 1).toUpperCase() + e.substr(1),
         o = [e, "Moz" + r, "Webkit" + r, "ms" + r, "O" + r];
      for (a = 0; a < o.length; a++)
         if (void 0 !== s[o[a]]) {
            n = !0;
            break
         } if (i && n) {
         var h, c = t("<div class='theatreCSSCompatDummy' style='width:1px; height: 1px; position: absolute; bottom: 0px; opacity: 0;'></div>").appendTo("body"),
            l = !1;
         for (s = c.get(0).style, a = 0; a < o.length; a++)
            if (void 0 !== s[o[a]] && (h = {}, h[o[a]] = i, c.css(h), s[o[a]] == i)) {
               l = !0;
               break
            } c.remove(), n = n && l
      }
      return n
   }, a.loadEffect = function (a) {
      e || t('script[src*="jquery.theatre.js"], script[src*="jquery.theatre.min.js"], link[href*="theatre.css"]').first().each(function () {
         e = (this.href || this.src).replace(/\/[^\/]*(#.*)?$/, "")
      });
      var n = e + "/effect." + a.split(":")[0] + ".js";
      return t("head").append('<script type="text/javascript" src="' + n + '"></script>'), i[a]
   }, a.buryDead = function (e) {
      return e.filter(function () {
         return t(this).get(0).parentNode
      })
   }, a.initAll = function (e) {
      if ("object" == typeof e || !e || "init" == e) {
         var n = this.is(document) || a.init.apply(this, arguments);
         return this.trigger("theatreReady", [this]), n
      }
      if ("effect" == e) {
         if ("function" == typeof arguments[2]) return i[arguments[1]] = arguments[2];
         t.error("Elixon Theatre cannot register effect object unless it is a Function.")
      } else if (this.is(document)) return !1;
      var s = this.data("theatre");
      if (!s) return !1;
      var r = arguments[1],
         o = !1;
      switch (e) {
         case "iterate":
            o = !0, e = s.settings.playDir;
         case "next":
         case "prev":
         case "redraw":
            r = e;
         case "jump":
            var h = 0;
            switch (r) {
               case "redraw":
                  r = s.index, h = 1;
                  break;
               case "first":
                  r = 0;
                  break;
               case "last":
                  r = s.actors.length - 1;
                  break;
               case "next":
                  r = (s.index + s.actors.length + 1) % s.actors.length;
                  break;
               case "prev":
                  r = (s.index + s.actors.length - 1) % s.actors.length;
                  break;
               default:
                  r = (parseInt(arguments[1]) - 1) % s.actors.length, r = (Math.abs(Math.floor(r / s.actors.length) * s.actors.length) + r) % s.actors.length
            }
            if (!h && r == s.index) break;
            "undefined" != typeof arguments[2] && ("undefined" == typeof s.settings.speedOrig && (s.settings.speedOrig = s.settings.speed), s.settings.speed = arguments[2]);
            var c = s.index;
            for (o || this.theatre("stop");
               (h || s.index != r) && (h = 0, r = a.onMove.apply(this, [r]), -1 != r);) {
               if (s.effect.jump) s.index = r, s.effect.jump.apply(s.effect, [c]);
               else {
                  if (s.index < r) var l = r - s.index,
                     f = s.index + s.actors.length - r;
                  else var f = s.index - r,
                     l = s.actors.length + r - s.index;
                  var p = s.index;
                  s.index = (s.index + (f > l ? 1 : -1) + s.actors.length) % s.actors.length;
                  var d = f > l || p + 1 == s.index ? "next" : "prev";
                  s.effect[d].apply(s.effect, [c])
               }
               if (s.index == c) break;
               c = s.index, a.updatePaging.apply(this)
            }
            "undefined" != typeof s.settings.speedOrig && (s.settings.speed = s.settings.speedOrig), this.attr("actors-count", s.actors.length).attr("position-ord", s.index + 1).attr("position", s.index + 1 == s.actors.length ? "last" : s.index || "first");
            break;
         case "play":
         case "destroy":
         case "stop":
            a[e].apply(this);
            break;
         default:
            t.error('Elixon Theatre method "' + e + '" does not exist on jQuery.theatre!')
      }
   }, a.init = function (e) {
      a.destroy.apply(this);
      var n = {
         selector: "> *:not(.theatre-control)",
         effect: "horizontal",
         speed: 1e3,
         still: 3e3,
         autoplay: !0,
         playDir: "next",
         controls: "horizontal",
         itemWidth: !1,
         itemHeight: !1,
         width: !1,
         height: !1,
         onMove: !1,
         onAfterMove: function () {},
         random: !1
      };
      if (e && t.extend(n, e), n.random)
         for (var s = t("> *", this).get(); s.length;) {
            var r = Math.floor(Math.random() * s.length),
               o = s[r];
            s.splice(r, 1), o.parentNode.appendChild(o)
         }
      var h, c = t(n.selector, this),
         l = {
            paging: n.paging && t(n.paging),
            actors: c,
            effect: !1,
            settings: n,
            interval: !1,
            index: 0,
            methods: a
         };
      switch (typeof n.effect) {
         case "string":
            h = n.effect.split(/\s+/);
            break;
         case "function":
            h = [n.effect]
      }
      for (var f, p = 0; p < h.length && !l.effect; p++)
         if (n.effect = h[p], f = "function" == typeof n.effect ? n.effect : i[n.effect] ? i[n.effect] : a.loadEffect(n.effect), f || t.error('Elixon Theatre does not support effect "' + n.effect + '"!'), l.effect = new i[n.effect](this, c, n, l), "function" == typeof l.effect.capable) {
            var d = l.effect.capable();
            d !== !0 && ("function" == typeof l.effect.destroy && l.effect.destroy(), l.effect = null, t(this).addClass("theatre-failover"), 1 == h.length && h.push(d || n.effect))
         } this.addClass("theatre").data("theatre", l), this.addClass("theatre-" + n.effect.replace(/[^a-z0-9]+/gi, "-")), n.width && this.css("width", n.width), n.height && this.css("height", n.height);
      var r = 0;
      if (c.each(function () {
            var e = t(this),
               i = r++,
               a = function () {
                  return {
                     width: e.width(),
                     height: e.height(),
                     index: i
                  }
               };
            e.is(".theatre-actor-active") && (l.index = i), e.data("theatre") || e.data("theatre", a()), e.load(function () {
               e.data("theatre", a())
            })
         }), n.itemWidth || n.itemHeight) {
         var u = this;
         c.each(function () {
            var e = t(this);
            n.itemWidth && e.css("width", "max" == n.itemWidth ? u.width() - e.outerWidth() + e.width() + "px" : n.itemWidth), n.itemHeight && e.css("height", "max" == n.itemHeight ? u.height() - e.outerHeight() + e.height() + "px" : n.itemHeight)
         })
      }
      this.attr("actors-count", l.actors.length).attr("position-ord", 1).attr("position", "first"), c.addClass("theatre-actor").stop(!0, !0), c.first().addClass("theatre-actor-first"), c.last().addClass("theatre-actor-last"), l.effect.init(), n.autoplay && a.play.apply(this, [!0]), a.appendControls.apply(this), a.generatePaging.apply(this), a.onMove.apply(this, [l.index]), a.onAfterMove.apply(this), a.swipeSupport.apply(this)
   }, a.onMove = function (e) {
      if (isNaN(e)) return -1;
      var i = this.data("theatre");
      i.actors.not(i.actors[e]).removeClass("theatre-actor-active"), t(i.actors[e]).addClass("theatre-actor-active");
      var a = e;
      return "function" == typeof i.settings.onMove ? (i.settings.onMove.apply(this, [e, i.actors[e], i]), "number" == typeof a ? a %= i.actors.length : a = a === !1 ? -1 : e) : a >= 0 && this.trigger("theatreMove", [a, i.actors[a], i]), a
   }, a.onAfterMove = function () {
      var t = this.data("theatre");
      return "function" != typeof t.settings.onAfterMove ? !1 : (t.settings.onAfterMove.apply(this, [t.index, t.actors[t.index], t]), !0)
   }, a.generatePaging = function () {
      var e = this,
         i = this.data("theatre");
      i.paging && (i.paging.each(function () {
         var a = t(this),
            n = a.data("theatrePagingTemplate");
         n ? a.html(n) : a.data("theatrePagingTemplate", a.html());
         var s = [];
         t("> *", a).each(function () {
            s.push(t("<div></div>").append(this).html())
         });
         for (var r = s[s.length - 1], o = 0; o < i.actors.length; o++) {
            var h = s.length < o + 1 ? r : s[o];
            ! function (t) {
               a.append(h.replace("{#}", t)), a.children().last().off(".theatre").on("click.theatre", function () {
                  e.theatre("jump", t)
               }).after(o < i.actors.length - 1 ? '<nobr class="theatre-spacer"> </nobr>' : "")
            }(o + 1)
         }
      }), a.updatePaging.apply(this))
   }, a.updatePaging = function () {
      var e = this.data("theatre");
      e.paging && e.paging.each(function () {
         var i = t(this);
         t("> *:not(.theatre-spacer)", i).removeClass("active").eq(e.index).addClass("active")
      })
   }, a.swipeSupport = function () {}, a.appendControls = function () {
      if (settings = this.data("theatre").settings, "horizontal" == settings.controls || "vertical" == settings.controls) {
         var e = this;
         this.append('<a class="theatre-control theatre-control-' + settings.controls + '-next theatre-next"><span></span></a>'), this.append('<a class="theatre-control theatre-control-' + settings.controls + '-prev theatre-prev"><span></span></a>'), this.append('<a class="theatre-control theatre-control-' + settings.controls + '-play theatre-play"><span></span></a>'), this.append('<a class="theatre-control theatre-control-' + settings.controls + '-stop theatre-stop"><span></span></a>'), t(".theatre-next", this).click(function () {
            e.theatre("next")
         }), t(".theatre-prev", this).click(function () {
            e.theatre("prev")
         }), t(".theatre-play", this).click(function () {
            e.theatre("play")
         }), t(".theatre-stop", this).click(function () {
            e.theatre("stop")
         }), this.mouseenter(function () {
            t(".theatre-control", e).fadeIn()
         }), this.mouseleave(function () {
            t(".theatre-control", e).fadeOut()
         }), t(".theatre-control", this).fadeOut(0)
      }
      this.append('<a class="theatre-control theatre-sign" rel="copyright license" style="position: absolute !important; display: none !important;" href="http://www.webdevelopers.eu/jquery/theatre" title="jQuery carousel plugin"><span style="display: none !important;">Elixon Theatre jQuery Plugin</span></a>')
   }, a.destroy = function () {
      var e = this.data("theatre");
      if (e) {
         clearInterval(e.interval);
         try {} catch (i) {}
         "function" == typeof e.effect.destroy && e.effect.destroy(), this.removeClass("theatre-" + e.settings.effect.replace(/[^a-z0-9]+/gi, "-")), e.actors.each(function () {
            var e = t(this),
               i = e.data("theatre");
            try {
               e.width(i.width), e.height(i.height)
            } catch (a) {}
         })
      }
      t(".theatre-control", this).remove()
   }, a.play = function (t) {
      var e = this.data("theatre"),
         i = this;
      i.theatre("stop"), !t && i.theatre("iterate"), e.interval = setInterval(function () {
         i.theatre("iterate")
      }, e.settings.speed + e.settings.still)
   }, a.stop = function () {
      var t = this.data("theatre");
      clearInterval(t.interval), t.interval = !1
   }, i.fade = i.slide = i.show = function (t, e, i, n) {
      var s = function () {
            a.onAfterMove.apply(t)
         },
         r = {
            fade: {
               show: "fadeIn",
               hide: "fadeOut",
               initStyle: {
                  margin: 0,
                  top: 0,
                  left: 0,
                  position: "absolute",
                  display: "none"
               }
            },
            slide: {
               show: "slideDown",
               hide: "slideUp",
               initStyle: {}
            },
            show: {
               show: "show",
               hide: "hide",
               initStyle: {}
            }
         } [i.effect];
      this.init = function () {
         e[r.hide](0).css(r.initStyle).eq(n.index)[r.show](0)
      }, this.next = function () {
         e.stop(!0, !0).css("z-index", 0)[r.hide](i.speed).eq(n.index).css("z-index", 10)[r.show](i.speed, s)
      }, this.prev = function () {
         e.stop(!0, !0).css("z-index", 0)[r.hide](i.speed).eq(n.index).css("z-index", 10)[r.show](i.speed, s)
      }, this.destroy = function () {
         e = a.buryDead(e), e.stop(!0, !0).css({
            zIndex: "",
            top: "",
            left: "",
            position: "",
            margin: ""
         })[r.show](0)
      }
   }, i.vertical = i.horizontal = function (e, i, n, s) {
      var r = function () {
            a.onAfterMove.apply(e)
         },
         o = {
            horizontal: {
               size: "outerWidth",
               direction: "left"
            },
            vertical: {
               size: "outerHeight",
               direction: "top"
            }
         } [n.effect];
      this.init = function () {
         e.scroll(function () {
            e.scrollTop(0).scrollLeft(0)
         }), i.fadeOut(0), this.align(0, 0), i.fadeIn()
      }, this.prev = function () {
         var i = t(n.selector, e).last(),
            a = i.parentsUntil(".theatre");
         (a.length ? a : i).last().prependTo(e), i.stop(!0, !0).css(o.direction, -i[o.size](!0)), this.align(0)
      }, this.next = function () {
         var i = t(n.selector, e).first(),
            a = (this.align(-i[o.size](!0)), i.parentsUntil(".theatre"));
         a = (a.length ? a : i).last(), a.appendTo(e)
      }, this.destroy = function () {
         i = a.buryDead(i), i.stop(!0, !0).css(o.direction, "").css({
            opacity: "",
            left: "",
            top: ""
         }), i.each(function () {
            t(this).appendTo(e)
         })
      }, this.align = function (i, a) {
         return e.scrollLeft(0).scrollTop(0), t(n.selector, e).each(function () {
            var e = t(this),
               h = s.index == e.data("theatre").index ? r : function () {},
               c = h;
            0 > i && (c = function () {
               e.css(o.direction, i), h()
            });
            var l = {};
            l[o.direction] = i, e.stop(!0, !0).animate(l, isNaN(a) ? n.speed : a, c), i += e[o.size](!0)
         }), i
      }
   }, i["3d"] = function (e, i, n, s) {
      var r = function () {
         a.onAfterMove.apply(e)
      };
      n.resize = !1;
      var o, h, c = [],
         l = {};
      this.init = function () {
         l.overflow = e.css("overflow"), e.css("overflow", "visible"), o = .5 * e.width(), h = .8 * e.height(), i.each(function (t) {
            var a = 2 * Math.PI * -t / i.length + Math.PI / 2,
               n = Math.cos(a),
               s = Math.sin(a);
            s = 1 - 2 * Math.sqrt((1 - s) / 2);
            var r = 10,
               o = .2,
               h = (s + 1) / 2 * (1 - o) + o,
               l = n * (e.width() - r) / 2 + e.width() / 2,
               f = s * (e.height() - r) / 2 + e.height() / 2;
            c.push({
               left: l,
               top: f,
               x: n,
               y: s,
               size: h,
               rad: a
            })
         }), this.animate()
      }, this.next = function () {
         this.animate()
      }, this.prev = function () {
         this.animate()
      }, this.destroy = function () {
         i.stop(!0, !0).css({
            "z-index": "",
            opacity: "",
            left: "",
            top: ""
         }), e.css("overflow", l.overflow)
      }, this.animate = function () {
         var e = this;
         i.stop(), i.each(function (a) {
            try {
               var l = c[(a - s.index + i.length) % i.length],
                  f = e.calcDim(t(this), o, h, l.size),
                  p = Math.round(l.left - l.x * f[0] / 2 - f[0] / 2),
                  d = Math.round(l.top - l.y * f[1] / 2 - f[1] / 2);
               t(this).css({
                  "z-index": Math.round(1e3 * l.size)
               }).animate({
                  opacity: l.size,
                  left: p,
                  top: d,
                  width: f[0],
                  height: f[1]
               }, n.speed, a == s.index ? r : null)
            } catch (u) {}
         })
      }, this.calcDim = function (t, e, i, a) {
         var n = t.data("theatre"),
            s = e,
            r = n.height / n.width * s;
         return r > i && (s = e * (i / r), r = i), [Math.round(s * a), Math.round(r * a)]
      }
   };
   var n = "W3-181013-142028";
   if (n.match(/^W3/)) {
      var s = "%45%6C%69%78%6F%6E%20%54%68%65%61%74%72%65%20%74%72%69%61%6C%20%76%65%72%73%69%6F%6E%20%68%61%73%20%65%78%70%69%72%65%64%21%20%43%6C%69%63%6B%20%4F%4B%20%74%6F%20%6F%62%74%61%69%6E%20%74%68%65%20%66%75%6C%6C%20%76%65%72%73%69%6F%6E%2E",
         r = new Date(n.replace(/^W(\d)-(\d{2})(\d{2})(\d{2})-(\d{2})(\d{2})(\d{2})$/, "20$2-$3-$4T$5:$6:$7Z")),
         o = ["co", "nfi", "rm"];
      r.setTime(r.getTime() + 999999999999999999999999999999999999), r.getTime() && r.getTime() < (new Date).getTime() && window[o.join("")](unescape(s)) && (window.location = "http://www.webdevelopers.eu/jquery/theatre/buy?trial=expired")
   }
}(jQuery);