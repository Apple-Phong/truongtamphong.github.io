$(window).load(function() {$('#Scenery').theatre({ 'speed' : 1, 'still' : config.imageTime })
});