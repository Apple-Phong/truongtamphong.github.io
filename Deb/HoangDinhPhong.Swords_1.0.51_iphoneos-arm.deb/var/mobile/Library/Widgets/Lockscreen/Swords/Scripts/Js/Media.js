function checkMusic(newData) {
document.getElementById('Ytb').src = newData.nowPlaying.artwork.length > 0 ? newData.nowPlaying.artwork : 'Scripts/Images/Album.jpg';

if (isplaying === 1) {
document.getElementById('Album').style.animation = '';
document.getElementById('Ytb').style.animation = '';
document.getElementById('AlbumImg').style.animation = 'fadingout 1s linear 1 forwards';
document.getElementById('PlayPause').classList.remove("ButtonPlay");
document.getElementById('PlayPause').classList.add("ButtonPause");
} else {
document.getElementById('Album').style.animation = 'fadingout 1s linear 1 forwards';
document.getElementById('Ytb').style.animation = 'fadingout 1s linear 1 forwards';
document.getElementById('AlbumImg').style.animation = '';
document.getElementById('PlayPause').classList.remove("ButtonPause");	document.getElementById('PlayPause').classList.add("ButtonPlay");
}

if (album === "(null)") {
document.getElementById('Album').src = 'Scripts/Images/Album.jpg';
} else {		
var xhr = new XMLHttpRequest();
xhr.open('HEAD', "file:///var/mobile/Documents/Artwork.jpg", false);
xhr.send();

if (xhr.status === "404") {
document.getElementById('Album').src = 'Scripts/Images/Album.jpg';
} else {
document.getElementById('Album').src = "file:///var/mobile/Documents/Artwork.jpg?" + (new Date()).getTime(); }
}
}

function checkOverflow(el) {
var curOverflow = el.style.overflow;
if (!curOverflow || curOverflow === "visible") {
el.style.overflow = "none"; 
}

var isOverflowing = el.clientWidth < el.scrollWidth;
el.style.overflow = curOverflow;
return isOverflowing; 
}

function XenApi() {
api.media.observeData(function (newData) {
appPlaying = newData.nowPlayingApplication.identifier;
checkMusic(newData); });
}

function HDP() {
XenApi();
}

function playPause() {
window.location = 'xeninfo:playpause';
document.getElementById('PlayPause').style.opacity = 0;
setTimeout(function () {
document.getElementById('PlayPause').style.opacity = 0;
}, 200);
}
		
function next() {
window.location = 'xeninfo:nexttrack';
document.getElementById('Album').style.animation = 'fadingout 1s linear 1 forwards';
document.getElementById('Ytb').style.animation = 'fadingout 1s linear 1 forwards';
document.getElementById('Next').style.opacity = 0;
setTimeout(function () {
document.getElementById('Next').style.opacity = 0.5;
}, 200);
}
			
function prev() {
window.location = 'xeninfo:prevtrack';
document.getElementById('Album').style.animation = 'fadingout 1s linear 1 forwards';
document.getElementById('Ytb').style.animation = 'fadingout 1s linear 1 forwards';
document.getElementById('Prev').style.opacity = 0;
setTimeout(function () {
document.getElementById('Prev').style.opacity = 0.5;
}, 200);
}

window.addEventListener("load", HDP, false);