var iPhoneType = "auto";
if (iPhoneType == "auto") {
if (screen.height == 780) { iPhoneType = "iPhMini"; }
else if (screen.height == 812) { iPhoneType = "iPhX"; }
else if (screen.height == 896) { iPhoneType = "iPhMax"; }
else if (screen.height == 844) { iPhoneType = "iPh12Pro"; }
else if (screen.height == 926) { iPhoneType = "iPh12Max"; }
}

window.addEventListener("load", function() { 
switch(iPhoneType) {

case "iPhMini":
document.body.style.width = '360px';
document.body.style.height = '780px';
screenWidth = 360;
$("#WeekdayCont").css({ "width":"23px", "height":"23px" });
$("#Weekday").css({ "font-size":"8px" });
$("#DateMonth").css({ "font-size":"24px" });
$("#Percent").css({ "right":"12.7%" });
$("#AlCont").css({ "height":"12.5%" });
$("#AlDate").css({ "font-size":"28px" });
$("#AlMonth").css({ "top":"2%", "font-size":"10px" });
$("#AlYear").css({ "bottom":"-2%", "font-size":"10px" });
$("#WeInfo").css({ "font-size":"10px" });
$("#AlbumCont").css({ "width":"115px", "height":"115px" });
break;

case "iPhX":
document.body.style.width='375px';
document.body.style.height='812px';
$("#WeekdayCont").css({ "width":"23px", "height":"23px" });
$("#Weekday").css({ "font-size":"8px" });
$("#DateMonth").css({ "font-size":"24px" });
$("#Percent").css({ "right":"12.2%" });
$("#AlCont").css({ "height":"12.5%" });
$("#AlDate").css({ "font-size":"28px" });
$("#AlMonth").css({ "top":"2%", "font-size":"10px" });
$("#AlYear").css({ "bottom":"-2%", "font-size":"10px" });
$("#WeInfo").css({ "font-size":"10px" });
$("#AlbumCont").css({ "width":"115px", "height":"115px" });
$("#Flash").css({ "left":"7.5%" });
$("#Cam").css({ "right":"7.5%" });
break;

case "iPhMax":
document.body.style.width='414px';
document.body.style.height='896px';
break;

case "iPh12Pro":
document.body.style.width='390px';
document.body.style.height='844px';
$("#Percent").css({ "right":"11.8%" });
$("#AlMonth").css({ "top":"-3%" });
$("#AlYear").css({ "bottom":"-4%" });
$("#AlbumCont").css({ "width":"120px", "height":"120px" });
break;

case "iPh12Max":
document.body.style.width='428px';
document.body.style.height='926px';
$("#Percent").css({ "right":"10.8%" });
$("#AlMonth").css({ "top":"2%" });
break;
}
}, false);