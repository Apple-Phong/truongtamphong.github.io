if (window.config.language == "Vietnamese") {
var altext = "Âm";
var motext = "Tháng";
var titletext = "Chưa phát";
var artisttext = "Không có nghệ sĩ";
var charging = "Đang sạc...";
var notcharging = "Chưa sạc";
var days = ["Chủ Nhật", "Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ bảy"];
var months = ["Tháng giêng", "Tháng hai", "Tháng ba", "Tháng tư", "Tháng năm", "Tháng sáu", "Tháng bảy", "Tháng tám", "Tháng chín", "Tháng mười", "Tháng mười một", "Tháng mười hai"];
}

if (window.config.language == "English") {
var altext = "Lunar";
var motext = "Month";
var titletext = "No Media Player";
var artisttext = "No Artist";
var charging = "Charging...";
var notcharging = "Not charged";
var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
}