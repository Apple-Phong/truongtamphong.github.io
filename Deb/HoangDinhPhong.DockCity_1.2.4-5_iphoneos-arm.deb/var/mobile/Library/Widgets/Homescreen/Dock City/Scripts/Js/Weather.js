function mainUpdate(type) {
if (type === "battery") { updateBattery(); 
document.getElementById("FreeRAM").innerHTML = freeRAMtxt + ' ' + ramFree + ' ' + 'MB'; }
if (type === "weather") { checkWeather(); }
}

function checkWeather() {
document.getElementById('WeIcon').src = 'Scripts/Weather/' + weather.conditionCode + '.png';
document.getElementById("City").innerHTML = weather.city;
document.getElementById("Temp").innerHTML = weather.temperature + '°';
}