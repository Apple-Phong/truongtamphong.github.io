function clock(options) {
var getTimes = function () {
var d = new Date(),
funcs = {

month: function () {
return d.getMonth();
}
};

options.success(funcs);
setTimeout(function () {
getTimes();
}, options.refresh);
};
getTimes();
}

clock({
refresh: 5000,
success:

function(clock){
document.getElementById('Month').innerHTML = months[clock.month()];
}
});