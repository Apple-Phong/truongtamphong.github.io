document.documentElement.style.setProperty('--scale', config.scale);

if (!config.monthWeekday) {
   document.querySelector('.Month').style.display = 'none';
   document.querySelector('.Weekday').style.display = 'block';
}