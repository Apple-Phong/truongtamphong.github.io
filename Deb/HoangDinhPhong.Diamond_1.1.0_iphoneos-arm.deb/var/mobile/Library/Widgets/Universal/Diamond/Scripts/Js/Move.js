var aniPath = function (id, speed) {
   var length = id.getTotalLength();
   id.style.transition = id.style.WebkitTransition =
      'none';
   id.style.strokeDasharray = length + ' ' + length;
   id.style.strokeDashoffset = length;
   id.getBoundingClientRect();
   id.style.transition = id.style.WebkitTransition =
      'stroke-dashoffset ' + speed + 's ease-in-out';
   id.style.strokeDashoffset = '0';
};
window.onload = function () {
   var svgbase = document.getElementById('Sv').getSVGDocument(),
      path, i;
   for (i = 1; i < 7; i++) {
      path = svgbase.getElementById('Path-' + i);
      aniPath(path, 2);
   }
};