function P() {
addLines();
updateClock();
setInterval("updateClock();", 5000);
}

function addLines() {
var i;
for (var i = 0; i < 60; i++) {
var tc = document.createElement('div');
tc.className = 'Thin-cir';
tc.style.transform = "rotate(" + 6 * i + "deg)";
tc.id = 'Cir' + i;
document.getElementById('DialCircles').appendChild(tc);
var tl = document.createElement('div');
tl.className = 'Thin-line';
tl.id = 'Tl' + i;
tl.style.transform = "rotate(" + 6 * i + "deg)";
document.getElementById('DialLines').appendChild(tl);
}

for (var j = 0; j < 12; j++) {
var n = document.createElement('div');
n.className = 'Num';
n.style.transform = "rotate(" + 30 * j + "deg)";
n.innerHTML = j;
n.id = 'Hour' + j;
      document.getElementById('DialNumbers').appendChild(n);
   }
}

window.addEventListener("load", P, false);