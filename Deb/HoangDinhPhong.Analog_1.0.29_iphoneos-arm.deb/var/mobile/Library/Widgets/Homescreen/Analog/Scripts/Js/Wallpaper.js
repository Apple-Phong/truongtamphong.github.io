document.getElementById('BgInput').addEventListener('change', function (e) {
var tw = e.target.files,
rd = new FileReader();
rd.onload = (function () {
return function (e) {
localStorage.analog = e.target.result;
         document.getElementById('Wallpaper').style.backgroundImage = 'url("' + localStorage.analog + '")';
tw = null;
rd = null;
};
}(tw[0]));
rd.readAsDataURL(tw[0]);
});

if (localStorage.analog && localStorage.analog != "null") {
document.getElementById('Wallpaper').style.backgroundImage = 'url("' + localStorage.analog + '")';
}