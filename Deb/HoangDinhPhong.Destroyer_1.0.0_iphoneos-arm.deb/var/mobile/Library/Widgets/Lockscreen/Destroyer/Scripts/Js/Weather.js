function mainUpdate(type) {
if (type === "weather") { checkWeather(); }
}

function checkWeather() {
document.getElementById('WeatherIcon').src = 'Scripts/Weather/' + weather.conditionCode + '.svg';
document.getElementById("WeInfo").innerHTML = weather.city + ' ' + condition[weather.conditionCode] + ' ' + weather.temperature + '°'  + '<br>' + humitext + ' ' + weather.humidity + '%' + '<br>' + windtext + ' ' + weather.windSpeed + ' km/h' + '<br>' + raintext + ' ' + weather.hourlyForecasts[0].percentPrecipitation + '%';
}