var action = {};
action.replaceElements = function () {

/*---------- Messenger ----------*/

action.Messenger = function (id) {
div = document.createElement('div');
div.id = id;
document.getElementById('MessengerCont').appendChild(div); return div; };

var Messenger = action.savedElements.Messenger;
Object.keys(Messenger).forEach(function (elementName) {
createdDiv = action.Messenger(elementName);
elementStyles = Messenger[elementName];
action.loadStyles(elementName, elementStyles, createdDiv); });

/*---------- Facebook ----------*/

action.Facebook = function (id) {
div = document.createElement('div');
div.id = id;
document.getElementById('FacebookCont').appendChild(div); return div; };

var Facebook = action.savedElements.Facebook;
Object.keys(Facebook).forEach(function (elementName) {
createdDiv = action.Facebook(elementName);
elementStyles = Facebook[elementName];
action.loadStyles(elementName, elementStyles, createdDiv); });

/*---------- YouTube ----------*/

action.YouTube = function (id) {
div = document.createElement('div');
div.id = id;
document.getElementById('YouTubeCont').appendChild(div); return div; };

var YouTube = action.savedElements.YouTube;
Object.keys(YouTube).forEach(function (elementName) {
createdDiv = action.YouTube(elementName);
elementStyles = YouTube[elementName];
action.loadStyles(elementName, elementStyles, createdDiv); });
};