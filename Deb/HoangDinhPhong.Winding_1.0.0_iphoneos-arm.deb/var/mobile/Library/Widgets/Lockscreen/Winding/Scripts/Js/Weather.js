function checkWeather() {
document.getElementById("WeInfo").innerHTML = wetext + ' ' + weather.city + '. ' + condition[weather.conditionCode] + '. ' + temptext + ' ' + weather.temperature + '°. ' + humitext + ' ' + weather.humidity + '%. ' + windtext + ' ' + weather.windSpeed + ' km/h. ' + hitext + ' ' + weather.high + '°. ' + lotext + ' ' + weather.low + '°...';
document.getElementById("Temp").innerHTML = weather.temperature + '°C';
}