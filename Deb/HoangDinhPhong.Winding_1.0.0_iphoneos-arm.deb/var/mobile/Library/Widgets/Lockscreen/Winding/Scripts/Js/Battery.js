function mainUpdate(type) {
if (type === "battery") { updateBattery(); }
if (type === "weather") { checkWeather(); }
}

function updateBattery() {
document.getElementById("Percentage").innerHTML = batteryPercent;
}