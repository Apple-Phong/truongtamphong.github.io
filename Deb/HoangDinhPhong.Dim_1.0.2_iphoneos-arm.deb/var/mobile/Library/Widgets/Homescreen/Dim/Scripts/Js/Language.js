if (window.config.language == "Vietnamese") {
var titletext = "Chưa phát";
var artisttext = "Không có nghệ sĩ";
var sday = ["C.Nh", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7"];
var smonth = ["Tháng 1", "Tháng 2", "Tháng 3", "Tháng 4", "Tháng 5", "Tháng 6", "Tháng 7", "Tháng 8", "Tháng 9", "Tháng 10", "Tháng 11", "Tháng 12"];
}

if (window.config.language == "English") {
var titletext = "No Title";
var artisttext = "No Artist";
var sday = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
var smonth = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
}