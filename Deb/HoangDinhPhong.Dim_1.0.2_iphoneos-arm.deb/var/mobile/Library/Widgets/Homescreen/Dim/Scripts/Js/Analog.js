function DP() {
var deg = 6;
var hr = document.querySelector('.Hour');
var mn = document.querySelector('.Min');

setInterval(() => {
let day = new Date();
let hh = day.getHours() * 30;
let mm = day.getMinutes() * deg;
hr.style.transform = `rotateZ(${ hh + (mm / 12) }deg)`;
mn.style.transform = `rotateZ(${ mm }deg)`;
 });
}

var twelve = document.querySelector('.TwelveL');
twelve.textContent = '';
var six = document.querySelector('.SixL');
six.textContent = '';

var nine = document.querySelector('.NineL');
nine.textContent = '';
var three = document.querySelector('.ThreeL');
three.textContent = '';

var one = document.querySelector('.One');
one.textContent = '';
var seven = document.querySelector('.Seven');
seven.textContent = '';

var two = document.querySelector('.Two');
two.textContent = '';
var eight = document.querySelector('.Eight');
eight.textContent = '';

var four = document.querySelector('.Four');
four.textContent = '';
var ten = document.querySelector('.Ten');
ten.textContent = '';

var five = document.querySelector('.Five');
five.textContent = '';
var eleven = document.querySelector('.Eleven');
eleven.textContent = '';

window.addEventListener("load", DP, false);