function mainUpdate(type) {
if (type === "weather") { checkWeather(); }
}

function checkWeather() {
document.getElementById('WeatherIcon').src = 'Scripts/Weather/' + weather.conditionCode + '.png';
document.getElementById("FeelsLike").innerHTML = feelstext + ' ' + weather.feelsLike + '°';
document.getElementById("HumiWind").innerHTML = humiditytext + ' ' + weather.humidity + '%' + ' | ' + windspeedtext + ' ' + weather.windSpeed + ' km/h';
document.getElementById("Condition").innerHTML = condition[weather.conditionCode] + ' ' + weather.temperature + '°';

document.getElementById("Day1").innerHTML = sday[weather.dayForecasts[1].dayOfWeek - 1];
document.getElementById("Day2").innerHTML = sday[weather.dayForecasts[2].dayOfWeek - 1];
document.getElementById("Day3").innerHTML = sday[weather.dayForecasts[3].dayOfWeek - 1];

document.getElementById("Day1Icon").src = "Scripts/Weather/1nka/" + weather.dayForecasts[1].icon + ".png";
document.getElementById("Day2Icon").src = "Scripts/Weather/1nka/" + weather.dayForecasts[2].icon + ".png";
document.getElementById("Day3Icon").src = "Scripts/Weather/1nka/" + weather.dayForecasts[3].icon + ".png";

document.getElementById("Day1HiLo").innerHTML = weather.dayForecasts[1].high + "°" + " / " + weather.dayForecasts[1].low + "°";
document.getElementById("Day2HiLo").innerHTML = weather.dayForecasts[2].high + "°" + " / " + weather.dayForecasts[2].low + "°";
document.getElementById("Day3HiLo").innerHTML = weather.dayForecasts[3].high + "°" + " / " + weather.dayForecasts[3].low + "°";
}