document.getElementById('YourName').innerHTML = config.name;
document.getElementById('Email').innerHTML = config.email;
document.documentElement.style.setProperty('--avSize', config.avSize +'px');
document.documentElement.style.setProperty('--filter', config.filter +'%');
if(!config.app) {
document.getElementById('AppCont').style.display = 'none'; }