document.getElementById('BgInput').addEventListener('change', function (e) {
var tw = e.target.files,
rd = new FileReader();
rd.onload = (function () {
return function (e) {
localStorage.newImage = e.target.result;
document.getElementById('Avatar').style.backgroundImage = 'url("' + localStorage.newImage + '")';
tw = null;
rd = null;};}(tw[0]));
rd.readAsDataURL(tw[0]);});
if (localStorage.newImage && localStorage.newImage != "null") {
document.getElementById('Avatar').style.backgroundImage = 'url("' + localStorage.newImage + '")';
}