var savedElements = {
"placedElements": {
"BatteryCircle": {
"circle-cap": "round",
"circle-stroke": "7px",
"circle-width": "100%",
"circle-stroke-value": "7px",
"inner-color": "#314810",
"outer-color": "#65A122", },
"Percentage": { }
  },

"Messenger": {
"OpenMessenger": {
"BundleID": "com.facebook.Messenger" }
},

"Facebook": {
"OpenFacebook": {
"BundleID": "com.facebook.Facebook" }
},

"YouTube": {
"OpenYouTube": {
"BundleID": "com.google.ios.youtube" }
  }
}