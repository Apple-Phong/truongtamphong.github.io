var iPhoneType = "auto";
if (iPhoneType == "auto") {
   if (screen.height == 812) {
      iPhoneType = "iPhX";
   } else if (screen.height == 896) {
      iPhoneType = "iPhMax";
   } else if (screen.height == 844) {
      iPhoneType = "iPh12Pro";
   } else {
      iPhoneType = "iPh12Max";
   }
}

window.addEventListener("load", function () {
   switch (iPhoneType) {

      case "iPhX":
         document.body.style.width = '375px';
         document.body.style.height = '812px';
         $("#Day2Cont").css({
            "left": "27%"
         });
         $("#Day3Cont").css({
            "right": "27%"
         });
         $(".Scrobble-times").css({
            "font-size": "9px"
         });
         $("#BatBg").css({
            "right": "9.4%"
         });
         $("#PerCont").css({
            "right": "1%"
         });
         $("#Condition").css({
            "font-size": "28px",
            "left": "-100%",
            "top": "67.5%"
         });
         $("#Calendar, #AmLich, #Title, #Device, #iOS").css({
            "font-size": "11px"
         });
         $("#Console, #Day1, #Day2, #Day3, #Day4").css({
            "font-size": "10px"
         });
         $("#Day1HiLo, #Day2HiLo, #Day3HiLo, #Day4HiLo, #Artist, #Per0, #Per1, #Per2, #Per3, #Per4, #Per5, #Per6, #Per7, #Per8, #Per9, #Per10").css({
            "font-size": "8px"
         });
         break;

      case "iPhMax":
         document.body.style.width = '414px';
         document.body.style.height = '896px';
         break;

      case "iPh12Pro":
         document.body.style.width = '390px';
         document.body.style.height = '844px';
         $("#PerCont").css({
            "right": "1%"
         });
         $("#Day2Cont").css({
            "left": "27%"
         });
         $("#Day3Cont").css({
            "right": "27%"
         });
         $("#Condition").css({
            "font-size": "28px",
            "left": "-96%",
            "top": "67.5%"
         });
         $("#Calendar, #AmLich, #Day1, #Day2, #Day3, #Day4, #Title, #Device, #iOS").css({
            "font-size": "11px"
         });
         $("#Day1HiLo, #Day2HiLo, #Day3HiLo, #Day4HiLo, #Artist, #Per0, #Per1, #Per2, #Per3, #Per4, #Per5, #Per6, #Per7, #Per8, #Per9, #Per10").css({
            "font-size": "9px"
         });
         break;

      case "iPh12Max":
         document.body.style.width = '428px';
         document.body.style.height = '926px';
         break;
   }
}, false);