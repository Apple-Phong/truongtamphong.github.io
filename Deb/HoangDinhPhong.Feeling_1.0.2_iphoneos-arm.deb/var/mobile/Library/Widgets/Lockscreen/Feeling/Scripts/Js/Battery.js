function updateBattery() {

document.getElementById('Percentage').innerHTML = batteryPercent + "% " + (batteryCharging? charging : notcharging);

if (batteryPercent > 0) {
$("#Overlay").css({ "left":"14%", "width":"86%" });
}

if (batteryPercent > 10) {
$("#Overlay").css({ "left":"22%", "width":"78%" });
}

if (batteryPercent > 20) {
$("#Overlay").css({ "left":"30%", "width":"70%" });
}

if (batteryPercent > 30) {
$("#Overlay").css({ "left":"38%", "width":"62%" });
}

if (batteryPercent > 40) {
$("#Overlay").css({ "left":"47%", "width":"53%" });
}

if (batteryPercent > 50) {
$("#Overlay").css({ "left":"55%", "width":"45%" });
}

if (batteryPercent > 60) {
$("#Overlay").css({ "left":"62%", "width":"38%" });
}

if (batteryPercent > 70) {
$("#Overlay").css({ "left":"70%", "width":"30%" });
}

if (batteryPercent > 80) {
$("#Overlay").css({ "left":"78%", "width":"22%" });
}

if (batteryPercent > 90) {
$("#Overlay").css({ "left":"86%", "width":"14%" });
}

if (batteryPercent > 95) {
$("#Overlay").css({ "left":"94%", "width":"6%" });
}
}