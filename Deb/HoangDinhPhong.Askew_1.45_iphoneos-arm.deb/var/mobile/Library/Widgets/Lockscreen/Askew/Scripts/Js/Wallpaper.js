document.getElementById('BgInput').addEventListener('change', function (e) {
var tw = e.target.files,
rd = new FileReader();
rd.onload = (function () {
return function (e) {
localStorage.askew = e.target.result;

document.getElementById('Wallpaper').style.backgroundImage = 'url("' + localStorage.askew + '")';
tw = null;
rd = null;
};
}(tw[0]));
rd.readAsDataURL(tw[0]);});

if (localStorage.askew && localStorage.askew != "null") {
document.getElementById('Wallpaper').style.backgroundImage = 'url("' + localStorage.askew + '")';
}