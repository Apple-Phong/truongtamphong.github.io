function TTP() {
checkSettings();
$(document).ready(function() {
var str = $('.curved-text').html();
var curved = '';
for (var i = 0, len = str.length; i < len; i++) {
curved += '<span class="char'; curved += i; curved += '">';
curved += str[i];
curved += '</span>';
}
$('.curved-text').html(curved);});
}

window.addEventListener("load", TTP, false);

var iPhoneType = "auto";
if (iPhoneType == "auto") {
if (screen.height == 667) { iPhoneType = "iPh678"; }
else if (screen.height == 736) { iPhoneType = "iPh678Plus"; }
else if (screen.height == 780) { iPhoneType = "iPhMini"; }
else if (screen.height == 812) { iPhoneType = "iPhX"; }
else if (screen.height == 896) { iPhoneType = "iPhMax"; }
else if (screen.height == 844) { iPhoneType = "iPh12Pro"; }
else if (screen.height == 926) { iPhoneType = "iPh12Max"; }
}

window.addEventListener("load", function() { 
switch(iPhoneType) {

case "iPh678":
document.body.style.width='375px';
document.body.style.height='667px';
screenWidth = 375;
break;

case "iPh678Plus":
document.body.style.width='414px';
document.body.style.height='736px'; 
screenWidth = 414;
break;

case "iPhMini":
document.body.style.width = '360px';
document.body.style.height = '780px';
screenWidth = 360;
$("#All").css({ "height":"82.14%" });
break;

case "iPhX":
document.body.style.width='375px';
document.body.style.height='812px';
screenWidth = 375;
$("#All").css({ "height":"82.14%" });
break;

case "iPhMax":
document.body.style.width='414px';
document.body.style.height='896px';
screenWidth = 414;
$("#All").css({ "height":"82.14%" });
break;

case "iPh12Pro":
document.body.style.width='390px';
document.body.style.height='844px';
screenWidth = 390;
$("#All").css({ "height":"82.14%" });
break;

case "iPh12Max":
document.body.style.width='428px';
document.body.style.height='926px';
screenWidth = 428;
$("#All").css({ "height":"82.14%" });
break;

case "editMode":
document.body.style.width='563px';
document.body.style.height='1000px';
screenWidth = 563;
break;
}
}, false);