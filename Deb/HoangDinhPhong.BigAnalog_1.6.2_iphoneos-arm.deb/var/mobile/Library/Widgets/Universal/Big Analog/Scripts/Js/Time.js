function calendar(options) {
var getTimes = function () {
var d = new Date(),
funcs = {

day: function () {
return d.getDay();
},

datepadded: function () {
return (d.getDate() < 10) ? "0" + d.getDate() : d.getDate();
},

month: function () {
return d.getMonth();
}
};

options.success(funcs);
setTimeout(function () {
getTimes();
}, options.refresh);
};
getTimes();
}

calendar({
refresh: 5000,
success:

function (calendar) {
document.getElementById('Month').innerHTML = smonth[calendar.month()];
document.getElementById('Date').innerHTML = calendar.datepadded();
document.getElementById('Weekday').innerHTML = sday[calendar.day()];
}
});

setInterval( function time() {
var mil = new Date().getMilliseconds();
var seconds = new Date().getSeconds();
var mins = new Date().getMinutes();
var hours = new Date().getHours();
var sdegree = seconds * 6 + (mil/(1000/6));
var mdegree = mins * 6;
var hdegree = (hours * 30 + mins * 0.5);
document.getElementById("Sec").style.webkitTransform = "rotate(" + sdegree + "deg)";
document.getElementById("Min").style.webkitTransform = "rotate(" + mdegree + "deg)";
document.getElementById("Hour").style.webkitTransform = "rotate(" + hdegree + "deg)";
}, 1000/6);