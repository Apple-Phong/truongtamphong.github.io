if (window.config.language == "Vietnamese") {
var sday = ["CN", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7"];
var smonth = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"];
var condition = [];
} else {
var sday = ["Sun", "Mon", "Tue", "Wed", "Thur", "Fri", "Sat"];
var smonth = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"];
var condition = [];
}