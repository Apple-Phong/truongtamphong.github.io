function checkSettings() {

// General
document.documentElement.style.setProperty('--AnalogSize', config.AnalogSize + '%');
document.documentElement.style.setProperty('--LineY', config.LineY + '%');
document.documentElement.style.setProperty('--RingOutSize', config.RingOutSize + 'px');
document.getElementById("curved-text").innerHTML = config.ctt;

// Size
document.documentElement.style.setProperty('--BattFont', config.BattFont + 'vw');
document.documentElement.style.setProperty('--TempFont', config.TempFont + 'vw');
document.documentElement.style.setProperty('--CityFont', config.CityFont + 'vw');
document.documentElement.style.setProperty('--CalFont', config.CalFont + 'vw');
document.documentElement.style.setProperty('--TimeFont', config.TimeFont + 'vw');
document.documentElement.style.setProperty('--CirFont', config.CirFont + 'vw');

// Color
document.documentElement.style.setProperty('--CirCl', config.CirCl);
document.documentElement.style.setProperty('--NumberCl', config.NumberCl);
document.documentElement.style.setProperty('--RingOutCl', config.RingOutCl);
document.documentElement.style.setProperty('--RingInCl', config.RingInCl);
document.documentElement.style.setProperty('--WeRing', config.WeRing);
document.documentElement.style.setProperty('--BattRing', config.BattRing);
document.documentElement.style.setProperty('--TempRing', config.TempRing);
document.documentElement.style.setProperty('--CityCl', config.CityCl);

// On off
if (!config.Line1) {
document.getElementById('Line1').style.display = 'none';
document.getElementById('Shadow1').style.display = 'none';
}

if (!config.Line2) {
document.getElementById('Line2').style.display = 'none';
document.getElementById('Shadow2').style.display = 'none';
}

if (!config.Line3) {
document.getElementById('Line3').style.display = 'none';
document.getElementById('Shadow3').style.display = 'none';
}

if (!config.Line4) {
document.getElementById('Line4').style.display = 'none';
document.getElementById('Shadow4').style.display = 'none';
}

if (!config.ct) {
document.getElementById("curved-text").style.display = 'none';
}
}

// Src Images
document.getElementById('Line1').src = 'Scripts/Images/Other/Line.png';
document.getElementById('Line2').src = 'Scripts/Images/Other/Line.png';
document.getElementById('Line3').src = 'Scripts/Images/Other/Line.png';
document.getElementById('Line4').src = 'Scripts/Images/Other/Line.png';
document.getElementById('Wallpaper').src = 'Scripts/Images/Wallpaper/' + config.Wall + '.jpg';
document.getElementById('Shadow1').src = 'Scripts/Images/Other/Shadow.png';
document.getElementById('Shadow2').src = 'Scripts/Images/Other/Shadow.png';
document.getElementById('Shadow3').src = 'Scripts/Images/Other/Shadow.png';
document.getElementById('Shadow4').src = 'Scripts/Images/Other/Shadow.png';
document.getElementById('Dock').src = 'Scripts/Images/Dock/' + config.Dock + '.png';
