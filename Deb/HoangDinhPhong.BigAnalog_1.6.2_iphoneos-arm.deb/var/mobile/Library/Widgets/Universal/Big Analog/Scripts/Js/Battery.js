var activate = true;
function updateBattery() {
document.getElementById("Percentage").innerHTML = batteryPercent + '%';

var Level = batteryPercent , batteryImage;

if ( Level >  0 && Level <=   2 ) batteryImage="Scripts/Images/Battery/1.png";

if ( Level >  2 && Level <=   5 ) batteryImage="Scripts/Images/Battery/2.png";

if ( Level >  5 && Level <=  10 ) batteryImage="Scripts/Images/Battery/3.png";

if ( Level > 10 && Level <=  20 ) batteryImage="Scripts/Images/Battery/4.png";

if ( Level > 20 && Level <=  25 ) batteryImage="Scripts/Images/Battery/5.png";

if ( Level > 25 && Level <=  35 ) batteryImage="Scripts/Images/Battery/6.png";

if ( Level > 35 && Level <=  45 ) batteryImage="Scripts/Images/Battery/7.png";

if ( Level > 45 && Level <=  50 ) batteryImage="Scripts/Images/Battery/8.png";

if ( Level > 50 && Level <=  55 ) batteryImage="Scripts/Images/Battery/9.png";

if ( Level > 55 && Level <=  65 ) batteryImage="Scripts/Images/Battery/10.png";

if ( Level > 65 && Level <=  70 ) batteryImage="Scripts/Images/Battery/11.png";

if ( Level > 70 && Level <=  80 ) batteryImage="Scripts/Images/Battery/12.png";

if ( Level > 80 && Level <=  85 ) batteryImage="Scripts/Images/Battery/13.png";

if ( Level > 85 && Level <=  90 ) batteryImage="Scripts/Images/Battery/14.png";

if ( Level > 90 && Level <=  95 ) batteryImage="Scripts/Images/Battery/15.png";

if ( Level > 95 && Level <=  98 ) batteryImage="Scripts/Images/Battery/16.png";

if ( Level > 98 && Level <= 100 ) batteryImage="Scripts/Images/Battery/17.png";

document.getElementById("BatteryImage").src = batteryImage;
}