function mainUpdate(type) {
if (type === "battery") { updateBattery(); }
if (type === "weather") { checkWeather(); }
}

function checkWeather() {
document.getElementById('Weather').src = 'Scripts/Weather/' +  weather.conditionCode + '.png';
document.getElementById("Temp").innerHTML = weather.temperature + '&deg;C';
document.getElementById("City").innerHTML = weather.city;
}