function mainUpdate(type) {
if (type === "battery") { updateBattery(); }
if (type === "weather") { checkWeather(); }
}

function checkWeather() {
document.getElementById("City").innerHTML = weather.city;
document.getElementById("Temp").innerHTML = weather.temperature + '&deg';
 document.getElementById('WeIcon').src = 'Scripts/Weather/' + weather.conditionCode + '.png';
}