document.getElementById('BgInput').addEventListener('change', function (e) {
var tw = e.target.files,
rd = new FileReader();
rd.onload = (function () {
return function (e) {
localStorage.pearl = e.target.result;

document.getElementById('Avatar').style.backgroundImage = 'url("' + localStorage.pearl + '")';
tw = null;
rd = null;
};
} (tw[0]));
rd.readAsDataURL(tw[0]);
});

if (localStorage.pearl && localStorage.pearl != "null") {
document.getElementById('Avatar').style.backgroundImage = 'url("' + localStorage.pearl + '")';
}