/* Color */
document.documentElement.style.setProperty('--effCl', config.effCl);
document.documentElement.style.setProperty('--dateCl', config.dateCl);

/* On off */
if (!config.app) {
document.getElementById('AppContSmall').style.display = 'none';
document.getElementById('AppContBig').style.opacity = 0; }

if (!config.bat) {
document.getElementById('BatBg').style.display = 'none';
document.getElementById('AvaName').style.top = '11%';
document.getElementById('WeCont').style.top = '11%';
document.getElementById('CalCont').style.top = '21%';
document.getElementById('AppContSmall').style.display = 'none';
document.getElementById('AppContBig').style.display = 'block'; }

/* Text */
document.getElementById('YourName').innerHTML = config.name;
document.getElementById('Email').innerHTML = config.email;

/* Other */
document.documentElement.style.setProperty('--avSize', config.avSize +'px');
document.documentElement.style.setProperty('--filter', config.filter +'%');
document.documentElement.style.setProperty('--bll', config.bll);
document.documentElement.style.setProperty('--blr', config.blr);