function webviewOpenApp() {
window.location = 'xeninfo:openapp:' + appToOpen;
}

document.getElementById('HDP').addEventListener('touchend', function (el) {
if (el.target.id.substring(0, 4) === 'Open') {
appToOpen = document.getElementById(el.target.id).getAttribute('bundleID');
webviewOpenApp(appToOpen);
}
});

action.loadStyles = function (key, value, createdDiv) {
var styleVal;
Object.keys(value).forEach(function (skey) {
styleVal = value[skey];
if (skey === 'BundleID') {
createdDiv.setAttribute(skey, styleVal);
}
});
};

function isExportedInfo() {
if (typeof savedElements !== 'undefined') {
return savedElements;
}
}

function setStoredElements() {
if (isExportedInfo()) {
action.savedElements = savedElements;
return action.savedElements;
}
}

action.loadFromStorage = function () {
var elements = setStoredElements();
if (elements) {
action.replaceElements();
}
};

function loadInfo() {
action.loadFromStorage();
}

window.onload = function () {
loadInfo();
};