function checkWeather() {
document.getElementById("WeInfo").innerHTML = weather.city + '<br>' + condition[weather.conditionCode] + '. ' + temptext + ' ' + weather.temperature + '°';
}