var changeSettings= function() {
document.getElementById("YourName").style.color = config.AllColor;
document.getElementById("Battery").style.color = config.AllColor;
document.getElementById("Hour").style.color = config.AllColor;
document.getElementById("City").style.color = config.AllColor;}
changeSettings();
document.getElementById("Calendar").style.value = config.bulkhead;
document.documentElement.style.setProperty('--br', config.br + 'px');
document.documentElement.style.setProperty('--timeY', config.timeY + 'px');
document.documentElement.style.setProperty('--bgBlur', config.bgBlur + 'px');
document.getElementById('HDP').style.webkitTransform = 'scale(' + config.Scale + ')';
document.getElementById('YourName').innerHTML = config.YourName;

if(!config.batName){
document.getElementById('Battery').style.display = 'none';
document.getElementById('YourName').style.display = 'block';
}