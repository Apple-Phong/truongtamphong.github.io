document.documentElement.style.setProperty('--clockCl', config.clockCl);
document.documentElement.style.setProperty('--boxCl', config.boxCl);
document.documentElement.style.setProperty('--calCl', config.calCl);
document.documentElement.style.setProperty('--monthCl', config.monthCl);

if (config.scale) {
document.body.style.webkitTransform = 'scale(' + config.scale + ')';
}