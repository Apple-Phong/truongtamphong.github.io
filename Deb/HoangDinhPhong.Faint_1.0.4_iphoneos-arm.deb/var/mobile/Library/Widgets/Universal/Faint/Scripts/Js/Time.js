function clock(options) {
var getTimes = function () {
var d = new Date(),
funcs = {

hour: function () {
var hour = (options.twentyfour === true) ? d.getHours() : (d.getHours() + 11) % 12 + 1;
hour = (options.padzero === true) ? (hour < 10 ? "0" + hour : "" + hour) : hour;
return hour;
},

minute: function () {
return (d.getMinutes() < 10) ? "0" + d.getMinutes() : d.getMinutes();
},

day: function () {
return d.getDay();
},

date: function () {
return d.getDate();
},

month: function () {
return d.getMonth();
},

dateplus: function () {
return this.date() + this.nth(Number(this.date()));
},

nth: function (d) {
if (d > 3 && d < 21) {
return 'th';
}
switch (d % 10) {
case 1:
return "st";
case 2:
return "nd";
case 3:
return "rd";
default:
return "th";
}
}
};

options.success(funcs);
setTimeout(function () {
getTimes();
}, options.refresh);
};
getTimes();
}

var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

clock({
twentyfour: true,
padzero: true,
refresh: 5000,
success:

function (clock) {
document.getElementById('Hour').innerHTML = clock.hour();
document.getElementById('Minute').innerHTML = clock.minute();
document.getElementById('Weekday').innerHTML = days[clock.day()];
document.getElementById('Month').innerHTML = months[clock.month()];
document.getElementById('Date').innerHTML = clock.dateplus();
}
});