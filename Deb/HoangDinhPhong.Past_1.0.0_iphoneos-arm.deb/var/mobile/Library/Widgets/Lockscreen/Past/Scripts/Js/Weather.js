function checkWeather() {
document.getElementById("City").innerHTML = weather.city;
document.getElementById("Condition").innerHTML = weather.temperature + '° ' + condition[weather.conditionCode];
}