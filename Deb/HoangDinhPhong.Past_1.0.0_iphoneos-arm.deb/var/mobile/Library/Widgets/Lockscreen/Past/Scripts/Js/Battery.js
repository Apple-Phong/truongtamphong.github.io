function mainUpdate(type) {
if (type === "battery") { updateBattery(); }
if (type === "weather") { checkWeather(); }
}

function updateBattery() {
document.getElementById("Percentage").innerHTML = batteryPercent;
document.getElementById("Charging").innerHTML = (batteryCharging) ? charging : notcharging;

if (batteryCharging === 1) {
document.getElementById("Percentage").style.top = '40%';
} else {
document.getElementById("Percentage").style.top = ''; }
}