if (window.config.language == "Vietnamese") {
var wetext = "Thời tiết tại";
var totext = "là";
var hilotext = "Cao & thấp nhất";
var windtext = "Tốc độ gió";
var humitext = "Độ ẩm";
var raintext = "Khả năng có mưa là";
var sday1 = ["S", "M", "T", "W", "T", "F", "S"];
var sday2 = ["U", "O", "U", "E", "H", "R", "A"];
var sday3 = ["N", "N", "E", "D", "U", "I", "T"];
var months = ["Tháng một", "Tháng hai", "Tháng ba", "Tháng tư", "Tháng năm", "Tháng sáu", "Tháng bảy", "Tháng tám", "Tháng chín", "Tháng mười", "Tháng mười một", "Tháng mười hai"];
var condition = ["Lốc xoáy", "Bão nhiệt đới", "Có bão", "Giông bão lớn", "Giông bão", "Mưa và tuyết hỗn hợp", "Mưa có tuyết", "Tuyết và mưa hỗn hợp", "Mưa phùn lạnh giá", "Mưa phùn", "Mưa đóng băng", "Mưa rào", "Mưa", "Tuyết rơi", "Mưa tuyết", "Tuyết thổi mạnh", "Tuyết rơi", "Mưa đá", "Mưa đá", "Gió bụi", "Sương mù", "Sương mù nhẹ", "Sương mù", "Gió dữ dội", "Có gió", "Trời lạnh", "Có mây", "Trời nhiều mây", "Trời nhiều mây", "Có mây vài nơi", "Có mây vài nơi", "Quang mây", "Có nắng", "Trời quang mây", "Trời nắng", "Mưa đá", "Trời nóng", "Có sấm sét", "Giông bão rải rác", "Có sấm sét", "Mưa lớn", "Có tuyết", "Tuyết rơi nhẹ", "Tuyết rơi nhiều", "Ít mây", "Có giông", "Có tuyết", "Có giông", "Không có sẵn"];
}

if (window.config.language == "English") {
var wetext = "Weather at";
var totext = "to be";
var hilotext = "Highest & Lowest";
var windtext = "Wind speed";
var humitext = "Humidity";
var raintext = "The possibility of rain is";
var sday1 = ["S", "M", "T", "W", "T", "F", "S"];
var sday2 = ["U", "O", "U", "E", "H", "R", "A"];
var sday3 = ["N", "N", "E", "D", "U", "I", "T"];
var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
var condition = ["Tornado", "Tropical storm", "Hurricane", "Severe thunderstorms", "Thunderstorms", "Mixed rain and snow", "Mixed rain and sleet", "Mixed snow and sleet", "Freezing drizzle", "Drizzle", "Freezing rain", "Showers", "Showers", "Snow flurries", "Light snow showers", "Blowing snow", "Snow", "Hail", "Sleet", "Dust", "Foggy", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy ", "Mostly cloudy", "Mostly cloudy", "Partly cloudy", "Partly cloudy", "Clear", "Sunny", "Fair", "Fair", "Mixed rain and hail", "Hot", "Isolated thunderstorms", "Scattered thunderstorms", "Scattered thunderstorms", "Scattered showers", "Heavy snow", "Scattered snow showers", "Heavy snow", "Partly cloudy", "Thundershowers", "Snow showers", "Isolated thundershowers", "Not available"];
}