function clock(options) {
var getTimes = function () {
var d = new Date(),
funcs = {

hour: function () {
var hour = (options.twentyfour === true) ? d.getHours() : (d.getHours() + 11) % 12 + 1;
hour = (options.padzero === true) ? (hour < 10 ? "0" + hour : "" + hour) : hour;
return hour;
},

minute: function () {
return (d.getMinutes() < 10) ? "0" + d.getMinutes() : d.getMinutes();
},

day: function () {
return d.getDay();
},

date: function () {
return d.getDate();
},

month: function () {
return d.getMonth();
},

year: function () {
return d.getFullYear();
}
};

options.success(funcs);
setTimeout(function () {
getTimes();
}, options.refresh);
};
getTimes();
}

clock({
twentyfour: config.Time24,
padzero: true,
refresh: 5000,
success:

function (clock) {
document.getElementById("Clock").innerHTML = clock.hour() + ':' + clock.minute();
document.getElementById('WeekdayL').innerHTML = sday1[clock.day()];
document.getElementById('WeekdayC').innerHTML = sday2[clock.day()];
document.getElementById('WeekdayR').innerHTML = sday3[clock.day()];
document.getElementById('Year').innerHTML = "It's " + clock.year();
document.getElementById('DateMonth').innerHTML = clock.date() + ' ' + months[clock.month()];
}
});