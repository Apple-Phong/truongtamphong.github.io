if(!config.time){
document.getElementById('TimeCont').style.display = 'none';
}

if(!config.weather){
document.getElementById('WeatherCont').style.display = 'none';
}