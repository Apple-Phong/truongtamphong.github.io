document.documentElement.style.setProperty('--conW', window.config.conW + '%');
document.documentElement.style.setProperty('--textCl', window.config.textCl);