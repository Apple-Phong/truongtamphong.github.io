function mainUpdate(type) {
if (type === "weather") { checkWeather(); }
}

function checkWeather() {
document.getElementById("Condition").innerHTML = condition[weather.conditionCode];
document.getElementById("Temp").innerHTML = weather.temperature + '°';
document.getElementById("FeelsLike").innerHTML = feelstext + ' ' + weather.feelsLike + '°';
document.getElementById("Wind").innerHTML = windtext + ' ' + weather.windSpeed + ' km/h';
document.getElementById("Humi").innerHTML = humitext + ' ' + weather.humidity + '%';
}