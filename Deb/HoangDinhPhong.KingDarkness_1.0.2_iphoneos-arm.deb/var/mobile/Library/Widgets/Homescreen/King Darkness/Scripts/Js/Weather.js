function mainUpdate(type) {
if (type === "weather") { checkWeather(); }
}

function checkWeather() {
document.getElementById("Hi").innerHTML = weather.high;
document.getElementById("Lo").innerHTML = weather.low;
document.getElementById('WeatherIcon').src = 'Scripts/Weather/' + config.IconSet + '/' + weather.conditionCode + '.png';
document.getElementById('Temp').innerHTML = weather.temperature;
}