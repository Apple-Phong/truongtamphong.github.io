if (window.config.language == "Vietnamese") {
var titletext = "Chưa phát";
var artisttext = "Không có nghệ sĩ";
var play = "Music Player";
var pause = "Music Paused";
}

if (window.config.language == "English") {
var titletext = "No Media Player";
var artisttext = "No Artist";
var play = "Music Player";
var pause = "Music Paused";
}