var iPhoneType = "auto";
if (iPhoneType == "auto") {
if (screen.height == 780) { iPhoneType = "iPhMini"; }
else if (screen.height == 812) { iPhoneType = "iPhX"; }
else if (screen.height == 896) { iPhoneType = "iPhMax"; }
else if (screen.height == 844) { iPhoneType = "iPh12Pro"; }
else if (screen.height == 926) { iPhoneType = "iPh12Max"; }
}

window.addEventListener("load", function() { 
switch(iPhoneType) {

case "iPhMini":
document.body.style.width = '360px';
document.body.style.height = '780px';
$("#Hi, #Lo, #Temp").css({ "font-size":"14px" });
$("#Title, #In").css({ "font-size":"11px" });
$("#Artist").css({ "font-size":"9px" });
$("#PlayPause").css({ "font-size":"27px" });
$("#MuIcon").css({ "font-size":"55px" });
break;

case "iPhX":
document.body.style.width='375px';
document.body.style.height='812px';
$("#Hi, #Lo, #Temp").css({ "font-size":"15px" });
$("#Title, #In").css({ "font-size":"12px" });
$("#Artist").css({ "font-size":"10px" });
$("#PlayPause").css({ "font-size":"28px" });
$("#MuIcon").css({ "font-size":"57px" });
break;

case "iPhMax":
document.body.style.width='414px';
document.body.style.height='896px';
break;

case "iPh12Pro":
document.body.style.width='390px';
document.body.style.height='844px';
$("#Hi, #Lo, #Temp").css({ "font-size":"15px" });
$("#Title, #In").css({ "font-size":"12px" });
$("#Artist").css({ "font-size":"10px" });
$("#PlayPause").css({ "font-size":"28px" });
$("#MuIcon").css({ "font-size":"57px" });
break;

case "iPh12Max":
document.body.style.width='428px';
document.body.style.height='926px';
break;
}
}, false);