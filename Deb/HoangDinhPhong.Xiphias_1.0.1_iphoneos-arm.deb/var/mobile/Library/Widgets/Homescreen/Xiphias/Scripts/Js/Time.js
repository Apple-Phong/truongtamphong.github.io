function calendar(options) {
var getTimes = function () {
var d = new Date(),
funcs = {

day: function () {
return d.getDay();
},

date: function () {
return d.getDate();
}
};

options.success(funcs);
setTimeout(function () {
getTimes();
}, options.refresh);
};
getTimes();
}

calendar({
refresh: 5000,
success:

function(calendar) {
document.getElementById('Weekday').innerHTML = days[calendar.day()];
document.getElementById('Date').innerHTML = calendar.date();
}
});