function mainUpdate(type) {
if (type === "weather") { checkWeather(); }
else if (type === "battery") { updateBattery(); }
}

function checkWeather() {
document.getElementById("Temp").innerHTML = weather.temperature + '°';
document.getElementById("Condition").innerHTML = condition[weather.conditionCode];
document.getElementById("HumiWind").innerHTML = humitext + ' ' + weather.humidity + '%, ' + windtext + ' ' + weather.windSpeed + ' km/h';
}