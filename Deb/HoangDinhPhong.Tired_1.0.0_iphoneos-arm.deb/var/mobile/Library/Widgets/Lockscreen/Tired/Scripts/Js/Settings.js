document.documentElement.style.setProperty('--weekCl', config.weekCl);
document.getElementById('BatText').innerHTML = battext;
document.documentElement.style.setProperty('--sc', config.sc);

if(!config.mu){
document.getElementById('Title').style.display = 'none';
document.getElementById('Artist').style.display = 'none';
document.getElementById('Controls').style.display = 'none';
}