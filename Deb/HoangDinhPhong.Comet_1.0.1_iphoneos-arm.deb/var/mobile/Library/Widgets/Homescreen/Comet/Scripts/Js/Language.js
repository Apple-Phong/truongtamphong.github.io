if (window.config.language == "Vietnamese") {
var todaytext = "Hôm nay";
var datetext = "";
var yeartext = "-";
var nowtext = "Thời tiết";
var temptext = "Cảm giác như";
var humtext = "Độ ẩm";
var windtext = "và tốc độ gió là";
var citytext = "tại";
var honame = "Giờ";
var miname = "Phút";
var charging = "Đang sạc...";
var notcharging = "Pin";
var pertext ="Phần trăm";
var condition = ["Lốc xoáy", "Bão nhiệt đới", "Có bão", "Giông bão lớn", "Giông bão", "Mưa và tuyết hỗn hợp", "Mưa có tuyết", "Tuyết và mưa hỗn hợp", "Mưa phùn lạnh giá", "Mưa phùn", "Mưa đóng băng", "Mưa rào", "Mưa", "Tuyết rơi", "Mưa tuyết", "Tuyết thổi mạnh", "Tuyết rơi", "Mưa đá", "Mưa đá", "Gió bụi", "Sương mù", "Sương mù nhẹ", "Sương mù", "Gió dữ dội", "Có gió", "Trời lạnh", "Có mây", "Trời nhiều mây", "Trời nhiều mây", "Có mây vài nơi", "Có mây vài nơi", "Quang mây", "Có nắng", "Trời quang mây", "Trời nắng", "Mưa đá", "Trời nóng", "Có sấm sét", "Giông bão rải rác", "Có sấm sét", "Mưa lớn", "Có tuyết", "Tuyết rơi nhẹ", "Tuyết rơi nhiều", "Ít mây", "Có giông", "Có tuyết", "Có giông", "Không có sẵn"];
var days = ["Chủ nhật", "Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy"];
var months = ["Tháng 1", "Tháng 2", "Tháng 3", "Tháng 4", "Tháng 5", "Tháng 6", "Tháng 7", "Tháng 8", "Tháng 9", "Tháng 10", "Tháng 11", "Tháng 12"];
var hourtxt = ["Hai mươi bốn", "Một", "Hai", "Ba", "Bốn", "Năm", "Sáu", "Bảy", "Tám", "Chín", "Mười", "Mười một", "Mười hai", "Mười ba", "Mười bốn", "Mười năm", "Mười sáu", "Mười bảy", "Mười tám", "Mười chín", "Hai mươi", "Hai mươi mốt", "Hai mươi ha", "Hai mươi ba", "Hai mươi bốn"];
var hourtext = ["Hai mươi bốn", "Một", "Hai", "Ba", "Bốn", "Năm", "Sáu", "Bảy", "Tám", "Chín", "Mười", "Mười một", "Mười hai", "Mười ba", "Mười bốn", "Mười năm", "Mười sáu", "Mười bảy", "Mười tám", "Mười chín", "Hai mươi", "Hai mươi mốt", "Hai mươi ha", "Hai mươi ba", "Hai mươi bốn"];
var minuteone = ["Không không", "Không một", "Không hai", "Không ba", "Không bốn", "Không năm", "Không sáu", "Không bảy", "Không tám", "Không chín", "Mười", "Mười một", "Mười hai", "Mười ba", "Mười bốn", "Mười năm", "Mười sáu", "Mười bảy", "Mười tám", "Mười chín", "Hai mươi", "Hai mươi", "Hai mươi", "Hai mươi", "Hai mươi", "Hai mươi", "Hai mươi", "Hai mươi", "Hai mươi", "Hai mươi", "Ba mươi", "Ba mươi", "Ba mươi", "Ba mươi", "Ba mươi", "Ba mươi", "Ba mươi", "Ba mươi", "Ba mươi", "Ba mươi", "Bốn mươi", "Bốn mươi", "Bốn mươi", "Bốn mươi", "Bốn mươi", "Bốn mươi", "Bốn mươi", "Bốn mươi", "Bốn mươi", "Bốn mươi", "Năm mươi", "Năm mươi", "Năm mươi", "Năm mươi", "Năm mươi", "Năm mươi", "Năm mươi", "Năm mươi", "Năm mươi", "Năm mươi", "Năm mươi"];
var minutetwo = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "mốt", "hai", "ba", "bốn", "năm", "sáu", "bảy", "tám", "chín", "", "mốt", "hai", "ba", "bốn", "năm", "sáu", "bảy", "tám", "chín", "", "mốt", "hai", "ba", "bốn", "năm", "sáu", "bảy", "tám", "chín", "", "mốt", "hai", "ba", "bốn", "năm", "sáu", "bảy", "tám", "chín", ""];
}

if (window.config.language == "English") {
var todaytext = "Today's";
var datetext = "";
var nowtext = "Weather is";
var temptext = "With feels like";
var humtext = "Humidity";
var windtext = "and wind speed is";
var citytext = "in";
var yeartext = "Year";
var charging = "Charging...";
var notcharging = "Level";
var pertext ="Percent";
var honame = "Hours";
var miname = "Minutes";
var condition = ["Tornado", "Tropical storm", "Hurricane", "Severe thunderstorms", "Thunderstorms", "Mixed rain and snow", "Mixed rain and sleet", "Mixed snow and sleet", "Freezing drizzle", "Drizzle", "Freezing rain", "Showers", "Showers", "Snow flurries", "Light snow showers", "Blowing snow", "Snow", "Hail", "Sleet", "Dust", "Foggy", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy ", "Mostly cloudy", "Mostly cloudy", "Partly cloudy", "Partly cloudy", "Clear", "Sunny", "Fair", "Fair", "Mixed rain and hail", "Hot", "Isolated thunderstorms", "Scattered thunderstorms", "Scattered thunderstorms", "Scattered showers", "Heavy snow", "Scattered snow showers", "Heavy snow", "Partly cloudy", "Thundershowers", "Snow showers", "Isolated thundershowers", "Not available"];
var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
var hourtxt = ["Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen", "Twenty", "Twenty One", "Twenty Two", "Twenty Three", "Twenty Four"];
var hourtext = ["Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve"];
var minuteone = ["O' Clock", "O' One", "O' Two", "O' Three", "O' Four", "O' Five", "O' Six", "O' Seven", "O' Eight", "O' Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty"];
var minutetwo = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", ""];
}