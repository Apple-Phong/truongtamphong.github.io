function clock(options) {
var getTimes = function () {
var d = new Date(),
funcs = {

day: function () {
return d.getDay();
},

datepadded: function () {
return (d.getDate() < 10) ? "0" + d.getDate() : d.getDate();
},

month: function () {
return d.getMonth();
},

year: function () {
return d.getFullYear();
},

rawhour: function () {
return d.getHours();
},

rawminute: function () {
return d.getMinutes();
},

hourtext: function () {
var hourtxt = (options.twentyfour === true) ? hourtxttext : hourtext;
return hourtxt[this.rawhour()];
},

minuteonetext: function () {
if (minuteone[this.rawminute()] !== undefined) {
return minuteone[this.rawminute()];
}
return "";
},

minutetwotext: function () {
if (minutetwo[this.rawminute()] !== undefined) {
return minutetwo[this.rawminute()];
}
return "";
}
};

options.success(funcs);
setTimeout(function () {
getTimes();
}, options.refresh);
};
getTimes();
}

clock({
twentyfour: config.Time24,
padzero: true,
refresh: 5000,
success:

function(clock) {
document.getElementById("Weekday").innerHTML = todaytext + ' ' + days[clock.day()];
document.getElementById("Date").innerHTML = datetext + ' ' + clock.datepadded();
document.getElementById("Month").innerHTML = months[clock.month()] + ' ' + yeartext + ' ' + clock.year();
document.getElementById("HoText").innerHTML = clock.hourtext();
document.getElementById("MiText").innerHTML = clock.minuteonetext() + ' ' + clock.minutetwotext();
}
});

(function () {
$minutes = $('.Minutes .Time');
$hour = $('.Hour .Time');
clockWidth = $('#BarClock .Hour').width();

var getTime = function () {
var dateTime;
d = new Date();
return {
hour: d.getHours(),
minutes: d.getMinutes(),
}
};

renderTime = function ($el, time, duration) {
var percentage;
percentage = (clockWidth * time) / duration
$el.width(function () {
return percentage;
});
};

updateTime = function (time) {
renderTime($minutes, time.minutes, 59);
renderTime($hour, time.hour, 23);
};

t = setInterval(function () {
return updateTime(getTime());
}, 150);
}).call(this);