function TP() {
document.getElementById("XuThe").innerHTML = xt();
setInterval(function () {
console.log(xt());
document.getElementById("XuThe").innerHTML = xt(); }, config.setTime);
}

window.addEventListener("load", TP, false);

function P() {
document.getElementById("TinhYeu").innerHTML = ty();
setInterval(function () {
console.log(ty());
document.getElementById("TinhYeu").innerHTML = ty(); }, config.setTime);
}

document.getElementById('Container').style.zoom = config.zoomLevel / 100;

window.addEventListener("load", P, false);