document.documentElement.style.setProperty('--conW', config.conW + '%');

document.documentElement.style.setProperty('--blCl', config.blCl);
document.documentElement.style.setProperty('--alCl', config.C1);
document.documentElement.style.setProperty('--dnCl', config.C2);

document.documentElement.style.setProperty('--fontStyle', config.fontStyle);

document.documentElement.style.setProperty('--alTrans', config.alTrans);
document.documentElement.style.setProperty('--dnTrans', config.dnTrans);

document.documentElement.style.setProperty('--alAlign', config.alAlign);
document.documentElement.style.setProperty('--dnAlign', config.dnAlign);

document.documentElement.style.setProperty('--alAlign', config.alAlign);
document.documentElement.style.setProperty('--dnAlign', config.dnAlign);

document.documentElement.style.setProperty('--alSize', config.alSize + 'px');
document.documentElement.style.setProperty('--dnSize', config.dnSize + 'px');

document.documentElement.style.setProperty('--alSh', config.alSh + 'px');
document.documentElement.style.setProperty('--dnSh', config.dnSh + 'px');

document.documentElement.style.setProperty('--alShCl', config.alShCl);
document.documentElement.style.setProperty('--batShCl', config.batShCl);
document.documentElement.style.setProperty('--dnShCl', config.dnShCl);

if (!config.al) {
document.getElementById('AmLich').style.display = 'none';
}

if (!config.bat) {
document.getElementById('Battery').style.display = 'none';
}

if (!config.daTi) {
document.getElementById('TinhYeu').style.display = 'none';
document.getElementById('XuThe').style.display = 'block';
}