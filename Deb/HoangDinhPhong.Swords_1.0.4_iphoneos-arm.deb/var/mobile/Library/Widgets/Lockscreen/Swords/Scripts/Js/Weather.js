function mainUpdate(type) {
if (type == "battery") { injectedSystem.battery = batteryPercent; 
document.getElementById("Charging").innerHTML = (batteryCharging) ? charging : notcharging;
}

if (batteryCharging === 1) {
document.getElementById("BatIcon").style.display = 'none';
} else {
document.getElementById("BatIcon").style.display = '';
}

if (type === "weather") { checkWeather(); }
}

function checkWeather() {
document.getElementById("WeInfo").innerHTML = weather.city + ' ' + weather.temperature + '°. ' + condition[weather.conditionCode];
document.getElementById("WindSpeed").innerHTML = windspeedtext + ' ' + weather.windSpeed + ' km/h';
document.getElementById("Humidity").innerHTML = humiditytext + ' ' + weather.humidity + '%';
document.getElementById("Sunrise").innerHTML = weather.sunriseTime.substring(1, 0) + ':' + weather.sunriseTime.substring(3, 1) + ' ' + sunrisetext;
document.getElementById("Sunset").innerHTML = weather.sunsetTime.substring(2, 0) + ':' + weather.sunsetTime.substring(2, 4) + ' ' + sunsettext;
}