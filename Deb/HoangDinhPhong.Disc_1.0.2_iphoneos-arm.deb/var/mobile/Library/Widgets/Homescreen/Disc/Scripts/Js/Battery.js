function updateBattery() {
document.getElementById('Percentage').innerHTML = batteryPercent;
}