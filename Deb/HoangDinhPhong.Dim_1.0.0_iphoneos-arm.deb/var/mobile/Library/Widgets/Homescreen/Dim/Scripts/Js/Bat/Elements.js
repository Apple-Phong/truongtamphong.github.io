var savedElements = {
"placedElements": {
"BatteryCircle": {
"circle-cap": "round",
"circle-width": "100%",
"circle-stroke": "5px",
"outer-color": "#FFFFFF",
"inner-color": "#FFFFFF33",
"circle-stroke-value": "5px",
},

"Percent": { },
  }
}