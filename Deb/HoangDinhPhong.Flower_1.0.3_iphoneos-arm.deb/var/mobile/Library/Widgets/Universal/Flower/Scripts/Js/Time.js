function calendar(options) {
var getTimes = function () {
var d = new Date(),
funcs = {

day: function () {
return d.getDay();
},

datepadded: function () {
return (d.getDate() < 10) ? "0" + d.getDate() : d.getDate();
}
};

options.success(funcs);
setTimeout(function () {
getTimes();
}, options.refresh);
};
getTimes();
}

calendar({
refresh: 5000,
success:

function(calendar) {
document.getElementById('Weekday').innerHTML = days[calendar.day()];
document.getElementById('Date').innerHTML = calendar.datepadded();
}
});