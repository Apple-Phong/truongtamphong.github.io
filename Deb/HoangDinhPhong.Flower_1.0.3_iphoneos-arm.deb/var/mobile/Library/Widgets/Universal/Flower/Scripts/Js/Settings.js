/* Scale */
document.documentElement.style.setProperty('--scale', config.scale);

/* Color */
document.documentElement.style.setProperty('--pCl', config.pCl);
document.documentElement.style.setProperty('--anaCl', config.anaCl);
document.documentElement.style.setProperty('--secCl', config.secCl);
document.documentElement.style.setProperty('--weekCl', config.weekCl);

/* Size & Blur */
document.documentElement.style.setProperty('--w', config.w + '%');
document.documentElement.style.setProperty('--h', config.h + '%');
document.documentElement.style.setProperty('--bl', config.bl + 'px');
document.documentElement.style.setProperty('--pbl', config.pbl + 'px');

/* On Off */
document.documentElement.style.setProperty('--disable', config.disable);