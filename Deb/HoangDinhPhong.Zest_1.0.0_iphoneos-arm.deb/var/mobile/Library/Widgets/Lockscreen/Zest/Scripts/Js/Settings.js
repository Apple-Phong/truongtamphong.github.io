document.documentElement.style.setProperty('--calCl', config.calCl);
document.documentElement.style.setProperty('--textCl', config.textCl);
