// Color
document.documentElement.style.setProperty('--calCl', config.calCl);

// Other
document.getElementById('Today').innerHTML = today;