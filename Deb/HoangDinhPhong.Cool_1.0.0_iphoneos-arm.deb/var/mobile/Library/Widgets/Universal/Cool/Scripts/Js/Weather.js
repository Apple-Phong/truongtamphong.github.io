function mainUpdate(type){ 
if (type === "battery") { updateBattery(); }
else if (type === "weather"){ checkWeather(); }
}

function checkWeather(){
document.getElementById('WeIcon').src = 'Scripts/Weather/' + weather.conditionCode + '.png';

document.getElementById("Condition").innerHTML = condition[weather.conditionCode] + ' ' + weather.temperature + '&deg;C';
document.getElementById("Humidity").innerHTML = humiditytext + ' ' + weather.humidity + '%';
document.getElementById("WindSpeed").innerHTML = windspeedtext + ' ' + weather.windSpeed + ' km/h';
}