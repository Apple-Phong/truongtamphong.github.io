function updateBattery() {
// Percentage
    document.getElementById('Percentage').innerHTML = batteryPercent + "%";
}