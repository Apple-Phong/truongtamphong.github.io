document.documentElement.style.setProperty('--perCl', config.perCl);
document.documentElement.style.setProperty('--weekdayCl', config.weekdayCl);
document.documentElement.style.setProperty('--dateCl', config.dateCl);
document.documentElement.style.setProperty('--monthCl', config.monthCl);
document.documentElement.style.setProperty('--lineCl', config.lineCl);
document.documentElement.style.setProperty('--timeCl', config.timeCl);
document.documentElement.style.setProperty('--weCl', config.weCl);
document.documentElement.style.setProperty('--batBgCl', config.batBgCl);
document.documentElement.style.setProperty('--andCl', config.andCl);

document.documentElement.style.setProperty('--scale', config.scale);
document.getElementById("Todays").innerHTML = todays;