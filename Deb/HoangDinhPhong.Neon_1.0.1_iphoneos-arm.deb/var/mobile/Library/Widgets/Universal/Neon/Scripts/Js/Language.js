if (window.config.language == "Vietnamese") {
var pertext = "Mức pin còn lại";
var daytext = "Ngày";
var days = ["Chủ Nhật", "Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy"];
var months = ["Tháng 1", "Tháng 2", "Tháng 3", "Tháng 4", "Tháng 5", "Tháng 6", "Tháng 7", "Tháng 8", "Tháng 9", "Tháng 10", "Tháng 11", "Tháng 12"];
var condition = ["Lốc xoáy", "Bão nhiệt đới", "Có bão", "Giông bão lớn", "Giông bão", "Mưa và tuyết hỗn hợp", "Mưa có tuyết", "Tuyết và mưa hỗn hợp", "Mưa phùn lạnh giá", "Mưa phùn", "Mưa đóng băng", "Mưa rào", "Mưa", "Tuyết rơi", "Mưa tuyết", "Tuyết thổi mạnh", "Tuyết rơi", "Mưa đá", "Mưa đá", "Gió bụi", "Sương mù", "Sương mù nhẹ", "Sương mù", "Gió dữ dội", "Có gió", "Trời lạnh", "Có mây", "Trời nhiều mây", "Trời nhiều mây", "Có mây vài nơi", "Có mây vài nơi", "Quang mây", "Có nắng", "Trời quang mây", "Trời nắng", "Mưa đá", "Trời nóng", "Có sấm sét", "Giông bão rải rác", "Có sấm sét", "Mưa lớn", "Có tuyết", "Tuyết rơi nhẹ", "Tuyết rơi nhiều", "Ít mây", "Có giông", "Có tuyết", "Có giông", "Không có sẵn"];
}

if (window.config.language == "English") {
var pertext = "Battery Level";
var daytext = "Day";
var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
var condition = ["Tornado", "Tropical storm", "Hurricane", "Severe thunder", "Thunder", "Rain and snow", "Rain and sleet", "Snow and sleet", "Freezing drizzle", "Drizzle", "Freezing rain", "Showers", "Showers", "Snow flurries", "Light snow showers", "Blowing snow", "Snow", "Hail", "Sleet", "Dust", "Foggy", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy ", "Mostly cloudy", "Mostly cloudy", "Partly cloudy", "Partly cloudy", "Clear", "Sunny", "Fair", "Fair", "Mixed rain and hail", "Hot", "Isolated thunder", "Scattered thunder", "Scattered thunder", "Scattered showers", "Heavy snow", "Scattered sleet", "Heavy snow", "Partly cloudy", "Thunder", "Snow showers", "Isolated thunder", "Not available"];
}