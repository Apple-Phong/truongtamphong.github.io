function mainUpdate(type) {
if (type === "weather") { checkWeather(); } 
if (type === "battery") { updateBattery(); }
}

function checkWeather() {
document.getElementById("Condition").innerHTML = weather.temperature + '&deg;' + ' ' + condition[weather.conditionCode];
}