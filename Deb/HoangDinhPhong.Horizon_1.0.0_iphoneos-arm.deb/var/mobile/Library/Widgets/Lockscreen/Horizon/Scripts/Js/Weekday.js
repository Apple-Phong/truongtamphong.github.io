function BP(){
var days_month = new Array(31,28,31,30,31,30,31,31,30,31,30,31);
var Calendar = new Date();
var month = Calendar.getMonth();
var today = Calendar.getDate();
var day = Calendar.getDay();
var num_days = 7;
var day;
var cal;
cal = '<table>';

for(index=0; index < num_days; index++) {
var yesterday_tomorrow = today - (day-index);
var this_month = days_month[month];
if (day == index)
cal += '<td class="today" style="font-size: 30px">' + today + '</td>';

else if (yesterday_tomorrow < this_month+1 & yesterday_tomorrow > 0)
cal += '<td  class="todays" style="font-size: 13px">' + yesterday_tomorrow + '</td>';
}

document.getElementById("Day").innerHTML = cal;
setTimeout("BP()",1000);
}

window.addEventListener("load", BP, false);