function clock(options) {
var getTimes = function () {
var d = new Date(),
funcs = {

hour: function () {
var hour = (options.twentyfour === true) ? d.getHours() : (d.getHours() + 11) % 12 + 1;
hour = (options.padzero === true) ? (hour < 10 ? "0" + hour : "" + hour) : hour;
return hour;
},

minute: function () {
return (d.getMinutes() < 10) ? "0" + d.getMinutes() : d.getMinutes();
},

day: function () {
return d.getDay();
},

datepadded: function () {
return (d.getDate() < 10) ? "0" + d.getDate() : d.getDate();
},

month: function () {
return d.getMonth();
}
};

options.success(funcs);
setTimeout(function () {
getTimes();
}, options.refresh);
};
getTimes();
}

clock({
twentyfour: config.Time24,
padzero: true,
refresh: 5000,
success:

function (clock) {
document.querySelector('.Time').innerHTML = clock.hour() + ':' + clock.minute();
document.querySelector('.Weekday').innerHTML = days[clock.day()];
document.querySelector('.Date').innerHTML = clock.datepadded();
document.querySelector('.Month').innerHTML = months[clock.month()];
}
});