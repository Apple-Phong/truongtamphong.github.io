$('head').removeAttr('mode');
if (config.mode == 'Gold') {
$('head').append('<link rel="stylesheet" media="screen" href="Scripts/Css/Gold.css" type="text/css" >');
document.getElementById('Sv').src = "Scripts/Images/Gold.svg";
}

if (config.mode == 'White') {
$('head').append('<link rel="stylesheet" media="screen" href="Scripts/Css/White.css" type="text/css" >');
document.getElementById('Sv').src = "Scripts/Images/White.svg";
}