function mainUpdate(type) {
if (type === "battery") { updateBattery(); }
if (type === "weather") { checkWeather(); }
}

function checkWeather() {
document.getElementById("Temp").innerHTML = weather.temperature + '°';
}