/* All */
document.documentElement.style.setProperty('--textCl', config.textCl);
document.documentElement.style.setProperty('--ro', config.ro + 's');
document.getElementById("Disc").src="Scripts/Images/" + config.disc + ".png";

/* On off */
if (!config.cal) {
document.getElementById('Weekday').style.display = 'none';
document.getElementById('Calendar').style.display = 'none';
}

if (!config.temp) {
document.getElementById('TempCont').style.display = 'none';
document.getElementById('Weekday').style.top = '9%';
document.getElementById('Calendar').style.top = '17.5%';
}

if (!config.per) {
document.getElementById('PerCont').style.display = 'none';
}

if (!config.dock) {
document.getElementById('Dock').style.display = 'none';
}