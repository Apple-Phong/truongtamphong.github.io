function mainUpdate(type) {
if (type === "weather") { checkWeather(); } 
if (type === "battery") { updateBattery(); }
}

function checkWeather() {
document.getElementById("Day1Icon").src = 'Scripts/Weather/' + weather.dayForecasts[1].icon + ".png";
document.getElementById("Day2Icon").src = 'Scripts/Weather/' + weather.dayForecasts[2].icon + ".png";
document.getElementById("Day3Icon").src = 'Scripts/Weather/' + weather.dayForecasts[3].icon + ".png";
document.getElementById("Day4Icon").src = 'Scripts/Weather/' +  weather.dayForecasts[4].icon + ".png";

document.getElementById("Condition").innerHTML = condition[weather.conditionCode];
document.getElementById('WeatherIcon').src = 'Scripts/Weather/' + weather.conditionCode + '.png';
document.getElementById("City").innerHTML = weather.city.substring(0,24);
document.getElementById("Temp").innerHTML = weather.temperature + '&deg;';
document.getElementById("Hilo").innerHTML = hitext +  ' ' + weather.high + '&deg;' + '. ' + lotext + ' ' + weather.low + '&deg;';
document.getElementById("SubHumi").innerHTML = humtext +  ' ' + weather.humidity + '%' + ' ✫';
document.getElementById("SubWind").innerHTML = windtext +  ' ' + weather.windSpeed + ' km/h' + ' ✫';
document.getElementById("Humi").innerHTML = humtext +  ' ' + weather.humidity + '%' + ' ✫';
document.getElementById("Wind").innerHTML = windtext + ' ' + weather.windSpeed + ' km/h' + ' ✫';
document.getElementById("Rain").innerHTML = raintext +  ' ' + weather.hourlyForecasts[0].percentPrecipitation + '%';
document.getElementById("Precip").innerHTML = raintext +  ' ' + weather.hourlyForecasts[0].percentPrecipitation + '%';
}