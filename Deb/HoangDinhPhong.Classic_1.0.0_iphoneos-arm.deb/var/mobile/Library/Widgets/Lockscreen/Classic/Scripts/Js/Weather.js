function checkWeather() {
document.getElementById('WeatherIcon').src = 'Scripts/Weather/' + weather.conditionCode + '.png';
document.getElementById("Temp").innerHTML = weather.temperature;
document.getElementById("City").innerHTML = weather.city;
document.getElementById("HumiWind").innerHTML = humitext + ' ' + weather.humidity + '% ' + windtext + ' ' + weather.windSpeed + ' km/h';
}