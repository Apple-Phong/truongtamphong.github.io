if (!config.media) {
document.getElementById('ControlBor').style.display = 'none';
document.getElementById('Title').style.display = 'none';
}

document.getElementById('HourText').innerHTML = hourtext;
document.getElementById('PerText').innerHTML = pertext;
document.getElementById('Deg').innerHTML = '°';