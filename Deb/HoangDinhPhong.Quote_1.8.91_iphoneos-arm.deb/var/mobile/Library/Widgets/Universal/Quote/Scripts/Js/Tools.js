var BODY = document.getElementsByTagName("body")[0],
   HEAD = document.getElementsByTagName("head")[0],
   VaExist = function (e, t, n) {
      var r = null,
         i = n || window;
      return r = null == i[e] ? null != t && "function" != typeof t ? t : null : i[e], "function" == typeof t && (r = t(r)), r
   },
   GetInterne = function (e, t) {
      Array.isArray(e) || (e = e.split("/"));
      var n = null,
         r = e[0];
      if (1 == e.length) n = null != t[r] ? t[r] : void 0;
      else {
         if (e.splice(0, 1), null == t[r]) return;
         n = GetInterne(e, t[r])
      }
      return n
   },
   FirstLetterUpperCase = function (e) {
      return e.charAt(0).toUpperCase() + e.slice(1)
   },
   FontSelector = function (e, t, n) {
      var r = -1 != e.indexOf(t) ? t : e[0];
      AddFont(r, "FontSelector", n)
   },
   AddFont = function (e, t, n) {
      t || (t = e), CreatBalise("addFont", "style").appendChild(document.createTextNode("@font-face {  font-family: '" + t + "';  font-style: normal;  font-weight: 400;  src: url(" + (n || "") + e + ".ttf) format('woff2');}"))
   },
   Each = function (e, t) {
      if (Array.isArray(e))
         for (var n = 0; n < e.length && !1 !== t(n, e[n]); n++);
      else
         for (var n in e)
            if (!1 === t(n, e[n])) break
   },
   AddStyleSheet = function (e, t) {
      var n = document.createElement("link");
      n.setAttribute("href", (t ? "" : "") + e + ".css"), n.setAttribute("rel", "stylesheet"), HEAD.appendChild(n)
   },
   OnMinuteChange = function () {
      var e = [],
         t = new Date,
         n = function () {
            t.getMinutes() != (new Date).getMinutes() && (t = new Date, Each(e, (e, t) => t()));
            var r = 1015 - (new Date).getMilliseconds();
            setTimeout(n, r > 0 ? r : 1e3)
         };
      return n(),
         function (t) {
            e.push(t)
         }
   }(),
   Storage = function (e, t, n) {
      var r = localStorage;
      if (!r) return !1;
      switch (e) {
         case 0:
            let i = r.getItem(t);
            return !!i && (n ? JSON.parse(i) : i);
         case 1:
            return null != n && null != n && "object" == typeof n && (n = JSON.stringify(n)), r.setItem(t, n) || !1;
         case 2:
            return r.removeItem(t) || !1;
         case 3:
            return r.clear() || !1
      }
   },
   Div = function (e) {
      this.Current = CreatBalise(e, "div"), this.Append = function (e) {
         this.Current.appendChild(e)
      }, this.Clear = function () {
         this.Current.innerHTML = ""
      }, this.AppendScript = function (e, t) {
         var n = document.createElement("script");
         n.setAttribute("src", e), t && (n.onload = t), this.Append(n)
      }
   },
   CreatBalise = function (e, t) {
      if (!document.getElementById(e)) {
         let n = document.createElement(t);
         n.setAttribute("id", e), BODY.appendChild(n)
      }
      return document.getElementById(e)
   },
   IsDOMElement = function (e) {
      return "object" == typeof HTMLElement ? e instanceof HTMLElement : e && "object" == typeof e && null !== e && 1 === e.nodeType && "string" == typeof e.nodeName
   },
   RemoveAccent = function (e) {
      return e.normalize("NFD").replace(/[\u0300-\u036f]/g, "")
   };