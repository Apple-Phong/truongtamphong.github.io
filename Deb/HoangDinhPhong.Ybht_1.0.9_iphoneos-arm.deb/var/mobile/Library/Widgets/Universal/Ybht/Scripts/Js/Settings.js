document.getElementById("YourName").style.color = config.AllColor;
document.getElementById("Battery").style.color = config.AllColor;
document.getElementById("Hour").style.color = config.AllColor;
document.getElementById("City").style.color = config.AllColor;
document.getElementById("Calendar").style.value = config.bulkhead;
document.documentElement.style.setProperty('--br', config.br + 'px');
document.documentElement.style.setProperty('--bgBlur', config.bgBlur + 'px');
document.getElementById("Container").style.webkitTransform = 'scale(' + config.Scale + ')';
document.getElementById("YourName").innerHTML = config.YourName;

if (!config.batName) {
document.getElementById("Battery").style.display = 'none';
document.getElementById("YourName").style.display = 'block';
}

if (!config.shadow) {
document.getElementById(".shadow-line").style.display = 'none';
document.getElementById(".shadow-time").style.display = 'none';
}

/* Shadow */
if (window.config.shadow == "in") {
document.getElementById('LineL').classList.remove('shadow-line');
document.getElementById('LineL').classList.add('shadow-off');
document.getElementById('LineC').classList.remove('shadow-line');
document.getElementById('LineC').classList.add('shadow-off');
document.getElementById('LineR').classList.remove('shadow-line');
document.getElementById('LineR').classList.add('shadow-off');
document.getElementById('TimeCont').classList.remove('shadow-time');
document.getElementById('TimeCont').classList.add('shadow-off');
document.getElementById('Container').classList.remove('text-shadow');
document.getElementById('Container').classList.add('shadow-off');
}