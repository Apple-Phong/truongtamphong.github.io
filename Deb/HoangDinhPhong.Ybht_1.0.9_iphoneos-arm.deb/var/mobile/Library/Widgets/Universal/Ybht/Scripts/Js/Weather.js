function mainUpdate(type) {
if (type === "weather") { checkWeather(); }
if (type === "battery") { updateBattery(); }

function checkWeather() {
document.getElementById('City').innerHTML = weather.city;
document.getElementById('Condition').innerHTML = condition[weather.conditionCode] + ' ' + weather.temperature + '°C';
document.getElementById('HiLo').innerHTML = hightext + ' ' + weather.high + '°' + ' / ' + lowtext + ' ' + weather.low + '°';
}
}

checkWeather();

function checkWeather() {
setInterval(function () {
window.location.reload();
}, 7200000);
}