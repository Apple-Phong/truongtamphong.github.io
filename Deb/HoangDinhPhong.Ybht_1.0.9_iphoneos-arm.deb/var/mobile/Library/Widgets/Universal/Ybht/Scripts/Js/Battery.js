function updateBattery() {
var batt = document.getElementById("Battery");

if (batteryCharging === 1) {
batt.innerHTML = batteryPercent + "% " + charging;
} else {
batt.innerHTML = battext + ' ' + batteryPercent + "%";
}
}