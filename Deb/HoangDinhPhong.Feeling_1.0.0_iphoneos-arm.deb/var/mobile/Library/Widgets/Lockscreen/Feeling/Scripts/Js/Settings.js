// Color
document.documentElement.style.setProperty('--bgCl', config.bgCl);
document.documentElement.style.setProperty('--textCl', config.textCl);
document.documentElement.style.setProperty('--dotCl', config.dotCl);
document.documentElement.style.setProperty('--secondary', config.secondary);
document.documentElement.style.setProperty('--hrsCl', config.hrsCl);
document.documentElement.style.setProperty('--minCl', config.minCl);
document.documentElement.style.setProperty('--alCl', config.alCl);

// Other
document.getElementById('TodayText').innerHTML = todaytext;