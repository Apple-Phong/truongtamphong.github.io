var action = {};
action.replaceElements = function () {

/*---------- Settings ----------*/

action.Settings = function (id) {
div = document.createElement('div');
div.id = id;
document.getElementById('SettingsCont').appendChild(div); return div; };

var Settings = action.savedElements.Settings;
Object.keys(Settings).forEach(function (elementName) {
createdDiv = action.Settings(elementName);
elementStyles = Settings[elementName];
action.loadStyles(elementName, elementStyles, createdDiv); });

/*---------- Messenger ----------*/

action.Messenger = function (id) {
div = document.createElement('div');
div.id = id;
document.getElementById('MessengerCont').appendChild(div); return div; };

var Messenger = action.savedElements.Messenger;
Object.keys(Messenger).forEach(function (elementName) {
createdDiv = action.Messenger(elementName);
elementStyles = Messenger[elementName];
action.loadStyles(elementName, elementStyles, createdDiv); });

/*---------- Facebook ----------*/

action.Facebook = function (id) {
div = document.createElement('div');
div.id = id;
document.getElementById('FacebookCont').appendChild(div); return div; };

var Facebook = action.savedElements.Facebook;
Object.keys(Facebook).forEach(function (elementName) {
createdDiv = action.Facebook(elementName);
elementStyles = Facebook[elementName];
action.loadStyles(elementName, elementStyles, createdDiv); });

/*---------- Note ----------*/

action.Note = function (id) {
div = document.createElement('div');
div.id = id;
document.getElementById('NoteCont').appendChild(div);
return div; };

var Note = action.savedElements.Note;
Object.keys(Note).forEach(function (elementName) {
createdDiv = action.Note(elementName);
elementStyles = Note[elementName];
action.loadStyles(elementName, elementStyles, createdDiv); });

/*---------- YouTube ----------*/

action.YouTube = function (id) {
div = document.createElement('div');
div.id = id;
document.getElementById('YouTubeCont').appendChild(div); return div; };

var YouTube = action.savedElements.YouTube;
Object.keys(YouTube).forEach(function (elementName) {
createdDiv = action.YouTube(elementName);
elementStyles = YouTube[elementName];
action.loadStyles(elementName, elementStyles, createdDiv); });
};