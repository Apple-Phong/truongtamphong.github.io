/* Scale */
document.body.style.webkitTransform = 'scale(' + config.Scale + ')';

/* Set */
document.documentElement.style.setProperty('--sec', config.sec + 's');
document.documentElement.style.setProperty('--height', config.height + 'px');
document.documentElement.style.setProperty('--length', config.length + 'px');

/* Color */
document.documentElement.style.setProperty('--textCl', config.textCl);
document.documentElement.style.setProperty('--dotCl', config.dotCl);
document.documentElement.style.setProperty('--ringCl', config.ringCl);
document.documentElement.style.setProperty('--circleCl', config.circleCl);