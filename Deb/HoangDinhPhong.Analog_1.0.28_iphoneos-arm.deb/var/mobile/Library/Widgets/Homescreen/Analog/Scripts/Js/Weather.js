function mainUpdate(type) {
   if (type === "weather") {
      checkWeather();
   }
}

function checkWeather() {
   document.getElementById("City").innerHTML = weather.city;
   document.getElementById("WeatherInfo").innerHTML = condition[weather.conditionCode] + '. ' + temptext + weather.temperature + '° <br>' + humitext + weather.humidity + '%' + '. ' + windtext + weather.windSpeed + ' km/h' + '. ' + '<br>' + raintext + weather.hourlyForecasts[0].percentPrecipitation + '%...';
   document.getElementById('Day1').src = 'Scripts/Weather/' + config.IconSet + '/' + weather.dayForecasts[1].icon + '.png';
   document.getElementById('Day2').src = "Scripts/Weather/" + config.IconSet + '/' + weather.dayForecasts[2].icon + ".png";
   document.getElementById('Day3').src = "Scripts/Weather/" + config.IconSet + '/' + weather.dayForecasts[3].icon + ".png";
   document.getElementById('Day4').src = "Scripts/Weather/" + config.IconSet + '/' + weather.dayForecasts[4].icon + ".png";
}