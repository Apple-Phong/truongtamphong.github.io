var hour = -1,
   mins = -1;
var Clock = "12h";

function updateClock() {
   var currentTime = new Date();
   var currentHours = currentTime.getHours();
   var currentMinutes = currentTime.getMinutes();
   var currentMinutes1 = currentTime.getMinutes();
   var currentMinutesunit = currentTime.getMinutes();
   var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
   var currentSeconds2 = currentTime.getSeconds();
   var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
   var currentYear = currentTime.getFullYear();
   var th, pm = '',
      i;
   if (Clock === "24h") {
      currentHours = (currentHours < 10 ? "0" : "") + currentHours;
      currentMinutes1 = (currentMinutes1 < 10 ? "0" : "") + currentMinutes1;
      currentTimeString = currentHours + currentMinutes + currentMinutesunit;
   }
   if (Clock === "12h") {
      if (currentHours > 12) {
         pm = 'pm';
      } else {
         pm = 'am';
      }
      currentHours = (currentHours > 12) ? currentHours - 12 : currentHours;
      currentHours = (currentHours == 0) ? 12 : currentHours;
      currentMinutes1 = (currentMinutes1 < 10 ? "0" : "") + currentMinutes1;
      currentTimeString = currentHours + currentMinutes + currentMinutesunit;
   }
   if (mins !== currentMinutes) {
      mins = currentMinutes;
      for (i = 0; i < 60; i++) {
         document.getElementById("Cir" + i).classList.remove('Change-color');
      }
      document.getElementById("Cir" + mins).classList.add('Change-color');
   }
   for (i = 0; i < 60; i++) {
      document.getElementById("Tl" + i).classList.remove('Change-color');
   }
   document.getElementById("Tl" + currentSeconds2).classList.add('Change-color');
   document.getElementById("HourTxt").innerHTML = currentHours;
   document.getElementById("MinTxt").innerHTML = currentMinutes1;

   //analog clock
   var rotM = currentTime.getMinutes() * 6;
   document.getElementById("MinH").style.transform = 'rotate(' + rotM + 'deg)';
   var rotH = currentTime.getHours() * 30;
   document.getElementById("HourH").style.transform = 'rotate(' + rotH + 'deg)';
   if (config.ro) {
      document.getElementById("MinTxt").style.transform = 'rotate(-' + rotM + 'deg)';
      document.getElementById("HourTxt").style.transform = 'rotate(-' + rotH + 'deg)';
   }
   document.getElementById("Date").innerHTML = shortdays[currentTime.getDay()] + '|' + currentDate;

   if (hour !== currentHours) {
      if (currentHours === 12) {
         currentHours = 0;
      }
      hour = currentHours;
      for (var j = 0; j < 12; j++) {
         document.getElementById("Hour" + j).classList.remove('Num-hour');
      }
      document.getElementById("Hour" + hour).classList.add('Num-hour');
   }
}