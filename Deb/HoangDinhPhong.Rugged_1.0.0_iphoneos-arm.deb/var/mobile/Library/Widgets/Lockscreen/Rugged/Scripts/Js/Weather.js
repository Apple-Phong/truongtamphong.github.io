function mainUpdate(type) {
if (type === "weather") { checkWeather(); }
}

function checkWeather() {
document.getElementById("WeInfo").innerHTML = intext + ' ' + weather.city + '<br>' + condition[weather.conditionCode] + ' ' + weather.temperature + '°' + '<br>' + windtext + ' ' + weather.windSpeed + 'km/h, ' + humitext + ' ' + weather.humidity + '%, ' + raintext + ' ' + weather.hourlyForecasts[0].percentPrecipitation + '%';
}