function mainUpdate(type) {
if (type === "weather") { checkWeather(); }
}

function checkWeather() {
document.getElementById('WeatherIcon').src = 'Scripts/Weather/' + weather.conditionCode + '.png';
document.getElementById("Temp").innerHTML = weather.temperature + '°';
document.getElementById("High").innerHTML = '⇡' + ' ' + weather.high + '°';
document.getElementById("Low").innerHTML = '⇣' + ' ' + weather.low + '°';
document.getElementById("City").innerHTML = weather.city;
document.getElementById("Condition").innerHTML = condition[weather.conditionCode];
}