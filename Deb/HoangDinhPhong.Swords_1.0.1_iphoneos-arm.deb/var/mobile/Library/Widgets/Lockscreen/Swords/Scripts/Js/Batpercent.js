function updateBattery() {
document.getElementById("Percentage").innerHTML = batteryPercent; 

document.getElementById("Charging").innerHTML = (batteryCharging) ? charging : notcharging;

if (batteryCharging === 1) {
document.getElementById("BatIcon").style.display = 'none';
} else {
document.getElementById("BatIcon").style.display = '';
  }
}