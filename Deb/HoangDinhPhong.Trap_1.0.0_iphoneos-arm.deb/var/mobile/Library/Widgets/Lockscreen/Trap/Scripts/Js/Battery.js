function mainUpdate(type) {
if (type === "battery"){ updateBattery(); }
if (type === "weather") { checkWeather(); }
}

function updateBattery() {
document.getElementById("Battery").style.width = batteryPercent + "%";
document.getElementById("Percentage").innerHTML = batteryPercent + '%';
}