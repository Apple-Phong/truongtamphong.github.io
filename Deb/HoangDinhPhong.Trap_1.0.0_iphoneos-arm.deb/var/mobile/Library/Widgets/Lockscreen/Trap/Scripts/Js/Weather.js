function checkWeather() {
document.getElementById('WeatherIcon').src = 'Scripts/Weather/' + weather.conditionCode + '.png';
document.getElementById("City").innerHTML = weather.city;
document.getElementById("Condition").innerHTML = condition[weather.conditionCode] + ' ' + weather.temperature + '°';
document.getElementById("HiLo").innerHTML = hitext + ' ' + weather.high + '°. ' + lotext + ' ' + weather.low + '°';
document.getElementById("WindHumi").innerHTML = windtext + ' ' + weather.windSpeed + ' km/h' + '<br>' + humitext + ' ' + weather.humidity + '%';
}