if (!config.al) {
document.getElementById('AmLich').style.display = 'none';
}

if (!config.mu) {
document.getElementById('Controls').style.display = 'none';
document.getElementById('CtrlBg').style.display = 'none';
document.getElementById('Title').style.display = 'none';
document.getElementById('Artist').style.display = 'none';
document.getElementById('AmLich').style.top = '80%';
}