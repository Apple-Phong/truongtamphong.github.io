function BP() {
var days_month = new Array(31,28,31,30,31,30,31,31,30,31,30,31);
var Calendar = new Date();
var month = Calendar.getMonth();
var today = Calendar.getDate();
var day = Calendar.getDay();
var num_days = 7;
var day;
var cal;
cal = '<table>';
cal += '<table cellpadding="0" cellspacing="0" border="0"><tr>';
var day = day;
for(index=0; index < num_days; index++) {
if (day == index)
cal += '<td class="day">' + sday[index] + '</td>';
else
cal += '<td class="weekday">' + sday[index] + '</td>';
}

cal += '</tr><tr>';
for(index=0; index < num_days; index++) {
var yesterday_tomorrow = today - (day-index);
var this_month = days_month[month];
if (day == index)
cal += '<td class="today">' + today + '</td>';
else if (yesterday_tomorrow < this_month+1 & yesterday_tomorrow > 0)
cal += '<td class="todays">' + yesterday_tomorrow + '</td>';
else
cal += '<td class="todays"></td>';
}

cal += '</tr></table>';
document.getElementById("Weekday").innerHTML = cal;
setTimeout("BP()",1000);
}

window.addEventListener("load", BP, false);