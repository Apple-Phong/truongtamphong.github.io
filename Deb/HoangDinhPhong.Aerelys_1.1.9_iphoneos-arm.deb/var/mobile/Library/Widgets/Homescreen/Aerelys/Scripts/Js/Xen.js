function mainUpdate(type){ 
if(type === "weather"){if(we === 1)
checkWeather();}
else if (type === "music"){if(mu === 1)
checkMusic();}
else if (type === "battery"){if(ba === 1)
updateBattery();}}
function checkWeather(){
document.getElementById('weatherIcon').src = 'Scripts/Weather/' + IconSet + '/' + weather.conditionCode + '.png';
document.getElementById('condition').innerHTML = condition[weather.conditionCode];
document.getElementById('tempe').innerHTML = weather.temperature;
document.getElementById('mm').innerHTML = weather.low + 'º' + " / " + weather.high + 'º';}
var activate = true;
function updateBattery() {
document.getElementById("percentage").innerHTML = batteryPercent + '%';
if(batteryPercent > 80 && batteryPercent <= 100){
document.documentElement.style.setProperty('--batC', '#2073ee');}
if(batteryPercent > 60 && batteryPercent <= 80){
document.documentElement.style.setProperty('--batC', '#24ebd8');}
if(batteryPercent > 40 && batteryPercent <= 60){
document.documentElement.style.setProperty('--batC', '#4bec69');}
if(batteryPercent > 20 && batteryPercent <= 40){
document.documentElement.style.setProperty('--batC', '#ec7f0c');}
if(batteryPercent >= 0 && batteryPercent <= 20){
document.documentElement.style.setProperty('--batC', '#f51355');}
if(batteryCharging === 1){
if(activate){
activate = false;
document.getElementById("blCont").style.opacity = 0.2;
setTimeout(function (){
document.getElementById("blCont").style.opacity = 1;
activate = true;}, 4000);}}}