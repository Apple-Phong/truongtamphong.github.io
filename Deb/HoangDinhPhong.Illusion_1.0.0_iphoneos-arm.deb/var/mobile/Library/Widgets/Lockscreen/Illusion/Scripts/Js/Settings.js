// Other
document.getElementById('Hello').innerHTML = hellotext;
document.getElementById('YourName').innerHTML = config.name;
document.getElementById('InText').innerHTML = intext;
document.getElementById('HiText').innerHTML = hitext;
document.getElementById('LoText').innerHTML = lotext;
document.getElementById('WindText').innerHTML = windtext;
document.getElementById('Wish').innerHTML = config.wish;