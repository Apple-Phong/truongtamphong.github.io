var iPhoneType = "auto";
if (iPhoneType == "auto") {
if (screen.height == 780) { iPhoneType = "iPhMini" }
else if (screen.height == 812) { iPhoneType = "iPhX11P" }
else if (screen.height == 896) { iPhoneType = "iPh11M" }
else if (screen.height == 844) { iPhoneType = "iPh12P" }
else if (screen.height == 926) { iPhoneType = "iPh12M" }
}

window.addEventListener("load", function () {
switch (iPhoneType) {

case "iPhMini":
document.body.style.width = '360px';
document.body.style.height = '780px';
$("#Clock").css({ "font-size": "35px" });
$("#BatteryInfo").css({ "font-size": "10px", "line-height":"14px" });
$("#Temp").css({ "font-size": "19px" });
$("#WeInfo").css({ "font-size": "10px" });
$("#Wish").css({ "font-size": "13px" });
$("#Month").css({ "font-size": "40px" });
$("#Date").css({ "font-size": "22px" });
$("#Weekday").css({ "font-size": "12px" });
break;

case "iPhX11P":
document.body.style.width = '375px';
document.body.style.height = '812px';
$("#Clock").css({ "font-size": "37px" });
$("#BatteryInfo").css({ "font-size": "10px", "line-height":"14px" });
$("#Month").css({ "font-size": "43px" });
break;

case "iPh11M":
document.body.style.width = '414px';
document.body.style.height = '896px';
break;

case "iPh12P":
document.body.style.width = '390px';
document.body.style.height = '844px';
$("#Clock").css({ "font-size": "38px" });
$("#BatteryInfo").css({ "line-height":"14px" });
break;

case "iPh12M":
document.body.style.width = '428px';
document.body.style.height = '926px';
$("#Clock").css({ "font-size": "41px" });
break;
}
}, false);