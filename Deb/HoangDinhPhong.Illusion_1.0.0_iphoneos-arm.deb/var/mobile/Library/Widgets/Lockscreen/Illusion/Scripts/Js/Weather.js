function mainUpdate(type) {
if (type == "battery") { injectedSystem.battery = batteryPercent }
if (type === "weather") { checkWeather() }
}

function checkWeather() {
document.getElementById('WeatherIcon').src = 'Scripts/Weather/' + weather.conditionCode + '.svg';
document.getElementById("Temp").innerHTML = weather.temperature + '°C';
document.getElementById("City").innerHTML = weather.city;
document.getElementById("Condition").innerHTML = condition[weather.conditionCode];
document.getElementById("Wind").innerHTML = weather.windSpeed;
document.getElementById("High").innerHTML = weather.high + '°';
document.getElementById("Low").innerHTML = weather.low + '°';
}