function checkBattery(newData) {
document.getElementById('Percentage').innerHTML = pertext + ' ' + newData.battery.percentage + '%' + '<br>' + timetext+ ' ' + newData.battery.timeUntilEmpty + ' ' + minutetext + '<br>';
document.getElementById("Charging").innerHTML = (batteryCharging) ? charging : notcharging;

if (batteryPercent > 0) {
document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Images/5.png" height="20px">';
}

if (batteryPercent > 10) {
document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Images/10.png" height="20px">';
}

if (batteryPercent > 20) {
document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Images/20.png" height="20px">';
}

if (batteryPercent > 30) {
document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Images/30.png" height="20px">';
}

if (batteryPercent > 40) {
document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Images/40.png" height="20px">';
}

if (batteryPercent > 50) {
document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Images/50.png" height="20px">';
}

if (batteryPercent > 60) {
document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Images/60.png" height="20px">';
}

if (batteryPercent > 70) {
document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Images/70.png" height="20px">';
}

if (batteryPercent > 80) {
document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Images/80.png" height="20px">';
}

if (batteryPercent > 90) {
document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Images/90.png" height="20px">';
}

if (batteryPercent == 100) {
document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Images/100.png" height="20px">';
}
}

function XenApi() {
api.resources.observeData(function (newData) {
checkBattery(newData); });
}

function HDP() {
XenApi();
}

window.addEventListener("load", HDP, false);