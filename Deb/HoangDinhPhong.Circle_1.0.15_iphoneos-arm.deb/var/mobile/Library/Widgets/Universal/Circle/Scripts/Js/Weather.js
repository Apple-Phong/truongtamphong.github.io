function mainUpdate(type) {
if (type === "weather") { checkWeather(); }
}

function checkWeather() {
document.getElementById('WeIcon').src = 'Scripts/Weather/' + weather.conditionCode + '.png';
document.getElementById("Temp").innerHTML = weather.temperature + '&deg;' + 'C';
}