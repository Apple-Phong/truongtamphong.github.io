/* Scale, shadow size & blur */
document.body.style.webkitTransform = 'scale(' + config.Scale + ')';
document.documentElement.style.setProperty('--shSize', config.shSize + 'px');
document.documentElement.style.setProperty('--bl', config.bl + 'px');

/* Color */
document.documentElement.style.setProperty('--clockCirCl', config.clockCirCl);
document.documentElement.style.setProperty('--calCirCl', config.calCirCl);
document.documentElement.style.setProperty('--tempCirCl', config.tempCirCl);
document.documentElement.style.setProperty('--weCirCl', config.weCirCl);

document.documentElement.style.setProperty('--clockCl', config.clockCl);
document.documentElement.style.setProperty('--dateCl', config.dateCl);
document.documentElement.style.setProperty('--weekMonthCl', config.weekMonthCl);
document.documentElement.style.setProperty('--tempCl', config.tempCl);

/* On off */
if (!config.Ae) {
document.getElementById('ClockAe').style.display = 'none';
document.getElementById('CalAe').style.display = 'none';
document.getElementById('TempAe').style.display = 'none';
document.getElementById('WeAe').style.display = 'none';
}