function mainUpdate(type) {

if (type == "battery") { injectedSystem.battery = batteryPercent; }

if (batteryCharging === 1) {
document.getElementById("Charging").style.display = 'block';
} else {
document.getElementById("Charging").style.display = ''; }

if (type === "weather") { checkWeather(); }
}

function checkWeather() {
document.getElementById('WeatherIcon').src = 'Scripts/Weather/' + weather.conditionCode + '.svg';
document.getElementById("WeInfo").innerHTML = weather.city + ' ' + condition[weather.conditionCode] + ' ' + weather.temperature + '°'  + '<br>' + humitext + ' ' + weather.humidity + '%' + '<br>' + windtext + ' ' + weather.windSpeed + ' km/h' + '<br>' + raintext + ' ' + weather.hourlyForecasts[0].percentPrecipitation + '%';
}