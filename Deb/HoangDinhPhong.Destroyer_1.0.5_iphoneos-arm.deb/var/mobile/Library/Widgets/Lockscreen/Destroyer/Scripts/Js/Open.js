function addStyleString(str, id) {
var doc = document;
node = doc.createElement('style');
node.innerHTML = str;
doc.body.appendChild(node);
}

function webviewOpenApp() {
window.location = 'xeninfo:openapp:' + appToOpen;
}

document.getElementById('HDP').addEventListener('touchend', function (el) {
if (el.target.id.substring(0, 4) === 'Open') {
appToOpen = document.getElementById(el.target.id).getAttribute('bundleID');
webviewOpenApp(appToOpen);
}
});

action.loadStyles = function(key, value, createdDiv) {
Object.keys(value).forEach(function(skey) {
styleVal = value[skey];

if (skey === 'BundleID') {
createdDiv.setAttribute(skey, styleVal);
} else if (skey === 'circle-width') {
addStyleString('.circle-progress-'+createdDiv.title+'{ width:' + styleVal + ';height:' + styleVal + '; }', 'circlewidth' + createdDiv.title);
} else if (skey === 'circle-stroke') {
addStyleString('.circle-progress-circle'+createdDiv.title+'{ stroke-width:' + styleVal + '; }', 'circlestroke' + createdDiv.title);
} else if (skey === 'circle-stroke-dasharray') {
addStyleString('.circle-progress-value'+createdDiv.title+'{ stroke-dasharray:' + styleVal + ' 2; }', 'circlestrokedash'+ createdDiv.title);
} else if (skey === 'circle-stroke-value') {
addStyleString('.circle-progress-value'+createdDiv.title+'{ stroke-width:' + styleVal + '; }', 'circlestrokevalue'+ createdDiv.title);
} else if (skey === 'outer-color') {
addStyleString('.circle-progress-value'+createdDiv.title+'{ stroke:' + styleVal + '; }', 'circleoutercolor'+ createdDiv.title);
} else if (skey === 'inner-color') {
addStyleString('.circle-progress-circle'+createdDiv.title+'{ stroke:' + styleVal + '; }', 'circleinnercolor'+ createdDiv.title);
} else if (skey === 'circle-cap') {
addStyleString('.circle-progress-value'+createdDiv.title+'{ stroke-linecap:'+styleVal+'; }', 'circlestrokecap'+ createdDiv.title);
} else {
if (skey === 'scale') {
document.getElementById(key).style.webkitTransform = 'scale(' + styleVal + ')';
} try {
createdDiv.style[skey] = styleVal;
} catch (err) {
}
}
});
};

function isExportedInfo() {
if (typeof savedElements !== 'undefined') {
return savedElements;
}
}

function setStoredElements() {
if (isExportedInfo()) {
action.savedElements = savedElements;
return action.savedElements;
}
}

action.loadFromStorage = function () {
var elements = setStoredElements();
if (elements) {
action.replaceElements();
}
};

function loadInfo() {
action.loadFromStorage();
}

window.onload = function () {
loadInfo();
};