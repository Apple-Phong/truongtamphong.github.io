const number_of_flakes = config.SnowNumber;
const number_of_images = 33;

function init() {
var container = document.getElementById("Flake");
for (var i = 0; i < number_of_flakes; i++) {
container.appendChild(createAFlake());
}
}

function randomInteger(low, high) {
return low + Math.floor(Math.random() * (high - low));
}

function randomFloat(low, high) {
return low + Math.random() * (high - low);
}

function pixelValue(value) {
return value + "px";
}

function durationValue(value) {
return value + "s";
}

function createAFlake() {
var flakeDiv = document.createElement("div");
var image = document.createElement("img"); 
image.src = "HDP/Images/" + config.IconSet + "/Flake" + randomInteger(1, number_of_images) + ".png";
flakeDiv.style.top = pixelValue(randomInteger(-150, -50));
flakeDiv.style.left = pixelValue(randomInteger(0, 812));
var spinAnimationName = (Math.random() < 0.5) ? "Spin" : "SpinFlip";
flakeDiv.style.webkitAnimationName = "Fade, Drop";
image.style.webkitAnimationName = spinAnimationName;
var fadeAndDropDuration = durationValue(randomFloat(10, 60));
var spinDuration = durationValue(randomFloat(4, 8));
flakeDiv.style.webkitAnimationDuration = fadeAndDropDuration + ", " + fadeAndDropDuration;
image.style.webkitAnimationDuration = spinDuration;
flakeDiv.appendChild(image);
return flakeDiv;
}

window.addEventListener("load", init, false);