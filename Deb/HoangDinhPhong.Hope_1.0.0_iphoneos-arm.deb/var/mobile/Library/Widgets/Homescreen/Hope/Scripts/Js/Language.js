if (window.config.language == "Vietnamese") {
var nighttext = "Chúc ngủ ngon";
var evetext = "Chào buổi tối";
var aftertext = "Chào buổi chiều";
var noontext = "Chào buổi trưa";
var morningtext = "Chào buổi sáng";
var charging = "Đang sạc...";
var notcharging = "Chưa sạc";
var todaytext = "Hôm nay";
var titletext = "✯ Âm Nhạc ✯ ࿐♪ ♫ ༄";
var sday = ["CN", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7"];
var days = ["Chủ Nhật", "Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy"];
}

if (window.config.language == "English") {
var nighttext = "Good night";
var evetext = "Good evening";
var aftertext = "Good afternoon";
var noontext = "Good noon";
var morningtext = "Good morning";
var charging = "Charging...";
var notcharging = "Not Charging";
var todaytext = "Today";
var titletext = "✯ Music ✯ ࿐♪ ♫ ༄";
var sday = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
}