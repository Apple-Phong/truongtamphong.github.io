function clock(options) {
var getTimes = function () {
var d = new Date(),
funcs = {

day: function () {
return d.getDay();
},

datepadded: function () {
return (d.getDate() < 10) ? "0" + d.getDate() : d.getDate();
},

tod: function () {
return (d.getHours() < 11 ? morningtext : d.getHours() < 13 ? noontext : d.getHours() < 18 ? aftertext : d.getHours() < 22 ? evetext : nighttext);
}
};

options.success(funcs);
setTimeout(function () {
getTimes();
}, options.refresh);
};
getTimes();
}

clock({
refresh: 5000,
success:

function (clock) {
document.getElementById('Tod').innerHTML = clock.tod();
document.getElementById('Date').innerHTML = clock.datepadded();
document.getElementById('Weekday').innerHTML = days[clock.day()];
}
});