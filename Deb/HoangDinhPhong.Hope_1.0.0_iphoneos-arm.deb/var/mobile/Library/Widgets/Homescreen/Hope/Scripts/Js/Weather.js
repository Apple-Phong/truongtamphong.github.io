function checkWeather() {
document.getElementById('WeatherIcon').src = 'Scripts/Weather/' + weather.conditionCode + '.svg';
document.getElementById("Temp").innerHTML = weather.temperature + '°C';

document.getElementById("Day1").innerHTML = sday[weather.dayForecasts[1].dayOfWeek - 1];
document.getElementById("Day2").innerHTML = sday[weather.dayForecasts[2].dayOfWeek - 1];

document.getElementById("Day1Icon").src = "Scripts/Weather/" + weather.dayForecasts[1].icon + ".svg";
document.getElementById("Day2Icon").src = "Scripts/Weather/" + weather.dayForecasts[2].icon + ".svg";

document.getElementById("Day1Hi").innerHTML = weather.dayForecasts[1].high + '°C';
document.getElementById("Day2Hi").innerHTML = weather.dayForecasts[2].high + '°C';

document.getElementById('Device').innerHTML = deviceType;
}