function mainUpdate(type) {
document.getElementById("Percentage").innerHTML = batteryPercent + "%";
document.getElementById("Charging").innerHTML = (batteryCharging) ? charging : notcharging;

if (batteryPercent > 0) {
document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Images/5.png" height="10px">';
}

if (batteryPercent > 10) {
document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Images/10.png" height="10px">';
}

if (batteryPercent > 20) {
document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Images/20.png" height="10px">';
}

if (batteryPercent > 30) {
document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Images/30.png" height="10px">';
}

if (batteryPercent > 40) {
document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Images/40.png" height="10px">';
}

if (batteryPercent > 50) {
document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Images/50.png" height="10px">';
}

if (batteryPercent > 60) {
document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Images/60.png" height="10px">';
}

if (batteryPercent > 70) {
document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Images/70.png" height="10px">';
}

if (batteryPercent > 80) {
document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Images/80.png" height="10px">';
}

if (batteryPercent > 90) {
document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Images/90.png" height="10px">';
}

if (batteryPercent == 100) {
document.getElementById("BatteryIcon").innerHTML = '<img src="Scripts/Images/100.png" height="10px">';
}

if (type === "weather") { checkWeather(); }
}