// On off
if (!config.app) {
document.getElementById('RowTop').style.display = 'none';
document.getElementById('RowCen').style.display = 'none';
document.getElementById('RowBot').style.display = 'none';
}

if (!config.dot) {
document.getElementById('DotL1').style.display = 'none';
document.getElementById('DotL2').style.display = 'none';
document.getElementById('DotL3').style.display = 'none';
document.getElementById('DotR1').style.display = 'none';
document.getElementById('DotR2').style.display = 'none';
document.getElementById('DotR3').style.display = 'none';
}

if (!config.mu) {
document.getElementById('ControlBor').style.display = 'none';
document.getElementById('LineBot').style.display = 'none';
document.getElementById('Title').style.display = 'none';
document.getElementById('Device').style.display = 'none';
}

if (!config.bat) {
document.getElementById('BatCont').style.display = 'none';
document.getElementById('BatteryIcon').style.display = 'none';
}

// Other
document.getElementById('TodayText').innerHTML = todaytext;