function checkMusic(newData) {
document.getElementById('YouTube').src = newData.nowPlaying.artwork.length > 0 ? newData.nowPlaying.artwork : 'Scripts/Js/Blank.js';

if (isplaying === 1) {
document.getElementById('Album').style.animation = 'fading 1s linear 1 forwards';
document.getElementById('YouTube').style.animation = 'fading 1s linear 1 forwards';
document.getElementById('PlayPause').classList.remove("ButtonPlay");
document.getElementById('PlayPause').classList.add("ButtonPause");
} else {
document.getElementById('Album').style.animation = 'fadingout 1s linear 1 forwards';
document.getElementById('YouTube').style.animation = 'fadingout 1s linear 1 forwards';
document.getElementById('PlayPause').classList.remove("ButtonPause");
document.getElementById('PlayPause').classList.add("ButtonPlay");
}

if (title === "(null)") {
document.getElementById('Title').innerHTML = titletext;
document.getElementById('Artist').innerHTML = artisttext;
} else {
document.getElementById('Title').innerHTML = title;
document.getElementById('Artist').innerHTML = artist;
if (checkOverflow(document.getElementById('Title')) === true) {
document.getElementById('Title').classList.add("Marquee");
} else {
document.getElementById('Title').classList.remove("Marquee");
  }
}

if (album === "(null)") {
document.getElementById('Album').src = 'Scripts/Js/Blank.js';
} else {
var xhr = new XMLHttpRequest();
xhr.open('HEAD', "file:///var/mobile/Documents/Artwork.jpg", false);
xhr.send();

if (xhr.status === "404") {
document.getElementById('Album').src = 'Scripts/Js/Blank.js';
} else {
document.getElementById('Album').src = "file:///var/mobile/Documents/Artwork.jpg?" + (new Date()).getTime();
      }
   }
}

function checkOverflow(el) {
var curOverflow = el.style.overflow;
if (!curOverflow || curOverflow === "visible") {
el.style.overflow = "none";
}

var isOverflowing = el.clientWidth < el.scrollWidth;
el.style.overflow = curOverflow;
return isOverflowing;
}

function XenApi() {
api.media.observeData(function (newData) {
appPlaying = newData.nowPlayingApplication.identifier;
checkMusic(newData); });
}

function HDP() {
XenApi();
}

function openApp(app) {
api.apps.launchApplication(app);
}

function playPause() {
window.location = 'xeninfo:playpause';
document.getElementById('PlayBg').style.opacity = 0.2;
document.getElementById('PlayPause').style.opacity = 0.2;
setTimeout(function () {
document.getElementById('PlayBg').style.opacity = 1;
document.getElementById('PlayPause').style.opacity = 1;
}, 200);
}

function next() {
window.location = 'xeninfo:nexttrack';
 document.getElementById('Album').style.animation = 'fadingout 1s linear 1 forwards';
document.getElementById('YouTube').style.animation = 'fadingout 1s linear 1 forwards';
document.getElementById('Next').style.opacity = 0.2;
document.getElementById('NextBg').style.opacity = 0.2;
setTimeout(function () {
document.getElementById('Next').style.opacity = 1;
document.getElementById('NextBg').style.opacity = 1;
}, 200);
}

function prev() {
window.location = 'xeninfo:prevtrack';
document.getElementById('Album').style.animation = 'fadingout 1s linear 1 forwards';
document.getElementById('YouTube').style.animation = 'fadingout 1s linear 1 forwards';
document.getElementById('Prev').style.opacity = 0.2;
document.getElementById('PrevBg').style.opacity = 0.2;
setTimeout(function () {
document.getElementById('Prev').style.opacity = 1;
document.getElementById('PrevBg').style.opacity = 1;
   }, 200);
}

window.addEventListener("load", HDP, false);

let scrobbleIsDragging = false;

function TP() {
api.media.observeData(function (newData) {
if (newData.isStopped) {}
handleTrackTimes(newData.nowPlaying.elapsed, newData.nowPlaying.length, false);
handleScrobblePosition(newData.nowPlaying.elapsed, newData.nowPlaying.length);
});
api.media.observeElapsedTime(function (newElapsedTime) {
handleTrackTimes(newElapsedTime, api.media.nowPlaying.length, false);
handleScrobblePosition(newElapsedTime, api.media.nowPlaying.length);
});
}

function handleTrackTimes(elapsed, length, forceUpdate) {
if (scrobbleIsDragging && !forceUpdate) return;
const elapsedContent = length === 0 ? '--:--' : secondsToFormatted(elapsed);
document.getElementById('Elapsed').innerHTML = elapsedContent;
const lengthContent = length === 0 ? '--:--' : secondsToFormatted(length);
document.getElementById('Length').innerHTML = lengthContent;
document.getElementById('Playback-time').setAttribute('max', length);
document.getElementById('Playback-time').value = elapsed;
}

function handleScrobblePosition(elapsed, length) {
if (scrobbleIsDragging) return;
const scrobble = document.getElementById('Scrobble-slider');
scrobble.setAttribute('max', length);
scrobble.value = elapsed;
}

function secondsToFormatted(seconds) {
if (seconds === 0) return '0:00';
const isNegative = seconds < 0;
if (isNegative) return '0:00';
seconds = Math.abs(seconds);
const hours = Math.floor(seconds / 60 / 60);
const minutes = Math.floor(seconds / 60) - (hours * 60);
const secs = Math.floor(seconds - (minutes * 60) - (hours * 60 * 60));
if (hours > 0) {
return hours + ':' + (minutes < 10 ? '0' : '') + minutes + ':' + (secs < 10 ? '0' : '') + secs;
} else {
return minutes + ':' + (secs < 10 ? '0' : '') + secs;
  }
}

function onScrobbleUIChanged(input) {
scrobbleIsDragging = true;
handleTrackTimes(input, api.media.nowPlaying.length, true);
}

function onScrobbleChanged(input) {
api.media.seekToPosition(input);
handleTrackTimes(input, api.media.nowPlaying.length, true);
scrobbleIsDragging = false;
}

window.addEventListener("load", TP, false);