if (window.config.language == "Vietnamese") {
var titletext = "✯ Âm Nhạc ✯ ࿐♪ ♫ ༄";
var artisttext = "Không có nghệ sĩ";
var yeartext = '';
var gan = new Array("Giáp", "Ất", "Bính", "Đinh", "Mậu", "Kỷ", "Canh", "Tân", "Nhâm", "Quý");
var zhi = new Array(" tí", " sửu", " dần", " mão", " thìn", " tị", " ngọ", " mùi", " thân", " dậu", " tuất", " hợi");
var sunday = ['C.N'];
var sday = ['T.2', 'T.3', 'T.4', 'T.5', 'T.6', 'T.7'];
var sdayfull = ["C.N", "T.2", "T.3", "T.4", "T.5", "T.6", "T.7"];
}

if (window.config.language == "English") {
var titletext = "✯ Music ✯ ࿐♪ ♫ ༄";
var artisttext = "No Artist";
var yeartext = 'Year';
var gan = new Array("", "", "", "", "", "", "", "", "", "");
var zhi = new Array("Rat", "Ox", "Tiger", "Cat", "Dragon", "Snake", "Horse", "Goat", "Monkey", "Chicken", "Dog", "Pig");
var sunday = ['Sun'];
var sday = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
var sdayfull = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
}