function openMu() {
if (
document.getElementById("MuCont").classList.contains('closed')) {
document.getElementById("MuCont").classList.add('open');
document.getElementById("MuCont").classList.remove('closed');
return;
} else {
document.getElementById("MuCont").classList.add('closed');
document.getElementById("MuCont").classList.remove('open');
  }
}

function openWd() {
if (
document.getElementById("WallCont").classList.contains('closed')) {
document.getElementById("WallCont").classList.remove('open');
return;
} else {
document.getElementById("WallCont").classList.add('closed');
}
document.getElementById("Up").style.opacity = 0;
document.getElementById('CalCont').style.animation = 'fadingout 1s linear 1 forwards';
setTimeout(function () {
document.getElementById("Up").style.opacity = 1;
document.getElementById('WeekdayCont').style.animation = 'fading 1.5s linear 1 forwards';
document.getElementById('SearchCont').style.animation = 'fading 1.5s linear 1 forwards';
  }, 200);
}

function closedWd() {
if (
document.getElementById("WallCont").classList.contains('open')) {
document.getElementById("WallCont").classList.add('closed');
return;
} else {
document.getElementById("WallCont").classList.remove('closed');
}

document.getElementById("Dow").style.opacity = 0;
document.getElementById('WeekdayCont').style.animation = 'fadingout 1s linear 1 forwards';
document.getElementById('SearchCont').style.animation = 'fadingout 1.5s linear 1 forwards';
setTimeout(function () {
document.getElementById("Dow").style.opacity = 1;
document.getElementById('CalCont').style.animation = 'fading 1.5s linear 1 forwards';
  }, 200);
}