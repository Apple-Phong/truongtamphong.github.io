function mainUpdate(type) {
if (type === "weather") { checkWeather(); }
if (type === "battery") { updateBattery(); }
}

function checkWeather() {
document.getElementById('WeIcon').src = 'Scripts/Weather/' + weather.conditionCode + '.png';
document.getElementById("High").innerHTML = '⇡' + weather.high + '°';
document.getElementById("Low").innerHTML = '⇣' + weather.low + '°';
document.getElementById("Temp").innerHTML = weather.temperature;
}