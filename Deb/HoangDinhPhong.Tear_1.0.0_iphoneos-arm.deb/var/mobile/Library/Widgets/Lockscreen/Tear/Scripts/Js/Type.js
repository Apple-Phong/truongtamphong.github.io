var screenWidth;
var resizeElements = "#Container";
var iPhoneType = "auto";
if (iPhoneType == "auto") {
if (screen.height == 667) { iPhoneType = "iPh678" }
else if (screen.height == 736) { iPhoneType = "iPh678P" }
else if (screen.height == 780) { iPhoneType = "iPhMini" }
else if (screen.height == 812) { iPhoneType = "iPhX11P" }
else if (screen.height == 896) { iPhoneType = "iPh11M" }
else if (screen.height == 844) { iPhoneType = "iPh12P" }
else if (screen.height == 926) { iPhoneType = "iPh12M" }
}

window.addEventListener("load", function () {
switch (iPhoneType) {

case "iPh678":
document.body.style.width = '375px';
document.body.style.height = '667px';
$(".Scrobble-times").css({ "margin-top":"7.4%" });
break;

case "iPh678P":
document.body.style.width = '414px';
document.body.style.height = '736px';
break;

case "iPhMini":
document.body.style.width = '360px';
document.body.style.height = '780px';
$(".Scrobble-times").css({ "margin-top":"7.3%" });
$(resizeElements).css({ "height": "82.14%" });
break;

case "iPhX11P":
document.body.style.width = '375px';
document.body.style.height = '812px';
$(".Scrobble-times").css({ "margin-top":"7.4%" });
$(resizeElements).css({ "height": "82.14%" });
break;

case "iPh11M":
document.body.style.width = '414px';
document.body.style.height = '896px';
$(resizeElements).css({ "height": "82.14%" });
break;

case "iPh12P":
document.body.style.width = '390px';
document.body.style.height = '844px';
$(".Scrobble-times").css({ "margin-top":"7.7%" });
$(resizeElements).css({ "height": "82.14%" });
break;

case "iPh12M":
document.body.style.width = '428px';
document.body.style.height = '926px';
$(resizeElements).css({ "height": "82.14%" });
break;
}
}, false);