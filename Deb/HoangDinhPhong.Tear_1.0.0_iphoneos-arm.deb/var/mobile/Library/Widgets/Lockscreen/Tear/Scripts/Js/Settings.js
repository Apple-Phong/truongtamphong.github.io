// Color
document.documentElement.style.setProperty('--secondary', config.secondary);