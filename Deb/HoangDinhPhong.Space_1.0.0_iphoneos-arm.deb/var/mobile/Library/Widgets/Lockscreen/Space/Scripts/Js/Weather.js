function checkWeather() {
document.getElementById("WeInfo").innerHTML = wetext + ' ' + weather.city + ', ' + condition[weather.conditionCode] + '. ' + temptext + ' ' + weather.temperature + '°. ' + hilotext + ' ' + weather.low + '°' + '/' + weather.high + '°. ' + humitext + ' ' + weather.humidity + '%';
}