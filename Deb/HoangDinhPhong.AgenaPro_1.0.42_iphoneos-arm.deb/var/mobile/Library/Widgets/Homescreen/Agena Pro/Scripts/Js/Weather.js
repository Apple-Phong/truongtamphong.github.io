function mainUpdate(type) {
if (type === "weather") { checkWeather(); }
if (type === "battery") { updateBattery();}
}

function checkWeather() {
document.getElementById('WeatherIcon').src = 'Scripts/Weather/' + config.IconSet + '/' + weather.conditionCode + '.png';
document.getElementById("City").innerHTML = weather.city.substring(0,15);
document.getElementById("Hi").innerHTML = weather.high;
document.getElementById("Lo").innerHTML = weather.low;
document.getElementById('Temp').innerHTML = weather.temperature;
}