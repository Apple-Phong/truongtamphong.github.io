function clock(options) {
var getTimes = function () {
var d = new Date(),
funcs = {

day: function () {
return d.getDay();
},

datepadded: function () {
return (d.getDate() < 10) ? "0" + d.getDate() : d.getDate();
},

month: function () {
return d.getMonth();
  }
};

options.success(funcs);
setTimeout(function () {
getTimes();
}, options.refresh);
};
getTimes();
}

clock({
twentyfour: true,
padzero: true,
refresh: 5000,
success:

function(clock) {
document.getElementById('Month').innerHTML = months[clock.month()];
document.getElementById('Date').innerHTML = clock.datepadded(); 
document.getElementById('Weekday').innerHTML = days[clock.day()];
   }
});