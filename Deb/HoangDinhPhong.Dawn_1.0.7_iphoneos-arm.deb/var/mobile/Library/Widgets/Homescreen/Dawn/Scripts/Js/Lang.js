if (window.config.language == "Vietnamese") {
var altext = ["âm lịch"];
var charging = ["⚡"];
var notcharging = [""];
var titletext = ["✫ Âm Nhạc ✫ ࿐♪♫༄"];
var sday = ["Chủ Nhật", "Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy"];
var smonth = ["Thg 1", "Thg 2", "Thg 3", "Thg 4", "Thg 5", "Thg 6", "Thg 7", "Thg 8", "Thg 9", "Thg 10", "Thg 11", "Thg 12"];
}

if (window.config.language == "English") {
var altext = ["lunar"];
var charging = "⚡";
var notcharging = "";
var titletext = ["✫ Media Player ✫ ࿐♪♫༄"];
var sday = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
var smonth = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
}