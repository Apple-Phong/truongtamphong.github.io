function mainUpdate(type){
if (type === "weather") { checkWeather(); }
else 
if (type === "battery"){ updateBattery(); }
}

function checkWeather(){
document.getElementById("City").innerHTML = weather.city + ' | ' + weather.temperature + "&deg";
}