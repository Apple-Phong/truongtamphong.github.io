function checkWeather() {
document.getElementById("Condition").innerHTML = condition[weather.conditionCode] + ' • ' + weather.temperature + '°';
document.getElementById("Sunset").innerHTML = weather.sunsetTime.substring(2, 0) + ':' + weather.sunsetTime.substring(2, 4);

document.getElementById("Day1Icon").src = "Scripts/Weather/" + weather.dayForecasts[1].icon + ".png";
document.getElementById("Day2Icon").src = "Scripts/Weather/" + weather.dayForecasts[2].icon + ".png";
document.getElementById("Day3Icon").src = "Scripts/Weather/" + weather.dayForecasts[3].icon + ".png";
document.getElementById("Day4Icon").src = "Scripts/Weather/" + weather.dayForecasts[4].icon + ".png";

document.getElementById("Day1HiLo").innerHTML = weather.dayForecasts[1].high + ' | ' + weather.dayForecasts[1].low;
document.getElementById("Day2HiLo").innerHTML = weather.dayForecasts[2].high + ' | ' + weather.dayForecasts[2].low;
document.getElementById("Day3HiLo").innerHTML = weather.dayForecasts[3].high + ' | ' + weather.dayForecasts[3].low;
document.getElementById("Day4HiLo").innerHTML = weather.dayForecasts[4].high + ' | ' + weather.dayForecasts[4].low;
}