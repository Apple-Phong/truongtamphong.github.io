if (!config.bat) {
document.getElementById('BatCont').style.display = 'none';
}

document.getElementById('SunsetText').innerHTML = sunsettext;