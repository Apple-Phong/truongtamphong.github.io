let fontFamily = new FontFace("FontSelect", `url(${'/var/mobile/Library/Widgets/Lockscreen/Askew/Scripts/Fonts/Greeting/' + config.fontSelect + '.ttf'}) format("truetype")`);
fontFamily.load().then(function (loadedFont) {
   document.fonts.add(loadedFont);
})