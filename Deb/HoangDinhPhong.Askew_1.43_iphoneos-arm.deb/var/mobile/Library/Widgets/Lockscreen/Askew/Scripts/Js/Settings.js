/*Color*/
document.documentElement.style.setProperty('--PlayCl', config.PlayCl);
document.documentElement.style.setProperty('--NextCl', config.NextCl);
document.documentElement.style.setProperty('--dateCl', config.dateCl);
document.documentElement.style.setProperty('--monthCl', config.monthCl);
document.documentElement.style.setProperty('--weekdayCl', config.weekdayCl);
document.documentElement.style.setProperty('--cityCl', config.cityCl);
document.documentElement.style.setProperty('--conditionCl', config.conditionCl);
document.documentElement.style.setProperty('--tempCl', config.tempCl);
document.documentElement.style.setProperty('--clockCl', config.clockCl);
document.documentElement.style.setProperty('--ampmCl', config.ampmCl);
document.documentElement.style.setProperty('--todCl', config.todCl);
document.documentElement.style.setProperty('--feelCl', config.feelCl);
document.documentElement.style.setProperty('--batteryCl', config.batteryCl);
document.documentElement.style.setProperty('--amlichCl', config.amlichCl);
document.documentElement.style.setProperty('--artistCl', config.artistCl);
document.documentElement.style.setProperty('--titleCl', config.titleCl);

/*On Off*/
if (!config.Title) {
  document.getElementById('Title').style.display = 'none';
}
if (!config.Album) {
  document.getElementById('AlbCont').style.display = 'none';
}
if (!config.Controls) {
  document.getElementById('Control').style.display = 'none';
}
var doc = document,
  bg = doc.getElementById('Bg');
if (config.HideBackground == false) {
  Bg.style.visibility = 'hidden';
  Bg1.style.visibility = 'hidden';
  Bg2.style.visibility = 'hidden';
}
if (!config.amlich) {
  document.getElementById('AmLich').style.display = 'none';
  document.getElementById('Mask3').style.display = 'none';
}
if (!config.overlay) {
  document.getElementById('BgOverlay').style.display = 'none';
}

/*Background*/
document.documentElement.style.setProperty('--spreadBg', config.spreadBg + 'px');
document.documentElement.style.setProperty('--blurBg', config.blurBg + 'px');
document.documentElement.style.setProperty('--borderBg', config.borderBg + 'px');
document.documentElement.style.setProperty('--darkBg', config.darkBg);

/*Text Style*/
document.documentElement.style.setProperty('--capital', config.capital);
document.documentElement.style.setProperty('--italic', config.italic);

/*Other*/
document.documentElement.style.setProperty('--second', config.Sec + 's');
document.documentElement.style.setProperty('--mask', config.mask);
document.getElementById('Widget').style.webkitTransform = 'scale(' + config.Scale + ')';
document.getElementById('Bg2').style.backgroundColor = config.BackgroundColor;
document.documentElement.style.setProperty('--dec', config.dec);
document.getElementById("Ae").src = "Scripts/Js/Ae.js";