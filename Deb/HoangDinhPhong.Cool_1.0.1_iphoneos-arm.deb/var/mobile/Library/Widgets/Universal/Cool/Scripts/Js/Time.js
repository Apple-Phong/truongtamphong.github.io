function clock(options) {
var getTimes = function () {
var d = new Date(),
funcs = {

hour: function () {
var hour = (options.twentyfour === true) ? d.getHours() : (d.getHours() + 11) % 12 + 1;
hour = (options.padzero === true) ? (hour < 10 ? "0" + hour : "" + hour) : hour;
return hour;
},

minute: function () {
return (d.getMinutes() < 10) ? "0" + d.getMinutes() : d.getMinutes();
},

ampm: function () {
if (options.twentyfour === true) {
return ' ';
}
return (d.getHours() < 11) ? "am" : "pm";
},

day: function () {
return d.getDay();
},

datepadded: function () {
return (d.getDate() < 10) ? "0" + d.getDate() : d.getDate();
},

month: function () {
return d.getMonth();
}
};

options.success(funcs);
setTimeout(function () {
getTimes();
}, options.refresh);
};
getTimes();
}

clock({
twentyfour: config.Time24,
padzero: true,
refresh: 5000,
success:

function (clock) {
document.getElementById("Weekday").innerHTML = days[clock.day()];
document.getElementById("Date").innerHTML = clock.datepadded();
document.getElementById("Month").innerHTML = months[clock.month()];
document.getElementById("Hour").innerHTML = clock.hour() + ':' + clock.minute();
document.getElementById("AmPm").innerHTML = clock.am();
}
});