/* Color */
document.documentElement.style.setProperty('--textCl', config.textCl);
document.documentElement.style.setProperty('--aldateCl', config.aldateCl);
document.documentElement.style.setProperty('--cnCl', config.cnCl);
document.documentElement.style.setProperty('--dateCl', config.dateCl);
document.documentElement.style.setProperty('--nameCl', config.nameCl);

/* Screws */
document.getElementById('Screws-1').src = 'Scripts/Images/Screws/' + config.Screws + '.png';
document.getElementById('Screws-2').src = 'Scripts/Images/Screws/' + config.Screws + '.png';
document.getElementById('Screws-3').src = 'Scripts/Images/Screws/' + config.Screws + '.png';
document.getElementById('Screws-4').src = 'Scripts/Images/Screws/' + config.Screws + '.png';

/* Name */
document.getElementById('YourName').innerHTML = config.YourName;

/* On Off */
if (!config.scr) {
   document.getElementById('Sc1Cont').style.display = 'none';
   document.getElementById('Sc2Cont').style.display = 'none';
   document.getElementById('Sc3Cont').style.display = 'none';
   document.getElementById('Sc4Cont').style.display = 'none';
}