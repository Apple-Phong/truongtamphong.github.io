/*---------- Globals ----------*/

var options = {},
injectedSystem = {},
percent = ['0', '40', '60', '100'],
pressOptions;
setTimeout(function() {
if (action.savedElements.placedElements) {
pressOptions = action.savedElements.placedElements['pressActions'];
 }
}, 1000);

/*---------- Elements ----------*/

var systemElements, systemMethods;

systemElements = {
'Percent' : ['battery'],
'Percentage' : ['battery', '%'],
'BatteryCircle' : ['batterycircle'],
'BatteryCharge' : ['battery', '%', ' / ', 'chargetext'],
'Charging' : ['chargetext'],
'OnlyCharging' : ['onlycharging'],
};

weatherMethods = {
battery: function() {
return injectedSystem.battery || '';
},

charging: function() {
return injectedSystem.chargetext || '';
},

charginglowercase: function() {
return String(injectedSystem.chargetext).toLowerCase();
  }
};

function checkIfEventExists(number) {
if (injectedSystem.events) {
if (injectedSystem.events[number]) {
return true;
} else {
return false;
    }
  }
return false;
}

systemMethods = {
percent : ['0', '40', '60', '100'],
battery: function() {
return injectedSystem.battery || '';
},

chargetext: function() {
return injectedSystem.chargetext || '';
},

batterycircle: function () {
try {
if(circleProgress) {
if(circleProgress.value != injectedSystem.battery) {
circleProgress.value = injectedSystem.battery;
    }
  }
} catch(err) {}
return "";
},

durationcircle: function () {
try {
if(durationProgress) {
if(durationProgress.value != injectedSystem.battery) {
durationProgress.value = injectedSystem.battery;
    }
  }
} catch(err) {}
return "";
},

onlycharging: function() {
return (injectedSystem.chargetext === 'Charging') ? '⚡️' : '';
  },
};

/*---------- Main ----------*/

var action = {};
action.savedElements = {};

function setSpecificStylesAfterCreation(div, id) {
switch (id) {
case 'BatteryCircle':
div.className = 'progressBattery';
div.style.width = 'auto';
div.style.height = 'auto';
div.title = 'progressBattery';
circleProgress = new CircleProgress('.progressBattery');
circleProgress.max = 100;
circleProgress.value = 75;
circleProgress.textFormat = 'none';
addStyleString('.circle-progress-progressBattery{overflow:visible;pointer-events:none;}', 'circleOverflowBattery');
break;
  }
}

function checkIfActionsAreApplied(id) {
var hasActions;
if (action.savedElements.placedElements[id]) {
hasActions = action.savedElements.placedElements[id]['action'];
}
return hasActions;
}


action.remakeDIV = function(id) {
var domElementIfExists = document.getElementById(id), div = null;
if (id === 'overlayStyle' || id === 'pressActions' || domElementIfExists) {
if (domElementIfExists) {
return domElementIfExists;
}
return;
}
div = document.createElement('div');
div.id = id;
div.style.zIndex = 1;

document.getElementById('Battery').appendChild(div);
setSpecificStylesAfterCreation(div, id);
return div;
};

function addStyleString(str, id) {
var doc = document;
node = doc.createElement('style');
node.innerHTML = str;
doc.body.appendChild(node);
}

action.loadStyles = function(key, value, createdDiv) {
Object.keys(value).forEach(function(skey) {
styleVal = value[skey];

if (skey === 'circle-width') {
addStyleString('.circle-progress-'+createdDiv.title+'{width:' + styleVal + ';height:' + styleVal + ';}', 'circlewidth' + createdDiv.title);
} else if (skey === 'circle-stroke') {
addStyleString('.circle-progress-circle'+createdDiv.title+'{stroke-width:' + styleVal + ';}', 'circlestroke' + createdDiv.title);
} else if (skey === 'circle-stroke-dasharray') {
addStyleString('.circle-progress-value'+createdDiv.title+'{stroke-dasharray:' + styleVal + ' 2;}', 'circlestrokedash'+ createdDiv.title);
} else if (skey === 'circle-stroke-value') {
addStyleString('.circle-progress-value'+createdDiv.title+'{stroke-width:' + styleVal + ';}', 'circlestrokevalue'+ createdDiv.title);
} else if (skey === 'outer-color') {
addStyleString('.circle-progress-value'+createdDiv.title+'{stroke:' + styleVal + ';}', 'circleoutercolor'+ createdDiv.title);
} else if (skey === 'inner-color') {
addStyleString('.circle-progress-circle'+createdDiv.title+'{stroke:' + styleVal + ';}', 'circleinnercolor'+ createdDiv.title);
} else if (skey === 'circle-cap') {
addStyleString('.circle-progress-value'+createdDiv.title+'{stroke-linecap:'+styleVal+';}', 'circlestrokecap'+ createdDiv.title);
} else {
if (skey === 'scale') {
document.getElementById(key).style.webkitTransform = 'scale(' + styleVal + ')';
} try {
createdDiv.style[skey] = styleVal;
} catch (err) {
       }
     }
 });
};

action.replaceElements = function() {
var elementStyles, createdDiv,
placedElements = action.savedElements.placedElements;
if (!placedElements) {
return;
}

Object.keys(placedElements).forEach(function (elementName) {
if (placedElements[elementName].type == 'widget') {
} else {
createdDiv = action.remakeDIV(elementName);
if (!createdDiv) {
return;
}

elementStyles = placedElements[elementName];
action.loadStyles(elementName, elementStyles, createdDiv); }
});

setTimeout(function () {
startLoop();
  }, 0);
};


function isExportedInfo() {
if (typeof savedElements !== 'undefined') {
return savedElements;
} else {
return false;
  }
}

function setStoredElementsToLocalSavedElements() {
if (isExportedInfo()) {
action.savedElements = savedElements;
}
return action.savedElements;
}

action.loadFromStorage = function () {
var elements = setStoredElementsToLocalSavedElements();
if (elements) {
action.replaceElements();
  }
};

function loadInfo() {
action.loadFromStorage();
}

window.onload = function () {
loadInfo();
};

/*---------- Main Loop ----------*/

function setElementInfo(div, value) {
var innerHTML = div.innerHTML.replace('°', '&deg;'),
innerTEXT = div.innerText.replace('°', '&deg;'),
knockoutEl = null;

if (innerHTML === value || innerTEXT === value) {
return;
} else {
if (String(value).indexOf(';') > -1) {
div.innerHTML = value;
} else {
div.innerText = value;
    }
  }
};

function setBattery(element, percent, fullWidth) {
switch(percent) {
case 'battery':
percent = injectedSystem.battery;
break;
}
var calc;
fullWidth = fullWidth.replace('px', '');
calc = Math.round((percent / 100) * fullWidth);
if (element.style.width != calc + "px") {
element.style.width = calc + "px";
  }
}

function getSystemInfo(key) {
var value = "";
if (systemElements[key]) {
systemElements[key].forEach(function(info) {
if (systemMethods[info]) {
value += systemMethods[info]();
} else {
value += info;
   }
});
}

if(value.indexOf('undefined') > -1) {
return "";
}
return value;
}

function refreshAllInfo() {
Object.keys(action.savedElements.placedElements).forEach(function(key) {
if (systemElements[key]) {
div = document.getElementById(key);
prefix = div.getAttribute('data-prefix') || '';
suffix = div.getAttribute('data-suffix') || '';
}

if (systemElements[key]) {
if (key.substring(0, 3) != 'box' && key.substring(0, 2) != 'ft') {
value = prefix + getSystemInfo(key) + suffix;
setElementInfo(div, value);
       }
     }
 });
}

/* Main Timers */
var Looper = {
loopit: function(obj) {
var loopSetTimeOutValue = 0;
this[obj.name] = setTimeout(function() {
obj.success();
Looper.loopit(obj);
  }, loopSetTimeOutValue);
},
create: function(obj) {
if (Looper[obj.name]) {
return;
}
this.loopit(obj);
  }
};

function startLoop() {
Looper.create({
refreshTime: 1000,
success: function () {
refreshAllInfo();
    }
});
}

function stopLoops() {
Looper.stopTimers();
}