var savedElements = {
"placedElements": {
"BatteryCircle": {
"circle-cap": "round",
"circle-width": "100%",
"circle-stroke": "8px",
"inner-color": "#CCCCCC",
"circle-stroke-value": "8px",
"outer-color": "var(--secondary)",
},

"Percent": { }
  }
}