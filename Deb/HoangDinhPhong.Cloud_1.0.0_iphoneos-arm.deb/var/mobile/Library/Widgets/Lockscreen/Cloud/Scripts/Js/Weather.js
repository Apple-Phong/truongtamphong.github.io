function mainUpdate(type) {
if (type === "weather") { checkWeather(); }
}

function checkWeather() {
  document.getElementById('WeIcon').src = 'Scripts/Weather/' + weather.conditionCode + '.png';
  document.getElementById("City").innerHTML = weather.city;
  document.getElementById("Temp").innerHTML = weather.temperature + '°';
  document.getElementById("Condition").innerHTML = condition[weather.conditionCode];
}