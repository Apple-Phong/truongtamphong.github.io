if(!config.cal){
document.getElementById('Calendar').style.display = 'none';
}

if(!config.clock){
document.getElementById('TimeCont').style.display = 'none';
}
