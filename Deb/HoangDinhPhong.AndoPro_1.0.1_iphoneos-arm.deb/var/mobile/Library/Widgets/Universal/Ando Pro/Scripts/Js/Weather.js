function mainUpdate(type) {
if (type === "weather") { checkWeather(); }
}

function checkWeather() {
document.getElementById('City').innerHTML = weather.city;
document.getElementById("Condition").innerHTML = condition[weather.conditionCode];
document.getElementById('Temp').innerHTML = weather.temperature + "&deg";
document.getElementById('Hi').innerHTML = weather.high + "&deg";
document.getElementById('Lo').innerHTML = weather.low + "&deg";
document.getElementById('WeIcon').src = 'Scripts/Weather/' + weather.conditionCode + '.png';

document.getElementById("Day1").innerHTML = sday[ weather.dayForecasts[1].dayOfWeek-1];
document.getElementById("Day2").innerHTML = sday[ weather.dayForecasts[2].dayOfWeek-1];
document.getElementById("Day3").innerHTML = sday[ weather.dayForecasts[3].dayOfWeek-1];
document.getElementById("Day4").innerHTML = sday[ weather.dayForecasts[4].dayOfWeek-1];

document.getElementById("Day1Icon").src = 'Scripts/Weather/' + weather.dayForecasts[1].icon + ".png";
document.getElementById("Day2Icon").src = 'Scripts/Weather/' + weather.dayForecasts[2].icon + ".png";
document.getElementById("Day3Icon").src = 'Scripts/Weather/' + weather.dayForecasts[3].icon + ".png";
document.getElementById("Day4Icon").src = 'Scripts/Weather/' +  weather.dayForecasts[4].icon + ".png";

document.getElementById("Day1HiLo").innerHTML = weather.dayForecasts[1].high  + "&deg;" + "/" + weather.dayForecasts[1].low  + "&deg;";
document.getElementById("Day2HiLo").innerHTML = weather.dayForecasts[2].high  + "&deg;" + "/" + weather.dayForecasts[2].low  + "&deg;";
document.getElementById("Day3HiLo").innerHTML = weather.dayForecasts[3].high  + "&deg;" + "/" + weather.dayForecasts[3].low  + "&deg;";
document.getElementById("Day4HiLo").innerHTML = weather.dayForecasts[4].high  + "&deg;" + "/" + weather.dayForecasts[4].low  + "&deg;";
}