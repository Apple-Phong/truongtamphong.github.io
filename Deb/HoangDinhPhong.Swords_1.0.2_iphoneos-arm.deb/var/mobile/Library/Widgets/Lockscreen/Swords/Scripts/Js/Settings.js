// Color
document.documentElement.style.setProperty('--secondary', config.secondary);

// Blur
document.documentElement.style.setProperty('--bl', config.bl + 'px');

// On off
if(!config.screws){
document.getElementById('ScDockLeftCont').style.display = 'none';
document.getElementById('ScDockRightCont').style.display = 'none';
document.getElementById('ScMuBotLeftCont').style.display = 'none';
document.getElementById('ScMuBotRightCont').style.display = 'none';
document.getElementById('ScMuTopLeftCont').style.display = 'none';
document.getElementById('ScMuTopRightCont').style.display = 'none';
document.getElementById('ScBoxLeftBotCont').style.display = 'none';
document.getElementById('ScBoxLeftTopCont').style.display = 'none';
document.getElementById('ScBoxRightBotCont').style.display = 'none';
document.getElementById('ScBoxRightTopCont').style.display = 'none';
document.getElementById('ScInfoLeftCont').style.display = 'none';
document.getElementById('ScInfoRightCont').style.display = 'none';
document.getElementById('Controls').style.width = '80%';
}

if(!config.flashcam){
document.getElementById('Flash').style.display = 'none';
document.getElementById('Cam').style.display = 'none';
}

if(!config.Ae){
document.getElementById('Ae').style.display = 'none';
}

if(!config.flashcam){
document.getElementById('Flash').style.display = 'none';
document.getElementById('Cam').style.display = 'none';
}

// Src
document.getElementById('Background').src = 'Scripts/Images/Background.png';
document.getElementById('Ae').src = 'Scripts/Images/Ae.png';
document.getElementById('ChainTopLeft').src = 'Scripts/Images/Chain/' + config.Chain + '.png';
document.getElementById('ChainTopRight').src = 'Scripts/Images/Chain/' + config.Chain + '.png';
document.getElementById('ChainCenLeft').src = 'Scripts/Images/Chain/' + config.Chain + '.png';
document.getElementById('ChainCenRight').src = 'Scripts/Images/Chain/' + config.Chain + '.png';
document.getElementById('ChainBotLeft').src = 'Scripts/Images/Chain/' + config.Chain + '.png';
document.getElementById('ChainBotRight').src = 'Scripts/Images/Chain/' + config.Chain + '.png';

document.getElementById('ScDockLeft').src = 'Scripts/Images/Screws/' + config.Screws + '.png';
document.getElementById('ScDockRight').src = 'Scripts/Images/Screws/' + config.Screws + '.png';
document.getElementById('ScMuBotLeft').src = 'Scripts/Images/Screws/' + config.Screws + '.png';
document.getElementById('ScMuBotRight').src = 'Scripts/Images/Screws/' + config.Screws + '.png';
document.getElementById('ScMuTopLeft').src = 'Scripts/Images/Screws/' + config.Screws + '.png';
document.getElementById('ScMuTopRight').src = 'Scripts/Images/Screws/' + config.Screws + '.png';
document.getElementById('ScBoxLeftBot').src = 'Scripts/Images/Screws/' + config.Screws + '.png';
document.getElementById('ScBoxLeftTop').src = 'Scripts/Images/Screws/' + config.Screws + '.png';
document.getElementById('ScBoxRightBot').src = 'Scripts/Images/Screws/' + config.Screws + '.png';
document.getElementById('ScBoxRightTop').src = 'Scripts/Images/Screws/' + config.Screws + '.png';
document.getElementById('ScInfoLeft').src = 'Scripts/Images/Screws/' + config.Screws + '.png';
document.getElementById('ScInfoRight').src = 'Scripts/Images/Screws/' + config.Screws + '.png';

// Other
document.documentElement.style.setProperty('--bri', config.bri + '%');