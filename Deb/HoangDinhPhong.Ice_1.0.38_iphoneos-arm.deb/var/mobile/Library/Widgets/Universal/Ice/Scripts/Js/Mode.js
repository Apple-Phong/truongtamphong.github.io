$('head').removeAttr('Mode');
if (config.Mode == 'General') {
$ ('head').append('<link rel="stylesheet" media="screen" href="Scripts/Css/General.css" type="text/css" >');
}

if (config.Mode == 'Distinctive') {
$ ('head').append('<link rel="stylesheet" media="screen" href="Scripts/Css/Distinctive.css" type="text/css" >');
}