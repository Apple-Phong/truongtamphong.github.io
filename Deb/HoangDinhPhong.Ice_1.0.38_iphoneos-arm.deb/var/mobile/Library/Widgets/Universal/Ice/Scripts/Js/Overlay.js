var options = {};
var action = {};
action.setOverlay = function(img) {
setTimeout(function() {

screenOverDiv = document.createElement('div');
screenOverDiv.className = 'Overlay';
screenOverDiv.style.backgroundImage = 'url(' + img + ')';
document.body.appendChild(screenOverDiv);
}, 0); };

action.replaceElements = function() {};

function isExportedInfo() {
if (typeof savedElements !== 'undefined') {
return savedElements; }
}

function setStoredElementsToLocalSavedElements(){
if (isExportedInfo()) {
action.savedElements = savedElements;
} return action.savedElements;
}

function setOverlayIfAvailable() {
if (action.savedElements.overlay != undefined) {
if (action.savedElements.overlay.length > 1) {
if (!options.disableoverlay) {
action.setOverlay(action.savedElements.overlay);
action.savedElements.overlay = null; }}}
}

action.loadFromStorage = function () {
if (localStorage.placedElements) {
this.savedElements = JSON.parse(localStorage.placedElements);
if(this.savedElements.overlay != undefined){
if (this.savedElements.overlay.length > 1) {
if (!options.disableoverlay)
{ this.setOverlay(this.savedElements.overlay); }}}}
};

action.loadFromStorage = function() {
var elements = setStoredElementsToLocalSavedElements();
if(elements) {
setTimeout(function() {
setOverlayIfAvailable();
}, 0); }
};

function loadInfo() {
action.loadFromStorage(); }
setTimeout(function () { loadInfo(); }, 0);