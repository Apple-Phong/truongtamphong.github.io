function mainUpdate(type) { 
if (type === "weather") { checkWeather(); } 
if (type === "battery") { updateBattery(); }
}

function checkWeather() {
document.getElementById("Temp").innerHTML = weather.temperature + '&deg;';
document.getElementById('WeIcon').src = 'Scripts/Weather/' + weather.conditionCode + '.png';
document.getElementById("Condition").innerHTML = condition[weather.conditionCode];
document.getElementById("Hi").innerHTML = hitext +  ' ' + weather.high + '&deg;';
document.getElementById("Lo").innerHTML = lotext + ' ' + weather.low + '&deg;';
document.getElementById("Humi").innerHTML = weather.humidity + '%';
document.getElementById("Wind").innerHTML = weather.windSpeed + 'km';
document.getElementById("Rain").innerHTML = weather.hourlyForecasts[0].percentPrecipitation + '%';
}