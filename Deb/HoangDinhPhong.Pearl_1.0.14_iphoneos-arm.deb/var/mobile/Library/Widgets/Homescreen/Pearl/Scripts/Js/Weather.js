function mainUpdate(type) {
if (type === "weather") { checkWeather(); }
else if (type === "battery") { updateBattery(); }
}

function checkWeather() {
document.getElementById("City").innerHTML = weather.city;
document.getElementById("Temp").innerHTML = weather.temperature + '&deg';
 document.getElementById('WeIcon').src = 'Scripts/Weather/' + weather.conditionCode + '.png';
}