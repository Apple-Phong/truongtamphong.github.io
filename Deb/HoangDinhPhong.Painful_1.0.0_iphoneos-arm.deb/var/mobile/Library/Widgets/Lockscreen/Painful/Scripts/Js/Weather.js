function mainUpdate(type) {
if (type === "weather") { checkWeather() }
}

function checkWeather() {
document.getElementById("WeInfo").innerHTML = condition[weather.conditionCode] + '. ' + temptext + ' ' + weather.temperature + '°' + '<br>' + windtext + ' ' + weather.windSpeed + ' km/h. ' + raintext + ' ' + weather.hourlyForecasts[0].percentPrecipitation + '% ' + '<br>' + humitext + ' ' + weather.humidity + '%';
document.getElementById("City").innerHTML = weather.city;
}