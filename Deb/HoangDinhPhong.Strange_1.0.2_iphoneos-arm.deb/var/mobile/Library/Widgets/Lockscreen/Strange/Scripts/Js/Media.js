function checkMusic(newData) {

if (isplaying === 1) {
document.getElementById('PlayPause').classList.remove("ButtonPlay");
document.getElementById('PlayPause').classList.add("ButtonPause");
} else {
document.getElementById('PlayPause').classList.remove("ButtonPause");
document.getElementById('PlayPause').classList.add("ButtonPlay");
}

if (title === "(null)") {
document.getElementById('Title').innerHTML = titletext;
document.getElementById('Artist').innerHTML = artisttext;
} else {
document.getElementById('Title').innerHTML = title;
document.getElementById('Artist').innerHTML = artist;
if (checkOverflow(document.getElementById('Title')) === true) {
document.getElementById('Title').classList.add("Marquee");
} else {
document.getElementById('Title').classList.remove("Marquee"); }
}
}

function checkOverflow(el) {
var curOverflow = el.style.overflow;
if ( !curOverflow || curOverflow === "visible" ) {
el.style.overflow = "none"; 
}

var isOverflowing = el.clientWidth < el.scrollWidth;
el.style.overflow = curOverflow;
return isOverflowing; 
}

function XenApi() {
api.media.observeData(function (newData) {
appPlaying = newData.nowPlayingApplication.identifier;
checkMusic(newData); });
}

function HDP() {
XenApi();
}

function openApp(app) {
api.apps.launchApplication(app);
}

function playPause() {
window.location = 'xeninfo:playpause';
document.getElementById('PlayPause').style.opacity = 0.3;
setTimeout(function (){
document.getElementById('PlayPause').style.opacity = 1;
}, 200);
}
		
function next() {
window.location = 'xeninfo:nexttrack';
document.getElementById('Next').style.opacity = 0.3;
setTimeout(function () {
document.getElementById('Next').style.opacity = 1;
}, 200);
}
			
function prev() {
window.location = 'xeninfo:prevtrack';
document.getElementById('Prev').style.opacity = 0.3;
setTimeout(function () {
document.getElementById('Prev').style.opacity = 1;
}, 200);
}

window.addEventListener("load", HDP, false);