// color
document.documentElement.style.setProperty('--heartCl', config.heartCl);
document.documentElement.style.setProperty('--timeDateCl', config.timeDateCl);
document.documentElement.style.setProperty('--infoCl', config.infoCl);

// other
document.getElementById('I').innerHTML = iText;

if (config.scale) {
document.body.style.webkitTransform = 'scale(' + config.scale + ')';
}