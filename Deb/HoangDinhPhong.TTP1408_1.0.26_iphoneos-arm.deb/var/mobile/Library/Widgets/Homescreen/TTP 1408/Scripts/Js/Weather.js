function mainUpdate(type) {
if (type === "battery") { updateBattery() }
if (type === "weather") { checkWeather() }
}

function checkWeather() {
document.getElementById("City").innerHTML = weather.city;
document.getElementById("Condition").innerHTML = condition[weather.conditionCode];
document.getElementById("Temp").innerHTML = weather.temperature + '&deg;';
document.getElementById("Humi").innerHTML = humtext + ' ' + weather.humidity + '%' + ' ✫';
document.getElementById("Wind").innerHTML = windtext + ' ' + weather.windSpeed + ' km/h' + ' ✫';
}