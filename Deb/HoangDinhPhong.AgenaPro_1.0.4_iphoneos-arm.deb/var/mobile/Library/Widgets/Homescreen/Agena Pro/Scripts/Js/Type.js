var iPhoneType = "auto";
if (iPhoneType == "auto") {
if (screen.height == 667) { iPhoneType = "iPh678"; }
else if (screen.height == 736) { iPhoneType = "iPh678Plus"; }
else if (screen.height == 780) { iPhoneType = "iPhMini"; }
else if (screen.height == 812) { iPhoneType = "iPhX"; }
else if (screen.height == 896) { iPhoneType = "iPhMax"; }
else if (screen.height == 844) { iPhoneType = "iPh12Pro"; }
else if (screen.height == 926) { iPhoneType = "iPh12M"; }
}

window.addEventListener("load", function() { 
switch(iPhoneType) {

case "iPh678":
document.body.style.width='375px';
document.body.style.height='667px';
$("#HiCont, #LoCont, #WeCont, #TempCont").css({ "width":"31px", "height":"28px" });
$("#WeatherIcon").css({ "width":"86%" });
$("#Hi, #Lo, #Temp").css({ "font-size":"11px" });

$("#Weekday").css({ "font-size":"20px" });
$("#AmLichCont").css({ "width":"32%", "height":"15%" });
$("#AmLich").css({ "font-size":"10px", "padding-top":"3px"});

$("#GgCont").css({ "width":"25px", "height":"25px" });

$("#MuIconCont").css({ "width":"37px", "height":"37px" });
$("#MuIcon").css({ "font-size":"37px" });
$("#DateMonth, #In, #Artist, #City, #Charging").css({ "font-size":"10px" });

$("#BatRingOut").css({ "width":"48px", "height":"48px" });
$("#BatRingIn").css({ "width":"39px", "height":"39px", "border":"1.5px solid #949AA2" });
$("#Percentage").css({ "font-size":"17px" });

$("#Title").css({ "font-size":"14px" });
$("#Controls").css({ "width":"68%" });
$("#PlayBg").css({ "width":"31px", "height":"31px" });
$("#PlayPause").css({ "width":"33px", "height":"25px", "padding-top":"8px", "padding-left":"0px", "font-size":"17px" });
$("#Prev").css({ "width":"22px", "height":"18px", "padding-top":"4px", "padding-left":"0px", "font-size":"12px" });
$("#Next").css({ "width":"19px", "height":"18px", "padding-top":"4px", "padding-left":"3px", "font-size":"12px" });
break;

case "iPh678Plus":
document.body.style.width='414px';
document.body.style.height='736px';
$("#HiCont, #LoCont, #WeCont, #TempCont").css({ "width":"32px", "height":"29px" });
$("#WeatherIcon").css({ "width":"88%" });
$("#Hi, #Lo, #Temp").css({ "font-size":"12px" });

$("#Weekday").css({ "font-size":"22px" });
$("#AmLichCont").css({ "width":"32%", "height":"14%" });
$("#AmLich").css({ "font-size":"11px", "padding-top":"2px"});

$("#GgCont").css({ "width":"28px", "height":"28px" });

$("#MuIconCont").css({ "width":"42px", "height":"42px" });
$("#MuIcon").css({ "font-size":"42px" });
$("#DateMonth, #In, #City, #Charging, #Artist").css({ "font-size":"11px" });

$("#BatRingOut").css({ "width":"54px", "height":"54px" });
$("#BatRingIn").css({ "width":"43px", "height":"43px" });
$("#Percentage").css({ "font-size":"19px" });

$("#Title").css({ "font-size":"15px" });
$("#Controls").css({ "width":"68%" });
$("#PlayBg").css({ "width":"33px", "height":"33px" });
$("#PlayPause").css({ "width":"36px", "height":"27px", "padding-top":"9px", "padding-left":"0px", "font-size":"18px" });
$("#Prev").css({ "width":"25px", "height":"19px", "padding-top":"6px", "padding-left":"0px", "font-size":"12px" });
$("#Next").css({ "width":"23px", "height":"19px", "padding-top":"6px", "padding-left":"2px", "font-size":"12px" });
break;

case "iPhMini":
document.body.style.width = '360px';
document.body.style.height = '780px';
screenWidth = 360;
$("#Weekday").css({ "font-size":"22px" });

$("#HiCont, #LoCont, #WeCont, #TempCont").css({ "width":"35px", "height":"32px" });
$("#Hi, #Lo, #Temp").css({ "font-size":"13px" });

$("#GgCont").css({ "width":"30px", "height":"30px" });

$("#MuIconCont").css({ "width":"44px", "height":"44px" });
$("#MuIcon").css({ "font-size":"44px" });
$("#DateMonth, #In, #Artist, #City, #Charging").css({ "font-size":"11px" });

$("#BatRingOut").css({ "width":"60px", "height":"60px" });
$("#BatRingIn").css({ "width":"48px", "height":"48px" });
$("#Percentage").css({ "font-size":"21px" });

$("#Title").css({ "font-size":"15px" });
$("#PlayBg").css({ "width":"34px", "height":"34px" });
$("#PlayPause").css({ "width":"36px", "height":"27px", "padding-top":"9px", "padding-left":"0px", "font-size":"19px" });
$("#Prev").css({ "width":"26px", "height":"20px", "padding-top":"6px", "padding-left":"0px", "font-size":"12px" });
$("#Next").css({ "width":"23px", "height":"20px", "padding-top":"6px", "padding-left":"3px", "font-size":"12px" });
break;

case "iPhX":
document.body.style.width='375px';
document.body.style.height='812px';
$("#Weekday").css({ "font-size":"22px" });

$("#HiCont, #LoCont, #WeCont, #TempCont").css({ "width":"35px", "height":"32px" });
$("#Hi, #Lo, #Temp").css({ "font-size":"13px" });

$("#GgCont").css({ "width":"30px", "height":"30px" });

$("#MuIconCont").css({ "width":"44px", "height":"44px" });
$("#MuIcon").css({ "font-size":"44px" });
$("#DateMonth, #In, #Artist, #City, #Charging").css({ "font-size":"11px" });

$("#BatRingOut").css({ "width":"60px", "height":"60px" });
$("#BatRingIn").css({ "width":"48px", "height":"48px" });
$("#Percentage").css({ "font-size":"21px" });

$("#Title").css({ "font-size":"15px" });
$("#PlayBg").css({ "width":"34px", "height":"34px" });
$("#PlayPause").css({ "width":"33px", "height":"27px", "padding-top":"9px", "padding-left":"3px", "font-size":"19px" });
$("#Prev").css({ "width":"26px", "height":"20px", "padding-top":"6px", "padding-left":"0px", "font-size":"12px" });
$("#Next").css({ "width":"23px", "height":"20px", "padding-top":"6px", "padding-left":"3px", "font-size":"12px" });
break;

case "iPhMax":
document.body.style.width='414px';
document.body.style.height='896px';
break;

case "iPh12Pro":
document.body.style.width='390px';
document.body.style.height='844px';
$("#Weekday").css({ "font-size":"23px" });
$("#HiCont, #LoCont, #WeCont, #TempCont").css({ "width":"35px", "height":"32px" });
$("#Hi, #Lo, #Temp").css({ "font-size":"14px" });

$("#MuIconCont").css({ "width":"46px", "height":"46px" });
$("#MuIcon").css({ "font-size":"46px" });

$("#BatRingOut").css({ "width":"61px", "height":"61px" });
$("#BatRingIn").css({ "width":"48px", "height":"48px" });
$("#Percentage").css({ "font-size":"22px" });

$("#Prev").css({ "width":"28px", "height":"21px", "padding-top":"7px", "padding-left":"0px", "font-size":"14px" });
$("#Next").css({ "width":"25px", "height":"21px", "padding-top":"7px", "padding-left":"3px", "font-size":"14px" });
break;

case "iPh12Max":
document.body.style.width='428px';
document.body.style.height='926px';
break;
  }
}, false);