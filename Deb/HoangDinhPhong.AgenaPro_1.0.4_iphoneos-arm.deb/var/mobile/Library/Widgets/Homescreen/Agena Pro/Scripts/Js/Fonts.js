let FontFamily = new FontFace("FontSelect", `url(${'/Fonts/' + config.FontSelect + '.ttf'}) format("truetype")`);
FontFamily.load().then(function(loadedFontFamily) {
document.fonts.add(loadedFontFamily); })

let WeekdayFont = new FontFace("WeekdayFont", `url(${'/Fonts/' + config.WeekdayFont + '.ttf'}) format("truetype")`);
WeekdayFont.load().then(function(loadedWeekdayFont) {
document.fonts.add(loadedWeekdayFont); })