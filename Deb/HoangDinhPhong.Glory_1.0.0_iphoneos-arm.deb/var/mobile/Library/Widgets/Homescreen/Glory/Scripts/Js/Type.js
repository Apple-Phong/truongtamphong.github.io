var iPhoneType = "auto";
if (iPhoneType == "auto") {
if (screen.height == 780) { iPhoneType = "iPhMini" }
else if (screen.height == 812) { iPhoneType = "iPhX11P" }
else if (screen.height == 896) { iPhoneType = "iPh11M" }
else if (screen.height == 844) { iPhoneType = "iPh12P" }
else if (screen.height == 926) { iPhoneType = "iPh12M" }
}

window.addEventListener("load", function () {
switch (iPhoneType) {

case "iPhMini":
document.body.style.width = '360px';
document.body.style.height = '780px';
$("#Day1, #Day2, #Day3, #Day4, #Day1Hi, #Day2Hi, #Day3Hi, #Day4Hi").css({ "font-size":"9px" });
$("#TempCity, #Condition, #Title").css({ "font-size":"10px" });
$("#Date, #LDate, #Rain, #Wind, #Percentage").css({ "font-size":"19px" });
$("#Positive, #Minus").css({ "top":"0px", "font-size":"11px" });
$("#RainIcon").css({ "top":"2px", "font-size":"7px" });
$("#WindIcon").css({ "top":"1px", "font-size":"8px" });
$("#BatIcon").css({ "top":"-2px", "font-size":"11px" });
$("#Charging").css({ "top":"0px", "font-size":"6px" });
$("#Weekday, #LMonth, #RainPercent, #Km, #BatPercent").css({ "font-size":"8px" });
$("#HighIcon").css({ "top":"-6px", "font-size":"25px" });
$("#LowIcon").css({ "font-size":"10px" });
$("#High, #Low").css({ "font-size":"9px" });
$(".TwelveSix, .NineThree").css({ "font-size":"7px" });
$("#Play").css({ "font-size":"13px" });
$("#Prev, #Next").css({ "font-size":"26px" });
break;

case "iPhX11P":
document.body.style.width = '375px';
document.body.style.height = '812px';
$("#Day1, #Day2, #Day3, #Day4, #Day1Hi, #Day2Hi, #Day3Hi, #Day4Hi").css({ "font-size":"10px" });
$("#TempCity, #Condition, #Title").css({ "font-size":"11px" });
$("#Date, #LDate, #Rain, #Wind, #Percentage").css({ "font-size":"20px" });
$("#Positive, #Minus").css({ "top":"-1px", "font-size":"12px" });
$("#RainIcon").css({ "top":"1px", "font-size":"7px" });
$("#WindIcon").css({ "top":"0px", "font-size":"8px" });
$("#BatIcon").css({ "top":"-3px", "font-size":"11px" });
$("#Charging").css({ "top":"-1px", "font-size":"6px" });
$("#Weekday, #LMonth, #RainPercent, #Km, #BatPercent").css({ "font-size":"8px" });
$("#HighIcon").css({ "top":"-6px", "font-size":"25px" });
$("#LowIcon").css({ "font-size":"10px" });
$("#High, #Low").css({ "font-size":"10px" });
break;

case "iPh11M":
document.body.style.width = '414px';
document.body.style.height = '896px';
break;

case "iPh12P":
document.body.style.width = '390px';
document.body.style.height = '844px';
break;

case "iPh12M":
document.body.style.width = '428px';
document.body.style.height = '926px';
break;
}
}, false);