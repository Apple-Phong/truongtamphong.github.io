// color
document.documentElement.style.setProperty('--textCl', config.textCl);
document.documentElement.style.setProperty('--dateCl', config.dateCl);
document.documentElement.style.setProperty('--lunarCl', config.lunarCl);
document.documentElement.style.setProperty('--batCl', config.batCl);
document.documentElement.style.setProperty('--rainCl', config.rainCl);
document.documentElement.style.setProperty('--windCl', config.windCl);
document.documentElement.style.setProperty('--tempCl', config.tempCl);
document.documentElement.style.setProperty('--wedayCl', config.wedayCl);
document.documentElement.style.setProperty('--highCl', config.highCl);
document.documentElement.style.setProperty('--lowCl', config.lowCl);
document.documentElement.style.setProperty('--secCl', config.secCl);
document.documentElement.style.setProperty('--controlCl', config.controlCl);

// on off
if (!config.effect) {
document.getElementById('BatColumnLCont').style.display = 'none';
document.getElementById('BatColumnRCont').style.display = 'none';
document.getElementById('AppBgCover').style.display = 'none';
}

// other
document.documentElement.style.setProperty('--ro', config.rotate + 's');