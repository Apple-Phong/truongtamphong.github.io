function checkMusic(newData) {
document.getElementById('Ytb').src = newData.nowPlaying.artwork.length > 0 ? newData.nowPlaying.artwork : 'Scripts/Images/Blank.png';

if (isplaying === 1) {
document.getElementById("BatBgL").style.animation = "effects 1s linear infinite";
document.getElementById("BatBgR").style.animation = "effects 1s linear infinite";
document.getElementById('AlbCont').style.animation = '';
document.getElementById('Album').style.animation = '';
document.getElementById('Ytb').style.animation = '';

document.getElementById("BatColumnLCont").classList.add('open');
document.getElementById("BatColumnLCont").classList.remove('closed');
document.getElementById("BatColumnRCont").classList.add('open');
document.getElementById("BatColumnRCont").classList.remove('closed');
document.getElementById("AppBgCover").classList.add('open');
document.getElementById("AppBgCover").classList.remove('closed');

document.getElementById('Play').classList.remove("BtnPlay");
document.getElementById('Play').classList.add("BtnPause");
} else {
document.getElementById("BatBgL").style.animation = "none";
document.getElementById("BatBgR").style.animation = "none";
document.getElementById('AlbCont').style.animation = 'none';
document.getElementById('Album').style.animation = 'fadingout 1s linear 1 forwards';
document.getElementById('Ytb').style.animation = 'fadingout 1s linear 1 forwards';

document.getElementById("BatColumnLCont").classList.add('closed');
document.getElementById("BatColumnLCont").classList.remove('open');
document.getElementById("BatColumnRCont").classList.add('closed');
document.getElementById("BatColumnRCont").classList.remove('open');
document.getElementById("AppBgCover").classList.add('closed');
document.getElementById("AppBgCover").classList.remove('open');

document.getElementById('Play').classList.remove("BtnPause");
document.getElementById('Play').classList.add("BtnPlay");
}

if (title === "(null)") {
document.getElementById('Title').innerHTML = titletext;
} else {
document.getElementById('Title').innerHTML = '• ' + title + ' •';
}

if (album === "(null)") {
document.getElementById('Album').src = 'Scripts/Images/Blank.png';
} else {		
var xhr = new XMLHttpRequest();
xhr.open('HEAD', "file:///var/mobile/Documents/Artwork.jpg", false);
xhr.send();

if (xhr.status === "404") {
document.getElementById('Album').src = 'Scripts/Images/Blank.png';
} else {
document.getElementById('Album').src = "file:///var/mobile/Documents/Artwork.jpg?" + (new Date()).getTime(); }
}
}

function checkOverflow(el) {
var curOverflow = el.style.overflow;
if ( !curOverflow || curOverflow === "visible" ) {
el.style.overflow = "none"; 
}

var isOverflowing = el.clientWidth < el.scrollWidth;
el.style.overflow = curOverflow;
return isOverflowing; 
}

function XenApi() {
api.media.observeData(function (newData) {
appPlaying = newData.nowPlayingApplication.identifier;
checkMusic(newData); });
}

function HDP() {
XenApi();
}

function openApp(app) {
api.apps.launchApplication(app);
}

function play() {
window.location = 'xeninfo:playpause';
document.getElementById('Play').style.opacity = 0.2;
setTimeout(function () {
document.getElementById('Play').style.opacity = 1;
}, 200);
}
		
function next() {
window.location = 'xeninfo:nexttrack';
document.getElementById('Album').style.animation = 'fadingout 1s linear 1 forwards';
document.getElementById('Ytb').style.animation = 'fadingout 1s linear 1 forwards';
document.getElementById('Next').style.opacity = 0.2;
setTimeout(function () {
document.getElementById('Next').style.opacity = 1;
}, 200);
}
			
function prev() {
window.location = 'xeninfo:prevtrack';
document.getElementById('Album').style.animation = 'fadingout 1s linear 1 forwards';
document.getElementById('Ytb').style.animation = 'fadingout 1s linear 1 forwards';
document.getElementById('Prev').style.opacity = 0.2;
setTimeout(function () {
document.getElementById('Prev').style.opacity = 1;
}, 200);
}

window.addEventListener("load", HDP, false);