function mainUpdate(type) {
if (type === "battery") { updateBattery(); }
if (type === "weather") { checkWeather(); }
}

function updateBattery() {
document.getElementById("Percentage").innerHTML = batteryPercent;
document.getElementById("Charging").innerHTML = (batteryCharging) ? charging : notcharging;
document.getElementById("BatteryL").style.height = batteryPercent + '%';
document.getElementById("BatteryR").style.height = batteryPercent + '%';

if (batteryPercent > 90 && batteryPercent <= 100) {
document.documentElement.style.setProperty('--batC', '#00FF00');
$("#BatteryL, #BatteryR").css({ "background": "linear-gradient(to bottom,#00FF00, #70FF13,#9EFF00,#D3FF13,#FFF604,#FFCB03,#FFA204,#FF6B08,#FF490E,#FF0000)" });
}

if (batteryPercent > 80 && batteryPercent <= 90) {
document.documentElement.style.setProperty('--batC', '#70FF13');
$("#BatteryL, #BatteryR").css({ "background": "linear-gradient(to bottom,#70FF13,#9EFF00,#D3FF13,#FFF604,#FFCB03,#FFA204,#FF6B08,#FF490E,#FF0000)" });
}

if (batteryPercent > 70 && batteryPercent <= 80) {
document.documentElement.style.setProperty('--batC', '#9EFF00');
$("#BatteryL, #BatteryR").css({ "background": "linear-gradient(to bottom,#9EFF00,#D3FF13,#FFF604,#FFCB03,#FFA204,#FF6B08,#FF490E,#FF0000)" });
}

if (batteryPercent > 60 && batteryPercent <= 70) {
document.documentElement.style.setProperty('--batC', '#D3FF13');
$("#BatteryL, #BatteryR").css({ "background": "linear-gradient(to bottom,#D3FF13,#FFF604,#FFCB03,#FFA204,#FF6B08,#FF490E,#FF0000)" });
}

if (batteryPercent > 50 && batteryPercent <= 60) {
document.documentElement.style.setProperty('--batC', '#FFF604');
$("#BatteryL, #BatteryR").css({ "background": "linear-gradient(to bottom,#FFF604,#FFCB03,#FFA204,#FF6B08,#FF490E,#FF0000)" });
}

if (batteryPercent > 40 && batteryPercent <= 50) {
document.documentElement.style.setProperty('--batC', '#FFCB03');
$("#BatteryL, #BatteryR").css({ "background": "linear-gradient(to bottom,#FFCB03,#FFA204,#FF6B08,#FF490E,#FF0000)"
});
}

if (batteryPercent > 30 && batteryPercent <= 40) {
document.documentElement.style.setProperty('--batC', '#FFA204');
$("#BatteryL, #BatteryR").css({ "background": "linear-gradient(to bottom,#FFA204,#FF6B08,#FF490E,#FF0000)" });
}

if (batteryPercent > 20 && batteryPercent <= 30) {
document.documentElement.style.setProperty('--batC', '#FF6B08');
$("#BatteryL, #BatteryR").css({ "background": "linear-gradient(to bottom,#FF6B08,#FF490E,#FF0000)" });
}

if (batteryPercent >= 10 && batteryPercent <= 20) {
document.documentElement.style.setProperty('--batC', '#FF490E');
$("#BatteryL, #BatteryR").css({ "background": "linear-gradient(to bottom,#FF490E,#FF0000)" });
}

if (batteryPercent >= 0 && batteryPercent <= 10) {
document.documentElement.style.setProperty('--batC', '#FF0000');
$("#BatteryL, #BatteryR").css({ "background": "#FF0000" });
}
}