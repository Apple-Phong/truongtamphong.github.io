function checkWeather() {
document.getElementById('WeatherIcon').src = 'Scripts/Weather/' + weather.conditionCode + '.png';
document.getElementById("City").innerHTML = '• ' + weather.city;
document.getElementById("Temp").innerHTML = weather.temperature;
document.getElementById("Condition").innerHTML = '• ' + condition[weather.conditionCode] + ' •';
document.getElementById("Rain").innerHTML = weather.hourlyForecasts[0].percentPrecipitation;
document.getElementById("Wind").innerHTML = weather.windSpeed;
document.getElementById("High").innerHTML = weather.high;
document.getElementById("Low").innerHTML = weather.low;

document.getElementById("Day1").innerHTML = sday[weather.dayForecasts[1].dayOfWeek - 1];
document.getElementById("Day2").innerHTML = sday[weather.dayForecasts[2].dayOfWeek - 1];
document.getElementById("Day3").innerHTML = sday[weather.dayForecasts[3].dayOfWeek - 1];
document.getElementById("Day4").innerHTML = sday[weather.dayForecasts[4].dayOfWeek - 1];

document.getElementById("Day1Icon").src = "Scripts/Weather/" + weather.dayForecasts[1].icon + ".png";
document.getElementById("Day2Icon").src = "Scripts/Weather/" + weather.dayForecasts[2].icon + ".png";
document.getElementById("Day3Icon").src = "Scripts/Weather/" + weather.dayForecasts[3].icon + ".png";
document.getElementById("Day4Icon").src = "Scripts/Weather/" + weather.dayForecasts[4].icon + ".png";

document.getElementById("Day1Hi").innerHTML = weather.dayForecasts[1].high;
document.getElementById("Day2Hi").innerHTML = weather.dayForecasts[2].high;
document.getElementById("Day3Hi").innerHTML = weather.dayForecasts[3].high;
document.getElementById("Day4Hi").innerHTML = weather.dayForecasts[4].high;
}