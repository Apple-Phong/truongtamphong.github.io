var iPhoneType = "auto";
if (iPhoneType == "auto") {
if (screen.height == 812) { iPhoneType = "iPhX"; }
else if (screen.height == 896) { iPhoneType = "iPhMax"; }
else if (screen.height == 844) { iPhoneType = "iPh12Pro"; }
else { iPhoneType = "iPh12Max"; }
}

window.addEventListener("load", function() { 
switch(iPhoneType) {

case "iPhX":
document.body.style.width='375px';
document.body.style.height='812px';
$("#Stt3Cont").css({ "top":"1.6%" });
$("#Month").css({ "font-size":"17px" });
$("#AnaCont").css({ "width":"118px", "height":"118px" });
break;

case "iPhMax":
document.body.style.width='414px';
document.body.style.height='896px';
break;

case "iPh12Pro":
document.body.style.width='390px';
document.body.style.height='844px';
$("#Stt3Cont").css({ "top":"1.5%" });
$("#Month").css({ "font-size":"18px" });
$("#AnaCont").css({ "width":"125px", "height":"125px" });
break;

case "iPh12Max":
document.body.style.width='428px';
document.body.style.height='926px';
$("#Month").css({ "font-size":"19px" });
break;
}}, false);