// Color
document.documentElement.style.setProperty('--bgCl', config.bgCl);
document.documentElement.style.setProperty('--tdBgCl', config.tdBgCl);
document.documentElement.style.setProperty('--dotCl', config.dotCl);
document.documentElement.style.setProperty('--textCl', config.textCl);
document.documentElement.style.setProperty('--brCl', config.brCl);
document.documentElement.style.setProperty('--dateCl', config.dateCl);
document.documentElement.style.setProperty('--lineMinCl', config.lineMinCl);
document.documentElement.style.setProperty('--lineHourCl', config.lineHourCl);
document.documentElement.style.setProperty('--hourminCl', config.hourminCl);
document.documentElement.style.setProperty('--hourNumCl', config.hourNumCl);
document.documentElement.style.setProperty('--secCl', config.secCl);
document.documentElement.style.setProperty('--dockCl', config.dockCl);

// Blur
document.documentElement.style.setProperty('--appBlur', config.appBlur + 'px');
document.documentElement.style.setProperty('--albBlur', config.albBlur + 'px');

//Border
document.documentElement.style.setProperty('--stt3Br', config.stt3Br + 'px');
document.documentElement.style.setProperty('--anaBr', config.anaBr + 'px');
document.documentElement.style.setProperty('--dockBr', config.dockBr + 'px');

// On off
if(!config.stt3){
document.getElementById('Stt3Cont').style.display = 'none';
document.getElementById('Stt3Blur').style.display = 'none';
}

if(!config.time){
document.getElementById('AmLich').style.display = 'none';
document.getElementById('Percentage').style.display = 'none';
document.getElementById('AnaCont').style.display = 'none';
document.getElementById('CalCont').style.display = 'none';
document.getElementById('Line').style.display = 'none';
document.getElementById('TimeBg').style.display = 'none';
document.getElementById('TimeBgBlur').style.display = 'none';
document.getElementById('FreeRAM').style.display = 'none';

document.getElementById('AppCont').style.top = '7.6%';
document.getElementById('AppCont').style.height = '71.6%';
document.getElementById('AppCont').style.width = '94%';
document.getElementById('AppBlur').style.top = '7.6%';
document.getElementById('AppBlur').style.height = '71.6%';
document.getElementById('AppBlur').style.width = '94%';
}

if(!config.timeBg){
document.getElementById('BgAnaL').style.display = 'none';
document.getElementById('BgAnaR').style.display = 'none';
document.getElementById('BgAnaDark').style.display = 'none';

document.getElementById('AnaBgIn').style.transform = 'translate(-50%, -50%) scale(1)';
}

if(!config.percent){
document.getElementById('Percentage').style.display = 'none';
document.getElementById('AmLich').style.left = '60%';
}

if(!config.app){
document.getElementById('AppCont').style.display = 'none';
document.getElementById('AppBlur').style.display = 'none';
}

if(!config.doColum){
document.getElementById('DockColumL').style.display = 'none';
document.getElementById('DockColumC').style.display = 'none';
document.getElementById('DockColumR').style.display = 'none';
}

if(!config.ram){
document.getElementById('FreeRAM').style.display = 'none';
}

if(!config.album){
document.getElementById('Album').style.display = 'none';
document.getElementById('YouTube').style.display = 'none';
document.getElementById('AlbBlur').style.display = 'none';
}

if(!config.ctrl){
document.getElementById('Controls').style.display = 'none';
}

if(!config.title){
document.getElementById('Title').style.display = 'none';
}

if(!config.dock){
document.getElementById('DockCont').style.display = 'none';
document.getElementById('DockBlur').style.display = 'none';
}