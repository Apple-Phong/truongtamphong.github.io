function TTP() {
const deg = 6;
const hr = document.querySelector('.Hour');
const mn = document.querySelector('.Min');
const sc = document.querySelector('.Sec');

setInterval(() => {
let day = new Date();
let hh = day.getHours() * 30;
let mm = day.getMinutes() * deg;
let ss = day.getSeconds() * deg;
hr.style.transform = `rotateZ(${hh + (mm / 12)}deg)`;
mn.style.transform = `rotateZ(${mm}deg)`;
sc.style.transform = `rotateZ(${ss}deg)`;});
}

const three = document.querySelector('.ThreeNum');
three.textContent = '3';
const nine = document.querySelector('.NineNum');
nine.textContent = '9';

const six = document.querySelector('.SixNum');
six.textContent = '6';
const twelve = document.querySelector('.TwelveNum');
twelve.textContent = '12';