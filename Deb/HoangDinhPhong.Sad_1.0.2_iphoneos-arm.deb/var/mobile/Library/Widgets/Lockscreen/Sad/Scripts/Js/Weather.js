function mainUpdate(type) {
if (type === "weather") { checkWeather(); }
}

function checkWeather() {
document.getElementById("WeInfo").innerHTML = temptext + ' ' + weather.temperature + '°' + ', ' + condition[weather.conditionCode] + ' ' + intext + ' ' + weather.city;
}