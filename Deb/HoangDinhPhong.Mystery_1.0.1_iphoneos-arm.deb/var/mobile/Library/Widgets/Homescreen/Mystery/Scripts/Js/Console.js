var i = 0;
var j = -1;
var t = document.getElementById("Console"),
   e = document.getElementById("Write");
var load = 'Loading...';
var name, info, ram;
var txt = [load];
var speed = config.sp;
var time = config.time;

function typeWriter() {
   if (i < txt[j].length) {
      e.innerHTML += txt[j].charAt(i);
      i++;
      setTimeout(typeWriter, speed);
   } else {
      i = 0;
      setTimeout(n3xt, time);
   }
}

function n3xt() {
   e.innerHTML = '#Terminal: ';
   j++;
   if (j > txt.length - 1) {
      j = 0;
   }
   setTimeout(typeWriter, 500);
}
n3xt();

function init() {
   updateBattery();
   setInterval("updateBattery();", 1000);
}

setInterval(() => {
   updateBattery()
}, 1000)