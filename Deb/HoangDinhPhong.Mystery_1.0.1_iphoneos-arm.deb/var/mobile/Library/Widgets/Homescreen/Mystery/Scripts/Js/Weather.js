function mainUpdate(type) {
   if (type === "weather") {
      checkWeather();
   } else if (type === "battery") {
      updateBattery();
      if (Device = true) {
         txt.push(name);
      }
      if (Weather = true) {
         txt.push(info);
      }
      if (Ram = true) {
         txt.push(ram);
      }
   }
}

function checkWeather() {
   document.getElementById('WeIcon').src = 'Scripts/Weather/' + config.IconSet + '/' + weather.conditionCode + '.png';
   document.getElementById("Condition").innerHTML = condition[weather.conditionCode];
   document.getElementById("Temp").innerHTML = weather.temperature + '°';

   document.getElementById("Day1").innerHTML = shortdays[weather.dayForecasts[1].dayOfWeek - 1];
   document.getElementById("Day2").innerHTML = shortdays[weather.dayForecasts[2].dayOfWeek - 1];
   document.getElementById("Day3").innerHTML = shortdays[weather.dayForecasts[3].dayOfWeek - 1];
   document.getElementById("Day4").innerHTML = shortdays[weather.dayForecasts[4].dayOfWeek - 1];

   document.getElementById("Day1Icon").src = "Scripts/Weather/" + config.IconSet2 + "/" + weather.dayForecasts[1].icon + ".png";
   document.getElementById("Day2Icon").src = "Scripts/Weather/" + config.IconSet2 + "/" + weather.dayForecasts[2].icon + ".png";
   document.getElementById("Day3Icon").src = "Scripts/Weather/" + config.IconSet2 + "/" + weather.dayForecasts[3].icon + ".png";
   document.getElementById("Day4Icon").src = "Scripts/Weather/" + config.IconSet2 + "/" + weather.dayForecasts[4].icon + ".png";

   document.getElementById("Day1HiLo").innerHTML = weather.dayForecasts[1].high + "°" + "|" + weather.dayForecasts[1].low + "°";
   document.getElementById("Day2HiLo").innerHTML = weather.dayForecasts[2].high + "°" + "|" + weather.dayForecasts[2].low + "°";
   document.getElementById("Day3HiLo").innerHTML = weather.dayForecasts[3].high + "°" + "|" + weather.dayForecasts[3].low + "°";
   document.getElementById("Day4HiLo").innerHTML = weather.dayForecasts[4].high + "°" + "|" + weather.dayForecasts[4].low + "°";

   info = intext + ' ' + weather.city + ', ' + windtext + ' ' + weather.windSpeed + 'km/h, ' + humitext + ' ' + weather.humidity + '%, ' + raintext + ' ' + weather.hourlyForecasts[0].percentPrecipitation + '%, ' + hilotext + ' ' + weather.high + '/' + weather.low + '°' + '.';
   name = deviceName;

   document.getElementById('Device').innerHTML = deviceType;
   document.getElementById('iOS').innerHTML = 'iOS' + ' ' + systemVersion;
}