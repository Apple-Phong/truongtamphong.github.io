document.documentElement.style.setProperty('--weekCl', config.weekCl);
