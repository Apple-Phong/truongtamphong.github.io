/*Color*/
document.documentElement.style.setProperty('--bgCl', config.bgCl);
document.documentElement.style.setProperty('--alBg', config.alBg);
document.documentElement.style.setProperty('--dockCl', config.dockCl);
document.documentElement.style.setProperty('--textCl', config.textCl);
document.documentElement.style.setProperty('--todayCl', config.todayCl);
document.documentElement.style.setProperty('--dotCl', config.dotCl);

/*On Off*/
if (!config.time) {
document.getElementById('Hour').style.display = 'none';
document.getElementById('Minute').style.display = 'none';
document.getElementById('ClockLine').style.display = 'none';
document.getElementById('Month').style.display = 'block';
document.getElementById('MonthText').style.display = 'block';
}

if (!config.dock) {
document.getElementById('DockDark').style.display = 'none';
}