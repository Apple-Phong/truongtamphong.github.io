/*Color*/
document.documentElement.style.setProperty('--weekdayCl', config.weekdayCl);

document.documentElement.style.setProperty('--weekdayRightCl', config.weekdayRightCl);

document.documentElement.style.setProperty('--dateMonthCl', config.dateMonthCl);

document.documentElement.style.setProperty('--dateMonthCl', config.dateMonthCl);

document.documentElement.style.setProperty('--amlichCl', config.amlichCl);
document.documentElement.style.setProperty('--amlichBgLCl', config.amlichBgLCl);
document.documentElement.style.setProperty('--amlichBgRCl', config.amlichBgRCl);

document.documentElement.style.setProperty('--hiCl', config.hiCl);

document.documentElement.style.setProperty('--loCl', config.loCl);

document.documentElement.style.setProperty('--tempCl', config.tempCl);

document.documentElement.style.setProperty('--batPerCl', config.batPerCl);

document.documentElement.style.setProperty('--chargingCl', config.chargingCl);

document.documentElement.style.setProperty('--muIconCl', config.muIconCl);
document.documentElement.style.setProperty('--cityCl', config.cityCl);

document.documentElement.style.setProperty('--titCl', config.titCl);

document.documentElement.style.setProperty('--artCl', config.artCl);

document.documentElement.style.setProperty('--playCl', config.playCl);
document.documentElement.style.setProperty('--contrCl', config.contrCl);

document.documentElement.style.setProperty('--effectsLeftCl', config.effectsCl);

document.documentElement.style.setProperty('--effectsRightCl', config.effectsRightCl);

/* On off */
if(!config.MuBat){
document.getElementById('MediaCont').style.display = 'none';
document.getElementById('AlbCont').style.display = 'none';
document.getElementById('BatCont').style.display = 'none';

document.getElementById('AppCont').style.height = '56.8%';
document.getElementById('SearchCont').style.top = '2.4%';
document.getElementById('SearchCont').style.height = '6%';
}

if(!config.Se){
document.getElementById('SearchCont').style.display = 'none';
}

if(!config.App){
document.getElementById('AppCont').style.display = 'none';
}

if(!config.Do){
document.getElementById('Dock').style.display = 'none';
}

/* Analog Clock */
document.documentElement.style.setProperty('--analogScale', config.analogScale);

document.documentElement.style.setProperty('--hourCl', window.config.hourCl);

document.documentElement.style.setProperty('--minCl', window.config.minCl);

document.documentElement.style.setProperty('--secCl', window.config.secCl);

document.documentElement.style.setProperty('--numCl', window.config.numCl);

document.documentElement.style.setProperty('--hourMarCl', window.config.hourMarCl);

document.documentElement.style.setProperty('--bgCenCl', window.config.bgCenCl);

/* Search */
document.getElementById("In").placeholder = config.ph;