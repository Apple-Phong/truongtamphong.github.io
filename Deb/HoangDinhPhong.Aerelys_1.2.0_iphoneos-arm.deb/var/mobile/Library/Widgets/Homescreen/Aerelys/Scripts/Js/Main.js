var iPhoneType = "auto";
if (iPhoneType == "auto") {
if (screen.height == 812) { iPhoneType = "iPhX"; }
else if (screen.height == 896) { iPhoneType = "iPhMax"; }
else if (screen.height == 844) { iPhoneType = "iPh12Pro"; }
else { iPhoneType = "iPh12Max"; }
}

window.addEventListener("load", function() { 
switch(iPhoneType) {

case "iPhX":
document.body.style.width='375px';
document.body.style.height='812px';
$("#BattCont").css({ "width":"91px", "height":"91px" });
$("#BlCont").css({ "width":"51px", "height":"51px" });
break;

case "iPhMax":
document.body.style.width='414px';
document.body.style.height='896px';
break;

case "iPh12Pro":
document.body.style.width='390px';
document.body.style.height='844px';
$("#BattCont").css({ "width":"94px", "height":"94px" });
$("#BlCont").css({ "width":"55px", "height":"55px" });
break;

case "iPh12Max":
document.body.style.width='428px';
document.body.style.height='926px';
$("#BattCont").css({ "width":"104px", "height":"104px" });
break;
  }
}, false);