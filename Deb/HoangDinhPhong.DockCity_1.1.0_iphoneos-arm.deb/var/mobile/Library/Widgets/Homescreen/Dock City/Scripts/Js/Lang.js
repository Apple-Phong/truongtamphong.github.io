if (window.config.language == 'Vietnamese') {
var sunday = ['CN'];
var sday = ['T2', 'T3', 'T4', 'T5', 'T6', 'T7'];
var months = ["Tháng 01", "Tháng 02", "Tháng 03", "Tháng 04", "Tháng 05", "Tháng 06", "Tháng 07", "Tháng 08", "Tháng 09", "Tháng 10", "Tháng 11", "Tháng 12"];
}

if (window.config.language == 'English') {
var sunday = ['Su'];
var sday = ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
}