// Color
document.documentElement.style.setProperty('--bgCl', config.bgCl);
document.documentElement.style.setProperty('--dotCl', config.dotCl);
document.documentElement.style.setProperty('--textCl', config.textCl);
document.documentElement.style.setProperty('--brCl', config.brCl);
document.documentElement.style.setProperty('--dateCl', config.dateCl);
document.documentElement.style.setProperty('--lineMinCl', config.lineMinCl);
document.documentElement.style.setProperty('--lineHourCl', config.lineHourCl);
document.documentElement.style.setProperty('--hourminCl', config.hourminCl);
document.documentElement.style.setProperty('--hourNumCl', config.hourNumCl);
document.documentElement.style.setProperty('--secCl', config.secCl);

// Blur
document.documentElement.style.setProperty('--appBlur', config.appBlur + 'px');

//Border
document.documentElement.style.setProperty('--stt3Br', config.stt3Br + 'px');
document.documentElement.style.setProperty('--anaBr', config.anaBr + 'px');
document.documentElement.style.setProperty('--dockBr', config.dockBr + 'px');

// On off
if(!config.stt3){
document.getElementById('Stt3Cont').style.display = 'none';
document.getElementById('Stt3Blur').style.display = 'none';
}

if(!config.clockCal){
document.getElementById('AnaCont').style.display = 'none';
document.getElementById('CalCont').style.display = 'none';
}

if(!config.app){
document.getElementById('AppCont').style.display = 'none';
document.getElementById('AppBlur').style.display = 'none';
}

if(!config.doColum){
document.getElementById('DockColumL').style.display = 'none';
document.getElementById('DockColumC').style.display = 'none';
document.getElementById('DockColumR').style.display = 'none';
}