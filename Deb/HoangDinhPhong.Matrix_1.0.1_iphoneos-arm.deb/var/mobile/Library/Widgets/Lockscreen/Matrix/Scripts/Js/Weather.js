function mainUpdate(type) {
if (type === "weather") { checkWeather(); }
}

function checkWeather() {
document.getElementById("Condition").innerHTML = condition[weather.conditionCode] + ' ' + weather.temperature + '°';
document.getElementById("WeInfo").innerHTML = '• ' + weather.city + ': ' + windtext + ' ' + weather.windSpeed + 'km/h, ' + humitext + ' ' + weather.humidity + '%' + ' ' + feelstext + ' ' + weather.feelsLike + '°';
}