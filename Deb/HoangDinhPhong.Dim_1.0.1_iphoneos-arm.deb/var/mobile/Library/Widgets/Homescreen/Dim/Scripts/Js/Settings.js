if(!config.snow){
document.getElementById('FlakeContainer').style.display = 'none';
}

if(!config.app){
document.getElementById('Application').style.display = 'none';
}

if(!config.dock){
document.getElementById('Dock').style.display = 'none';
}