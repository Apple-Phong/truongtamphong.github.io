function checkWeather() {
document.getElementById("City").innerHTML = weather.city;
document.getElementById("Condition").innerHTML = condition[weather.conditionCode];
document.getElementById("Temp").innerHTML = weather.temperature + '°';
document.getElementById("Wind").innerHTML = windtext + ' ' + weather.windSpeed + ' km/h';

document.getElementById("Day1").innerHTML = sday[weather.dayForecasts[1].dayOfWeek - 1];
document.getElementById("Day2").innerHTML = sday[weather.dayForecasts[2].dayOfWeek - 1];

document.getElementById("Day1Icon").src = "Scripts/Weather/" + weather.dayForecasts[1].icon + ".png";
document.getElementById("Day2Icon").src = "Scripts/Weather/" + weather.dayForecasts[2].icon + ".png";

document.getElementById("Day1Hi").innerHTML = weather.dayForecasts[1].high + '°';
document.getElementById("Day2Hi").innerHTML = weather.dayForecasts[2].high + '°';
}