document.documentElement.style.setProperty('--batCl', config.batCl);

document.getElementById('Today').innerHTML = todaytext;