function mainUpdate(type) {
if (type === "weather") { checkWeather() }
}

function checkWeather() {
document.getElementById('WeatherIcon').src = 'Scripts/Weather/' + weather.conditionCode + '.svg';
document.getElementById("CityTemp").innerHTML = weather.city + ', ' + weather.temperature + '°';
document.getElementById("Condition").innerHTML = condition[weather.conditionCode];
}