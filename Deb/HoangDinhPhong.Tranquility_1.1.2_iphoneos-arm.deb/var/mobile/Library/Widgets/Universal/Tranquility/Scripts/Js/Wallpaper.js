document.getElementById('BgInput').addEventListener('change', function (e) {
var tw = e.target.files,
rd = new FileReader();
rd.onload = (function () {
return function (e) {
localStorage.tranquility = e.target.result;
document.getElementById('Wallpaper').style.backgroundImage = 'url("' + localStorage.tranquility + '")';
tw = null;
rd = null;};}(tw[0]));
rd.readAsDataURL(tw[0]);});
if (localStorage.tranquility && localStorage.tranquility != "null") {
document.getElementById('Wallpaper').style.backgroundImage = 'url("' + localStorage.tranquility + '")';
}