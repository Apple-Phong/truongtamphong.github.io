/* Other */
document.documentElement.style.setProperty('--bl', config.bl + 'px');
document.documentElement.style.setProperty('--shW', config.shW + 'px');
document.documentElement.style.setProperty('--shTrans', config.shTrans);
document.documentElement.style.setProperty('--sec', config.sec + 's');
document.getElementById('YourName').innerHTML = config.YourName;
document.getElementById('Wel').innerHTML = weltext;
document.getElementById('Come').innerHTML = cometext;
document.getElementById('CD').src = 'Scripts/Images/' + config.cdSet + '.png';

/*Color*/
document.documentElement.style.setProperty('--bgCl', config.bgCl);
document.documentElement.style.setProperty('--clockCl', config.clockCl);
document.documentElement.style.setProperty('--textCl', config.textCl);
document.documentElement.style.setProperty('--welCl', config.welCl);
document.documentElement.style.setProperty('--comeCl', config.comeCl);
document.documentElement.style.setProperty('--playCl', config.playCl);
document.documentElement.style.setProperty('--nextCl', config.nextCl);
document.documentElement.style.setProperty('--titleCl', config.titleCl);