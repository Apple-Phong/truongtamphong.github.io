var iPhoneType = "auto";
if (iPhoneType == "auto") {
if (screen.height == 480) { iPhoneType = "iPh4"; }
else if (screen.height == 568) { iPhoneType = "iPh5"; }
else if (screen.height == 667) { iPhoneType = "iPh678"; }
else if (screen.height == 736) { iPhoneType = "iPh678Plus"; }
else if (screen.height == 812) { iPhoneType = "iPhX"; }
else if (screen.height == 896) { iPhoneType = "iPhMax"; }
else if (screen.height == 844) { iPhoneType = "iPh12Pro"; }
else { iPhoneType = "iPh12Max"; }
}

window.addEventListener("load", function() { 
switch(iPhoneType) {

case "iPh4":
document.body.style.width='320px';
document.body.style.height='480px';
break;

case "iPh5":
document.body.style.width='320px';
document.body.style.height='568px';
break;

case "iPh678":
document.body.style.width='375px';
document.body.style.height='667px';
$("#InfoCont").css({ "font-size":"9px" });
$("#YourName").css({ "font-size":"9px" });
$("#Tod").css({ "font-size":"12px" });
$("#Welcome").css({ "top":"29.5%", "font-size":"29px" });
$("#Clock").css({ "font-size":"25px" });
$("#AmLich").css({ "font-size":"11px" });
$("#Percentage").css({ "font-size":"8px" });
$("#Calendar").css({ "font-size":"10px" });
$("#PlayPause").css({ "padding-top":"2px", "font-size":"20px" });
$("#Prev, #Next").css({ "font-size":"13px" });
$("#Wallpaper, #Album, #YouTube").css({ "height":"68.5%" });
$("#Title").css({ "bottom":"1%", "font-size":"10px" });
break;

case "iPh678Plus":
document.body.style.width='414px';
document.body.style.height='736px';
$("#Clock").css({ "font-size":"29px" });
$("#InfoCont").css({ "font-size":"10px" });
$("#AmLich").css({ "font-size":"13px" });
$("#Percentage").css({ "font-size":"9px" });
$("#YourName").css({ "font-size":"11px" });
$("#Tod").css({ "font-size":"15px" });
$("#Welcome").css({ "top":"28.3%", "font-size":"34px" });
$("#PlayPause").css({ "padding-top":"2px", "font-size":"22px" });
$("#Prev, #Next").css({ "font-size":"15px" });
$("#Wallpaper, #Album, #YouTube").css({ "height":"68%" });
$("#Title").css({ "bottom":"1.2%" });
break;

case "iPhX":
document.body.style.width='375px';
document.body.style.height='812px';
$("#Clock").css({ "font-size":"33px" });
$("#Tod").css({ "width":"115%" });
$("#Welcome").css({ "font-size":"40px" });
$("#Percentage").css({ "width":"115%" });
$("#PlayPause").css({ "font-size":"23px" });
$("#Prev, #Next").css({ "font-size":"16px" });
break;

case "iPhMax":
document.body.style.width='414px';
document.body.style.height='896px';
break;

case "iPh12Pro":
document.body.style.width='390px';
document.body.style.height='844px';
$("#Clock").css({ "font-size":"33px" });
$("#Welcome").css({ "font-size":"41px" });
$("#Percentage").css({ "width":"115%" });
$("#PlayPause").css({ "font-size":"24px" });
$("#Prev, #Next").css({ "font-size":"17px" });
break;

case "iPh12Max":
document.body.style.width='428px';
document.body.style.height='926px';
break;
}}, false);