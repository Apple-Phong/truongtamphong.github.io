function updateBattery() {
document.getElementById("Percentage").innerHTML = battext + ' ' + batteryPercent + '%' + ' ' + ((batteryCharging) ? charging : notcharging);
}